/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.helpers;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

/**
 * Tab separated spill file used to keep a large number of rows on disk while the CVE report is
 * built. One record is always one line: tab, backslash and line breaks inside a value are escaped,
 * so a record can be read back without holding more than one line at a time.
 *
 * <p>The separator only has to be something that cannot appear unescaped in a value.</p>
 */
public final class TsvFile {

	private static final char SEPARATOR = '\t';

	private TsvFile() {
	}

	/** Appends rows to a spill file. */
	public static final class Writer implements Closeable {

		private final BufferedWriter writer;

		public Writer(Path path) throws IOException {
			this.writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8,
					StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
		}

		public void write(List<String> values) throws IOException {
			StringBuilder line = new StringBuilder(values.size() * 48);
			for (int index = 0; index < values.size(); index++) {
				if (index > 0) {
					line.append(SEPARATOR);
				}
				escape(values.get(index), line);
			}
			line.append('\n');
			writer.write(line.toString());
		}

		public void flush() throws IOException {
			writer.flush();
		}

		@Override
		public void close() throws IOException {
			writer.close();
		}

		private static void escape(String value, StringBuilder target) {
			if (value == null) {
				return;
			}
			for (int index = 0; index < value.length(); index++) {
				char character = value.charAt(index);
				switch (character) {
					case '\\':
						target.append("\\\\");
						break;
					case '\t':
						target.append("\\t");
						break;
					case '\n':
						target.append("\\n");
						break;
					case '\r':
						target.append("\\r");
						break;
					default:
						target.append(character);
						break;
				}
			}
		}
	}

	/** Reads the rows of a spill file back, one line at a time. */
	public static final class Reader implements Closeable {

		private final BufferedReader reader;

		public Reader(Path path) throws IOException {
			this.reader = Files.newBufferedReader(path, StandardCharsets.UTF_8);
		}

		/** The next row, or null at the end of the file. */
		public List<String> read() throws IOException {
			String line = reader.readLine();
			return line == null ? null : parse(line);
		}

		@Override
		public void close() throws IOException {
			reader.close();
		}
	}

	/** Splits one line of a spill file back into its values. */
	public static List<String> parse(String line) {
		List<String> values = new ArrayList<>(8);
		StringBuilder value = new StringBuilder(32);
		boolean escaped = false;

		for (int index = 0; index < line.length(); index++) {
			char character = line.charAt(index);
			if (escaped) {
				switch (character) {
					case 't':
						value.append('\t');
						break;
					case 'n':
						value.append('\n');
						break;
					case 'r':
						value.append('\r');
						break;
					default:
						value.append(character);
						break;
				}
				escaped = false;
			} else if (character == '\\') {
				escaped = true;
			} else if (character == SEPARATOR) {
				values.add(value.toString());
				value.setLength(0);
			} else {
				value.append(character);
			}
		}
		values.add(value.toString());
		return values;
	}

	/**
	 * Reads a spill file with random access, so one group of rows can be read without scanning the
	 * file from the start. Used for the groups of the CVE report, where the same group is read more
	 * than once.
	 */
	public static final class RandomReader implements Closeable {

		private static final int BUFFER_SIZE = 1 << 16;

		private final RandomAccessFile file;
		private final byte[] buffer = new byte[BUFFER_SIZE];
		private final ByteArrayOutputStream line = new ByteArrayOutputStream(256);

		private int bufferPosition;
		private int bufferLimit;
		private boolean endOfFile;
		private long consumed;

		public RandomReader(Path path) throws IOException {
			this.file = new RandomAccessFile(path.toFile(), "r");
		}

		/** The byte offset of the row that {@link #read()} would return next. */
		public long position() {
			return consumed;
		}

		public void seek(long position) throws IOException {
			file.seek(position);
			bufferPosition = 0;
			bufferLimit = 0;
			endOfFile = false;
			consumed = position;
		}

		/** The next row, or null at the end of the file. */
		public List<String> read() throws IOException {
			line.reset();
			boolean any = false;

			while (true) {
				if (bufferPosition >= bufferLimit) {
					if (endOfFile) {
						break;
					}
					bufferLimit = file.read(buffer);
					bufferPosition = 0;
					if (bufferLimit <= 0) {
						endOfFile = true;
						break;
					}
				}
				byte value = buffer[bufferPosition++];
				consumed++;
				any = true;
				if (value == '\n') {
					return parse(new String(line.toByteArray(), StandardCharsets.UTF_8));
				}
				line.write(value);
			}
			return any ? parse(new String(line.toByteArray(), StandardCharsets.UTF_8)) : null;
		}

		@Override
		public void close() throws IOException {
			file.close();
		}
	}
}
