package com.automationanywhere.botcommand.sharepointpersongroup.session;

import java.net.http.HttpClient;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.concurrent.locks.ReentrantLock;

import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.commandsdk.i18n.Messages;
import com.automationanywhere.commandsdk.i18n.MessagesFactory;
import com.automationanywhere.core.security.SecureString;
import com.automationanywhere.toolchain.runtime.session.CloseableSessionObject;

/**
 * The SharePoint session that the Authenticate action hands to the following actions.
 *
 * <p>It holds the connection details, the HttpClient, the resolved site ID and the current Graph
 * token. The token is refreshed automatically shortly before it expires, so a long bot does not
 * fail in the middle of a run. The client secret is kept as a {@link SecureString} and is only read
 * at the moment a token is requested.</p>
 */
public class GraphSession implements CloseableSessionObject {

	private static final Messages MESSAGES = MessagesFactory
			.getMessages("com.automationanywhere.botcommand.sharepointpersongroup.messages");

	/** Renew this long before the token really expires, to leave room for clock skew. */
	private static final Duration REFRESH_WINDOW = Duration.ofMinutes(2);

	private final String tenantId;
	private final String clientId;
	private final SecureString clientSecret;
	private final String sharePointHost;
	private final String siteName;
	private final HttpClient httpClient;
	private final ReentrantLock tokenLock = new ReentrantLock();

	private volatile String accessToken;
	private volatile Instant tokenExpiry;
	private volatile String siteId;
	private volatile boolean closed;

	public GraphSession(String tenantId, String clientId, SecureString clientSecret, String sharePointHost,
			String siteName) {
		this.tenantId = tenantId;
		this.clientId = clientId;
		this.clientSecret = clientSecret;
		this.sharePointHost = sharePointHost;
		this.siteName = siteName == null ? "" : siteName;
		this.httpClient = HttpClient.newBuilder()
				.connectTimeout(Duration.ofSeconds(30))
				.followRedirects(HttpClient.Redirect.NORMAL)
				.build();
	}

	public String getSharePointHost() {
		return sharePointHost;
	}

	/** Empty for the root site, otherwise the part after {@code /sites/}. */
	public String getSiteName() {
		return siteName;
	}

	public String getSiteId() {
		if (siteId == null) {
			throw new BotCommandException(MESSAGES.getString("sessionClosed"));
		}
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public HttpClient getHttpClient() {
		return httpClient;
	}

	/** The current bearer token, refreshed first when it is about to expire. */
	public String accessToken() {
		if (closed) {
			throw new BotCommandException(MESSAGES.getString("sessionClosed"));
		}
		if (needsRefresh()) {
			refresh();
		}
		return accessToken;
	}

	private boolean needsRefresh() {
		Instant expiry = tokenExpiry;
		return accessToken == null || expiry == null || Instant.now().plus(REFRESH_WINDOW).isAfter(expiry);
	}

	private void refresh() {
		tokenLock.lock();
		try {
			if (!needsRefresh()) {
				return;
			}
			String secret = readClientSecret();
			GraphTokenClient.TokenResult token = GraphTokenClient.request(httpClient, tenantId, clientId, secret);
			this.accessToken = token.accessToken();
			this.tokenExpiry = token.expiresAt();
		} finally {
			tokenLock.unlock();
		}
	}

	/** Reads the secret at the moment it is needed and wipes the temporary character buffer. */
	private String readClientSecret() {
		if (clientSecret == null) {
			throw new BotCommandException(MESSAGES.getString("clientSecretRequired"));
		}
		StringBuilder secret = new StringBuilder();
		clientSecret.accessChars(chars -> {
			try {
				secret.append(chars);
			} finally {
				Arrays.fill(chars, '\0');
			}
		});
		if (secret.length() == 0) {
			String plain = clientSecret.getInsecureString();
			if (plain != null) {
				secret.append(plain);
			}
		}
		if (secret.length() == 0) {
			throw new BotCommandException(MESSAGES.getString("clientSecretUnavailable"));
		}
		return secret.toString();
	}

	@Override
	public boolean isClosed() {
		return closed;
	}

	@Override
	public void close() {
		closed = true;
		accessToken = null;
		tokenExpiry = null;
		siteId = null;
	}
}
