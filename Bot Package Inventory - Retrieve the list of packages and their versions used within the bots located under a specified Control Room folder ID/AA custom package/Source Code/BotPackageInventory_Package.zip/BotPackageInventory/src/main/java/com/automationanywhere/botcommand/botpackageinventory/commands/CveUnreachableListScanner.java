/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.commands;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.automationanywhere.botcommand.data.Value;
import com.automationanywhere.botcommand.data.impl.StringValue;
import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.botcommand.botpackageinventory.helpers.CveReportBuilder;
import com.automationanywhere.botcommand.botpackageinventory.helpers.ReportLogger;
import com.automationanywhere.commandsdk.annotations.BotCommand;
import com.automationanywhere.commandsdk.annotations.CommandPkg;
import com.automationanywhere.commandsdk.annotations.Execute;
import com.automationanywhere.commandsdk.annotations.Idx;
import com.automationanywhere.commandsdk.annotations.Pkg;
import com.automationanywhere.commandsdk.annotations.rules.FileFolder;
import com.automationanywhere.commandsdk.annotations.rules.LocalFile;
import com.automationanywhere.commandsdk.annotations.rules.NotEmpty;
import com.automationanywhere.commandsdk.i18n.Messages;
import com.automationanywhere.commandsdk.i18n.MessagesFactory;

import static com.automationanywhere.commandsdk.model.AttributeType.FILE;
import static com.automationanywhere.commandsdk.model.DataType.STRING;

/**
 * Compares the packages found by {@code Trace Packages and Commands} (PackageReport.xlsx) with the
 * Control Room unreachable findings report and writes CVEBotReport.xlsx:
 *
 * <ul>
 * <li>"CVE Summary" - one row per CVE per package, with the unreachable versions and bot counts</li>
 * <li>"CVE-wise report" - CVE &gt; artifact name &gt; bots</li>
 * <li>"Bot-wise report" - bot &gt; package &gt; CVEs</li>
 * </ul>
 *
 * <p>Both reports must sit in the same folder: PackageReport.xlsx is read from it and the newest
 * "unreachable_findings_report*.xlsx" of that folder is picked up automatically. The run summary
 * is returned as JSON.</p>
 */
@BotCommand
@CommandPkg(
		name = "cveUnreachableListScanner", label = "[[CveUnreachableListScanner.label]]",
		node_label = "[[CveUnreachableListScanner.node_label]]",
		description = "[[CveUnreachableListScanner.description]]", icon = "pkg.svg",
		return_label = "[[CveUnreachableListScanner.return_label]]", return_type = STRING, return_required = true)
public class CveUnreachableListScanner {

	private static final Messages MESSAGES = MessagesFactory
			.getMessages("com.automationanywhere.botcommand.botpackageinventory.messages");

	@Execute
	public Value<String> action(
			@Idx(index = "1", type = FILE)
			@Pkg(label = "[[CveUnreachableListScanner.folderPath.label]]",
					description = "[[CveUnreachableListScanner.folderPath.description]]")
			@NotEmpty
			@LocalFile
			@FileFolder
			String folderPath) {

		Path folder = resolveFolder(folderPath);

		try (ReportLogger log = new ReportLogger(folder.resolve(CveReportBuilder.LOG_FILE_NAME),
				ReportLogger.Level.DEBUG)) {

			log.info("action", "Log file started.");
			log.debug("action", "cve_unreachable_list_scanner called with folder: " + folder);

			CveReportBuilder builder = new CveReportBuilder(folder, log);
			String summary = builder.build();

			log.info("action", "CVE report finished. Summary: " + summary);
			return new StringValue(summary);
		} catch (BotCommandException e) {
			throw e;
		} catch (IOException e) {
			throw new BotCommandException(MESSAGES.getString("cveReportFailed", folderPath, e.getMessage()));
		}
	}

	private static Path resolveFolder(String folderPath) {
		String cleaned = folderPath == null ? "" : folderPath.trim().replaceAll("^\"|\"$", "");
		if (cleaned.isEmpty()) {
			throw new BotCommandException(MESSAGES.getString("emptyInputString", "folderPath"));
		}

		Path folder = Paths.get(cleaned);
		if (!Files.isDirectory(folder)) {
			throw new BotCommandException(MESSAGES.getString("invalidOutputFolder", cleaned));
		}
		return folder;
	}
}
