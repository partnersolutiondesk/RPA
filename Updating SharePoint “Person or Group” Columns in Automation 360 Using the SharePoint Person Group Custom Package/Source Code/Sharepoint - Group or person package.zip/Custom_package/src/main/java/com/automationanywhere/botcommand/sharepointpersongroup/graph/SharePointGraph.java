package com.automationanywhere.botcommand.sharepointpersongroup.graph;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.botcommand.sharepointpersongroup.logic.PersonFieldLogic;
import com.automationanywhere.botcommand.sharepointpersongroup.session.GraphSession;
import com.automationanywhere.commandsdk.i18n.Messages;
import com.automationanywhere.commandsdk.i18n.MessagesFactory;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/**
 * The SharePoint side of Microsoft Graph: resolve a site, a list, a column and a person, and write
 * the fields of a list item.
 *
 * <p>Every failure is turned into a {@link BotCommandException} with a message a bot developer can
 * act on. The client secret and the access token never appear in any of them.</p>
 */
public class SharePointGraph {

	private static final Messages MESSAGES = MessagesFactory
			.getMessages("com.automationanywhere.botcommand.sharepointpersongroup.messages");

	/** Hidden list that holds the numeric lookup ID of every person and group known to the site. */
	public static final String USER_INFORMATION_LIST = "User Information List";

	/** Lets Graph run a query on a column that is not indexed, instead of failing it. */
	private static final Map<String, String> ALLOW_NON_INDEXED = Collections
			.singletonMap("Prefer", "HonorNonIndexedQueriesWarningMayFailRandomly");

	private static final String FIELD_SELECT = "fields($select=EMail,Title)";

	private final GraphSession session;
	private final GraphHttp http;

	public SharePointGraph(GraphSession session) {
		this.session = session;
		this.http = new GraphHttp(session);
	}

	/** Resolves the site ID and returns it. Empty site name means the root site. */
	public String resolveSiteId() {
		String host = session.getSharePointHost();
		String siteName = session.getSiteName();
		StringBuilder url = new StringBuilder(GraphHttp.url("/sites/")).append(host);
		if (!siteName.isEmpty()) {
			url.append(":/sites/").append(GraphHttp.urlEncode(stripSlashes(siteName)));
		}
		JsonObject site;
		try {
			site = http.get(url.toString(), null);
		} catch (GraphException e) {
			throw failure(e, "siteNotFound", host, siteName);
		}
		if (!site.has("id") || site.get("id").isJsonNull()) {
			throw new BotCommandException(MESSAGES.getString("siteNotFound", host, siteName,
					"The response did not contain a site ID."));
		}
		return site.get("id").getAsString();
	}

	/** Finds the list ID from the display name or the internal name. */
	public String resolveListId(String listName) {
		String url = GraphHttp.url("/sites/" + session.getSiteId() + "/lists") + "?$select=id,displayName,name";
		List<JsonElement> lists;
		try {
			lists = http.getAll(url, null);
		} catch (GraphException e) {
			throw failure(e);
		}
		for (JsonElement element : lists) {
			JsonObject list = element.getAsJsonObject();
			if (PersonFieldLogic.nameMatches(listName, text(list, "displayName"), text(list, "name"))) {
				return text(list, "id");
			}
		}
		throw new BotCommandException(MESSAGES.getString("listNotFound", listName));
	}

	/**
	 * Finds a column by display name or internal name and reads whether it holds more than one
	 * person or group.
	 *
	 * @param requirePersonGroup when true the column must be a Person or Group column
	 */
	public ColumnInfo resolveColumn(String listId, String listName, String columnName, boolean requirePersonGroup) {
		for (JsonElement element : columns(listId)) {
			JsonObject column = element.getAsJsonObject();
			String internalName = text(column, "name");
			String displayName = text(column, "displayName");
			if (!PersonFieldLogic.nameMatches(columnName, displayName, internalName)) {
				continue;
			}
			boolean personOrGroup = column.has("personOrGroup") && column.get("personOrGroup").isJsonObject();
			if (!personOrGroup && requirePersonGroup) {
				throw new BotCommandException(MESSAGES.getString("columnNotPersonGroup", columnName, listName));
			}
			boolean multiple = false;
			if (personOrGroup) {
				JsonObject facet = column.getAsJsonObject("personOrGroup");
				multiple = facet.has("allowMultipleSelection") && !facet.get("allowMultipleSelection").isJsonNull()
						&& facet.get("allowMultipleSelection").getAsBoolean();
			}
			return new ColumnInfo(internalName, displayName, personOrGroup, multiple);
		}
		throw new BotCommandException(MESSAGES.getString("columnNotFound", columnName, listName));
	}

	/**
	 * Finds the IDs of the items whose column equals the given value. The filtered query is tried
	 * first; when SharePoint refuses it because the column is not indexed, the list is paged and
	 * matched in code.
	 */
	public List<String> findItemIds(String listId, String internalColumn, String value) {
		String base = GraphHttp.url("/sites/" + session.getSiteId() + "/lists/" + listId + "/items");
		String select = "fields($select=" + internalColumn + ")";
		String filter = "fields/" + internalColumn + " eq '" + PersonFieldLogic.escapeODataString(value) + "'";
		String filtered = base + "?$filter=" + GraphHttp.urlEncode(filter)
				+ "&$expand=" + GraphHttp.urlEncode(select) + "&$select=id";

		List<String> ids = new ArrayList<>();
		JsonObject page;
		try {
			page = http.getOrNull(filtered, ALLOW_NON_INDEXED);
		} catch (GraphException e) {
			throw failure(e);
		}
		if (page != null) {
			collectIds(page, ids);
			return ids;
		}

		String paged = base + "?$expand=" + GraphHttp.urlEncode(select) + "&$select=id&$top=999";
		List<JsonElement> items;
		try {
			items = http.getAll(paged, ALLOW_NON_INDEXED);
		} catch (GraphException e) {
			throw failure(e);
		}
		for (JsonElement element : items) {
			JsonObject item = element.getAsJsonObject();
			if (value.equalsIgnoreCase(fieldText(item, internalColumn))) {
				ids.add(text(item, "id"));
			}
		}
		return ids;
	}

	/**
	 * Resolves the numeric lookup ID of a user or group in the site's User Information List. A value
	 * containing {@code @} is matched on the email address, everything else on the title, which also
	 * covers SharePoint groups.
	 */
	public String resolveUserLookupId(String person) {
		String base = userInformationListItemsUrl(session.getSiteId());
		String field = PersonFieldLogic.lookupFieldFor(person);
		String filter = "fields/" + field + " eq '" + PersonFieldLogic.escapeODataString(person) + "'";
		String filtered = base + "?$filter=" + GraphHttp.urlEncode(filter)
				+ "&$expand=" + GraphHttp.urlEncode(FIELD_SELECT) + "&$select=id";

		JsonObject page;
		try {
			page = http.getOrNull(filtered, ALLOW_NON_INDEXED);
		} catch (GraphException e) {
			throw failure(e, "userInformationListUnavailable");
		}
		if (page != null && page.has("value") && page.get("value").isJsonArray()) {
			List<String> ids = new ArrayList<>();
			collectIds(page, ids);
			if (!ids.isEmpty()) {
				return ids.get(0);
			}
		}

		String paged = base + "?$expand=" + GraphHttp.urlEncode(FIELD_SELECT) + "&$select=id&$top=999";
		List<JsonElement> entries;
		try {
			entries = http.getAll(paged, ALLOW_NON_INDEXED);
		} catch (GraphException e) {
			throw failure(e, "userInformationListUnavailable");
		}
		for (JsonElement element : entries) {
			JsonObject entry = element.getAsJsonObject();
			if (person.equalsIgnoreCase(fieldText(entry, field))) {
				return text(entry, "id");
			}
		}
		throw new BotCommandException(MESSAGES.getString("personNotFound", person));
	}

	/**
	 * The hidden User Information List is addressed by name in SharePoint style quotes, exactly as
	 * the reference script does: {@code lists('User Information List')/items}.
	 *
	 * <p>The quote characters must stay literal, because Microsoft Graph reads them as part of the
	 * list key; percent encoding them makes Graph look for a list whose name starts with a quote and
	 * it answers 404 "The specified list was not found". Only the spaces are encoded, because a space
	 * is not legal in a URI path and the request would otherwise never leave the bot agent.</p>
	 */
	static String userInformationListItemsUrl(String siteId) {
		return GraphHttp.url(
				"/sites/" + siteId + "/lists('" + GraphHttp.urlEncode(USER_INFORMATION_LIST) + "')/items");
	}

	/** Writes the given fields to one list item and returns the item ID. */
	public String patchItemFields(String listId, String itemId, Map<String, Object> body) {
		String url = GraphHttp.url("/sites/" + session.getSiteId() + "/lists/" + listId + "/items/" + itemId + "/fields");
		try {
			http.patch(url, null, body);
		} catch (GraphException e) {
			throw failure(e, "itemUpdateFailed", itemId);
		}
		return itemId;
	}

	private List<JsonElement> columns(String listId) {
		String url = GraphHttp.url("/sites/" + session.getSiteId() + "/lists/" + listId + "/columns");
		try {
			return http.getAll(url, null);
		} catch (GraphException e) {
			throw failure(e);
		}
	}

	private static void collectIds(JsonObject page, List<String> ids) {
		if (!page.has("value") || !page.get("value").isJsonArray()) {
			return;
		}
		for (JsonElement element : page.getAsJsonArray("value")) {
			JsonObject item = element.getAsJsonObject();
			if (item.has("id") && !item.get("id").isJsonNull()) {
				ids.add(item.get("id").getAsString());
			}
		}
	}

	private static String fieldText(JsonObject item, String field) {
		if (!item.has("fields") || !item.get("fields").isJsonObject()) {
			return "";
		}
		JsonObject fields = item.getAsJsonObject("fields");
		if (!fields.has(field) || fields.get(field).isJsonNull()) {
			return "";
		}
		return fields.get(field).getAsString();
	}

	private static String text(JsonObject object, String member) {
		return object.has(member) && !object.get(member).isJsonNull() ? object.get(member).getAsString() : "";
	}

	private static String stripSlashes(String value) {
		return value.replaceAll("^/+", "").replaceAll("/+$", "");
	}

	/** Turns a transport failure into a message that names the thing the bot was looking for. */
	private static BotCommandException failure(GraphException e, String messageKey, Object... context) {
		if (e.isAccessDenied() || e.isUnreachable()) {
			return failure(e);
		}
		Object[] arguments = Arrays.copyOf(context, context.length + 1);
		arguments[context.length] = e.getDetail();
		return new BotCommandException(MESSAGES.getString(messageKey, arguments));
	}

	private static BotCommandException failure(GraphException e) {
		if (e.isAccessDenied()) {
			return new BotCommandException(MESSAGES.getString("accessDenied", e.getStatus(), e.getDetail()));
		}
		if (e.isUnreachable()) {
			return new BotCommandException(MESSAGES.getString("graphUnreachable", "Microsoft Graph", e.getDetail()));
		}
		return new BotCommandException(MESSAGES.getString("graphRequestFailed", e.getStatus(), e.getDetail()));
	}
}
