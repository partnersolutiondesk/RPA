/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.helpers;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

/**
 * Sorts more rows than fit in memory. Rows are collected in memory, sorted and written to a run file
 * as soon as the buffer is full; the sorted runs are then merged into one sorted file.
 *
 * <p>This replaces the temporary SQLite database the original script used, so the CVE report can be
 * produced for a very large package report without holding it in memory.</p>
 */
public final class TsvSorter {

	private final Path dir;
	private final String prefix;
	private final int rowsPerRun;
	private final Comparator<List<String>> comparator;
	private final List<List<String>> buffer = new ArrayList<>();
	private final List<Path> runs = new ArrayList<>();

	private int runSequence;
	private Path sortedFile;

	public TsvSorter(Path dir, String prefix, int rowsPerRun, Comparator<List<String>> comparator) {
		this.dir = dir;
		this.prefix = prefix;
		this.rowsPerRun = rowsPerRun;
		this.comparator = comparator;
	}

	/** Adds a row; the rows are sorted as soon as enough of them have been collected. */
	public void add(List<String> row) throws IOException {
		buffer.add(row);
		if (buffer.size() >= rowsPerRun) {
			spill();
		}
	}

	/**
	 * Sorts and merges everything that was added and returns the sorted file. The file stays until
	 * the work folder of the run is removed.
	 */
	public Path finish() throws IOException {
		if (sortedFile != null) {
			return sortedFile;
		}
		spill();

		if (runs.isEmpty()) {
			sortedFile = dir.resolve(prefix + "-sorted.tsv");
			Files.write(sortedFile, new byte[0]);
			return sortedFile;
		}
		if (runs.size() == 1) {
			sortedFile = runs.get(0);
			return sortedFile;
		}

		sortedFile = merge();
		for (Path run : runs) {
			Files.deleteIfExists(run);
		}
		return sortedFile;
	}

	/** Writes the rows collected so far to a sorted run file. */
	private void spill() throws IOException {
		if (buffer.isEmpty()) {
			return;
		}
		buffer.sort(comparator);
		Path run = dir.resolve(prefix + "-run-" + (runSequence++) + ".tsv");
		try (TsvFile.Writer writer = new TsvFile.Writer(run)) {
			for (List<String> row : buffer) {
				writer.write(row);
			}
		}
		buffer.clear();
		runs.add(run);
	}

	/** Merges the sorted runs into one sorted file. */
	private Path merge() throws IOException {
		Path merged = dir.resolve(prefix + "-sorted.tsv");
		List<Cursor> cursors = new ArrayList<>(runs.size());
		PriorityQueue<Cursor> queue = new PriorityQueue<>();

		try {
			for (int index = 0; index < runs.size(); index++) {
				Cursor cursor = new Cursor(new TsvFile.Reader(runs.get(index)), index);
				cursors.add(cursor);
				if (cursor.advance()) {
					queue.add(cursor);
				}
			}
			try (TsvFile.Writer writer = new TsvFile.Writer(merged)) {
				while (!queue.isEmpty()) {
					Cursor cursor = queue.poll();
					writer.write(cursor.row);
					if (cursor.advance()) {
						queue.add(cursor);
					}
				}
			}
		} finally {
			for (Cursor cursor : cursors) {
				cursor.closeQuietly();
			}
		}
		return merged;
	}

	/** One sorted run being read during the merge. */
	private final class Cursor implements Comparable<Cursor> {

		private final TsvFile.Reader reader;
		private final int run;

		private List<String> row;

		Cursor(TsvFile.Reader reader, int run) {
			this.reader = reader;
			this.run = run;
		}

		boolean advance() throws IOException {
			row = reader.read();
			return row != null;
		}

		void closeQuietly() {
			try {
				reader.close();
			} catch (IOException ignored) {
				// The merge result is what matters; a read that cannot be closed is left to the GC.
			}
		}

		@Override
		public int compareTo(Cursor other) {
			int result = comparator.compare(row, other.row);
			return result != 0 ? result : Integer.compare(run, other.run);
		}
	}
}
