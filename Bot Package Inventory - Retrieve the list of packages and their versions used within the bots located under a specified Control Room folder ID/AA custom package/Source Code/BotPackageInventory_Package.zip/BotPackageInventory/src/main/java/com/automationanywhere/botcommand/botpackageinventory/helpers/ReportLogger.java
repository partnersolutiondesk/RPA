/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.helpers;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Writes the execution log of the scan next to the generated report and mirrors every entry to the
 * bot execution log, so the run can be followed from either side.
 *
 * <p>Never pass credentials (API key or token) to this logger.</p>
 */
public class ReportLogger implements Closeable {

	public enum Level {
		TRACE, DEBUG, INFO, WARN, ERROR;

		boolean includes(Level level) {
			return level.ordinal() >= this.ordinal();
		}
	}

	private static final DateTimeFormatter TIMESTAMP_FORMAT =
			DateTimeFormatter.ofPattern("dd-MM-yyyy hh.mm.ss a", Locale.ENGLISH);
	private static final Logger AA_LOGGER = LogManager.getLogger("BotPackageInventory");

	private final BufferedWriter fileLog;
	private final Level threshold;

	public ReportLogger(Path logFile, Level threshold) throws IOException {
		this.threshold = threshold;
		this.fileLog = Files.newBufferedWriter(logFile, StandardCharsets.UTF_8,
				StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
	}

	public void trace(String caller, String message) {
		write(Level.TRACE, caller, message);
	}

	public void debug(String caller, String message) {
		write(Level.DEBUG, caller, message);
	}

	public void info(String caller, String message) {
		write(Level.INFO, caller, message);
	}

	public void warn(String caller, String message) {
		write(Level.WARN, caller, message);
	}

	public void error(String caller, String message) {
		write(Level.ERROR, caller, message);
	}

	private synchronized void write(Level level, String caller, String message) {
		if (threshold.includes(level)) {
			try {
				fileLog.write("(" + LocalDateTime.now().format(TIMESTAMP_FORMAT) + ") " + level + " BotPackageInventory ("
						+ caller + "): " + message);
				fileLog.newLine();
				fileLog.flush();
			} catch (IOException e) {
				AA_LOGGER.warn("Unable to write to the package scanner log: " + e.getMessage());
			}
		}
		switch (level) {
			case ERROR:
				AA_LOGGER.error(message);
				break;
			case WARN:
				AA_LOGGER.warn(message);
				break;
			case INFO:
				AA_LOGGER.info(message);
				break;
			default:
				AA_LOGGER.debug(message);
				break;
		}
	}

	@Override
	public void close() throws IOException {
		fileLog.close();
	}
}
