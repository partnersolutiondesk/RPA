/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.helpers;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * Builds {@code CVEBotReport.xlsx} from the package report of the scan action and the unreachable
 * findings report of the Control Room: for every CVE it takes the packages and the unreachable
 * versions tagged to it, finds the bots using those packages and reports whether the version of the
 * bot is one of the unreachable ones.
 *
 * <p>Sheets of the report:</p>
 * <ul>
 * <li>"CVE Summary" - one row per CVE per package, with the unreachable versions and the bot counts
 * per status</li>
 * <li>"CVE-wise report" - CVE (main row) &gt; artifact name &gt; bots</li>
 * <li>"Bot-wise report" - bot (main row) &gt; package &gt; CVEs, so every package of a bot is
 * listed</li>
 * </ul>
 *
 * <p>Built for very large inputs: the package report is sorted on disk instead of being kept in
 * memory, every sheet is written as a stream, the grouped sheets can be collapsed with the outline
 * buttons and a full sheet continues on "&lt;name&gt; 2", "&lt;name&gt; 3", ... If the run stops
 * with an error, the rows written so far are still saved and a "Run Status" sheet says that the
 * report is incomplete and why.</p>
 */
public class CveReportBuilder {

	public static final String LOG_FILE_NAME = "cvebotreport.log";

	private static final String PACKAGE_REPORT_FILE = "PackageReport.xlsx";
	private static final String FINDINGS_FILE_PREFIX = "unreachable_findings_report";
	private static final String FORMATTED_SUFFIX = "_formatted.xlsx";
	private static final String OUTPUT_FILE = "CVEBotReport.xlsx";
	private static final String MVN_PREFIX = "mvn://com.automationanywhere.packages:";

	private static final String STATUS_UNREACHABLE = "Unreachable";
	private static final String STATUS_NOT_LISTED = "Not in unreachable list. Upgrade to latest version";
	private static final String STATUS_CHECK = "Check Manually";
	private static final String STATUS_NO_FINDINGS = "No CVE findings";
	private static final String STATUS_NO_ARTIFACT = "Artifact name missing";

	private static final List<String> STATUS_ORDER =
			List.of(STATUS_NOT_LISTED, STATUS_CHECK, STATUS_UNREACHABLE);
	private static final List<String> PACKAGE_STATUS_ORDER =
			List.of(STATUS_NOT_LISTED, STATUS_CHECK, STATUS_UNREACHABLE, STATUS_NO_FINDINGS, STATUS_NO_ARTIFACT);

	private static final List<Object> SUMMARY_HEADER = List.<Object>of(
			"CVE", "Severity", "Artifact Name", "Package", "CVE's version", "Bots Using Package",
			STATUS_NOT_LISTED, STATUS_CHECK, STATUS_UNREACHABLE);
	private static final double[] SUMMARY_WIDTHS = {18, 11, 32, 22, 24, 18, 50, 16, 14};

	private static final List<Object> GROUPED_HEADER = List.<Object>of(
			"CVE", "Artifact Name", "Bot Id", "Bot Name", "Bot Path", "Package", "CVE's version",
			"Package version in bot", "Status", "Summary / Notes");
	private static final double[] GROUPED_WIDTHS = {18, 32, 14, 32, 70, 22, 24, 24, 50, 70};

	private static final List<Object> BOT_GROUPED_HEADER = List.<Object>of(
			"Bot Id", "Bot Name", "Bot Path", "Package", "Artifact Name", "Package version in bot",
			"CVE", "Severity", "CVE's version", "Status", "Summary / Notes");
	private static final double[] BOT_GROUPED_WIDTHS = {14, 32, 70, 22, 32, 24, 18, 11, 24, 50, 70};

	private static final Pattern CVE_PATTERN = Pattern.compile("CVE-\\d+-\\d+", Pattern.CASE_INSENSITIVE);
	private static final Pattern VERSION_PATTERN = Pattern.compile("\\s*v?(\\d+(?:\\.\\d+)+)");

	private static final String[] PACKAGE_COLUMNS =
			{"Bot Id", "Bot Name", "Bot Path", "Package", "Artifact Name", "Version", "Commands Used"};

	/** Rows held in memory before a sorted run is written to disk. */
	private static final int ROWS_PER_SORT_RUN = 25_000;

	private static final Comparator<List<String>> BY_ARTIFACT =
			Comparator.comparing((List<String> row) -> row.get(0))
					.thenComparing(row -> row.get(3))
					.thenComparing(row -> row.get(2))
					.thenComparing(row -> row.get(1));
	private static final Comparator<List<String>> BY_BOT =
			Comparator.comparing((List<String> row) -> row.get(2))
					.thenComparing(row -> row.get(1))
					.thenComparing(row -> row.get(0))
					.thenComparing(row -> row.get(3));

	private static final DateTimeFormatter RUN_TIME = DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm:ss a", Locale.ENGLISH);
	private static final DateTimeFormatter FALLBACK_NAME = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss", Locale.ENGLISH);
	private static final ObjectMapper MAPPER = new ObjectMapper();

	private final Path folder;
	private final ReportLogger log;

	private Path outputPath;
	private int packageRows;
	private int cveWiseBotRows;

	public CveReportBuilder(Path folder, ReportLogger log) {
		this.folder = folder;
		this.log = log;
	}

	/**
	 * Builds the report and returns a JSON summary of the run. The newest
	 * "unreachable_findings_report*.xlsx" of the folder is used.
	 */
	public String build() throws IOException {
		long started = System.currentTimeMillis();
		Path findingsPath = locateFindings();
		log.info("build", "Using findings report " + findingsPath);

		Findings findings = loadFindings(findingsPath);
		log.info("build", "Findings: " + findings.cves.size() + " CVEs, " + findings.pairs() + " CVE and package combinations");

		Map<String, ReleaseInfo> infos = new LinkedHashMap<>();
		Map<String, List<String>> cvesByArtifact = buildReleaseInfos(findings, infos);

		Path workFolder = Files.createTempDirectory("cvebotreport-work-");
		try {
			PackageIndex index = indexPackageReport(workFolder);
			Map<String, int[]> counts = countStatuses(findings, infos, index.histograms);
			log.info("build", "Compared " + infos.size() + " CVE and package combinations");

			outputPath = folder.resolve(OUTPUT_FILE);
			Throwable failure = null;
			try (StreamingXlsxWriter writer = new StreamingXlsxWriter(outputPath, workFolder.resolve("parts"))) {
				try {
					fillWorkbook(writer, findings, infos, counts, index, cvesByArtifact);
				} catch (Exception e) {
					failure = e;
					log.error("build", "Stopped before the report was finished. The rows written so far are saved: "
							+ describe(e));
					addRunStatusSheet(writer, e);
				}
				saveWorkbook(writer);
			}
			log.info("build", "Report saved to " + outputPath + (failure == null ? "" : " (INCOMPLETE)"));
			if (failure != null) {
				throw failure instanceof IOException ? (IOException) failure : new IOException(describe(failure), failure);
			}
		} finally {
			deleteTree(workFolder);
		}

		log.info("build", "Finished in " + ((System.currentTimeMillis() - started) / 1000) + "s: " + packageRows
				+ " package rows, " + findings.cves.size() + " CVEs, report " + outputPath);

		ObjectNode summary = MAPPER.createObjectNode();
		summary.put("status", "OK");
		summary.put("packageReportRows", packageRows);
		summary.put("cves", findings.cves.size());
		summary.put("cvePackagePairs", findings.pairs());
		summary.put("cveWiseBotRows", cveWiseBotRows);
		summary.put("reportPath", outputPath.toString());
		return summary.toString();
	}

	/** Finds the findings report: the newest "unreachable_findings_report*.xlsx" of the folder. */
	private Path locateFindings() throws IOException {
		Path newest = null;
		FileTime newestTime = null;
		try (DirectoryStream<Path> stream =
					 Files.newDirectoryStream(folder, FINDINGS_FILE_PREFIX + "*.xlsx")) {
			for (Path candidate : stream) {
				String name = candidate.getFileName().toString().toLowerCase(Locale.ROOT);
				// The *_formatted.xlsx copy is only for reading by people, so it is not picked up
				if (name.endsWith(FORMATTED_SUFFIX) || !Files.isRegularFile(candidate)) {
					continue;
				}
				FileTime modified = Files.getLastModifiedTime(candidate);
				if (newestTime == null || modified.compareTo(newestTime) > 0) {
					newest = candidate;
					newestTime = modified;
				}
			}
		}
		if (newest == null) {
			throw new IOException("No file matching " + FINDINGS_FILE_PREFIX + "*.xlsx was found in " + folder);
		}
		return newest;
	}

	/**
	 * Reads the findings report and returns the unreachable versions of every CVE and package,
	 * together with the severity of every CVE. Every row is used, including "master" rows.
	 */
	private Findings loadFindings(Path file) throws IOException {
		Findings findings = new Findings();
		try (XlsxReader reader = XlsxReader.open(file)) {
			List<String> sheets = reader.sheetNames();
			if (sheets.isEmpty()) {
				throw new IOException("The findings report '" + file + "' has no sheet");
			}
			Iterator<List<String>> rows = reader.rows(sheets.get(0));
			if (!rows.hasNext()) {
				throw new IOException("The findings report '" + file + "' is empty");
			}

			List<String> header = new ArrayList<>();
			for (String cell : rows.next()) {
				header.add(cell == null ? "" : cell.trim());
			}
			int cveColumn = header.indexOf("CVE");
			int packageColumn = header.indexOf("Package Name");
			int severityColumn = header.indexOf("Severity Level");
			if (cveColumn < 0) {
				throw new IOException("Column \"CVE\" was not found in " + file);
			}
			if (packageColumn < 0) {
				throw new IOException("Column \"Package Name\" was not found in " + file);
			}

			int rowsRead = 0;
			int skippedVersions = 0;
			while (rows.hasNext()) {
				List<String> row = rows.next();
				rowsRead++;

				List<String> cves = new ArrayList<>();
				Matcher matcher = CVE_PATTERN.matcher(cell(row, cveColumn));
				while (matcher.find()) {
					cves.add(matcher.group().toUpperCase(Locale.ROOT));
				}

				// A Package Name cell can carry stray new lines or more than one entry
				for (String entry : cell(row, packageColumn).split("\n")) {
					entry = entry.trim();
					if (!entry.startsWith(MVN_PREFIX)) {
						continue;
					}
					int separator = entry.indexOf('@', MVN_PREFIX.length());
					if (separator < 0) {
						continue;
					}
					String artifact = entry.substring(MVN_PREFIX.length(), separator);
					String versionText = entry.substring(separator + 1);
					Version unreachable = Version.parse(versionText);
					if (unreachable == null) {
						skippedVersions++;
						log.warn("loadFindings", "Skipping finding with unreadable version '" + versionText + "' for " + cves);
						continue;
					}
					for (String cve : cves) {
						findings.add(cve, artifact, unreachable);
						String severity = cell(row, severityColumn);
						if (!severity.isEmpty()) {
							findings.setSeverity(cve, titleCase(severity.replace("FINDING_LEVEL_", "")));
						}
					}
				}
			}
			log.info("loadFindings", "Read " + rowsRead + " rows, skipped " + skippedVersions
					+ " entries with an unreadable version");
		}
		return findings;
	}

	/** The unreachable versions of every CVE and package, and the CVEs tagged to each package. */
	private static Map<String, List<String>> buildReleaseInfos(Findings findings, Map<String, ReleaseInfo> infos) {
		Map<String, List<String>> cvesByArtifact = new LinkedHashMap<>();
		for (String cve : sortedCves(findings)) {
			for (String artifact : sortedArtifacts(findings, cve)) {
				infos.put(key(cve, artifact), new ReleaseInfo(findings.cves.get(cve).get(artifact)));
				cvesByArtifact.computeIfAbsent(artifact, name -> new ArrayList<>()).add(cve);
			}
		}
		return cvesByArtifact;
	}

	/**
	 * Reads the package report, sorts it on disk by artifact and by bot, and returns the version
	 * counts per package.
	 */
	private PackageIndex indexPackageReport(Path workFolder) throws IOException {
		Path report = folder.resolve(PACKAGE_REPORT_FILE);
		if (!Files.isRegularFile(report)) {
			throw new IOException("The package report '" + report + "' was not found. Run the package scan action first");
		}

		PackageIndex index = new PackageIndex();
		TsvSorter byArtifact = new TsvSorter(workFolder, "artifact", ROWS_PER_SORT_RUN, BY_ARTIFACT);
		TsvSorter byBot = new TsvSorter(workFolder, "bot", ROWS_PER_SORT_RUN, BY_BOT);

		try (XlsxReader reader = XlsxReader.open(report)) {
			List<String> sheets = new ArrayList<>();
			for (String name : reader.sheetNames()) {
				if (name.startsWith("Full Report")) {
					sheets.add(name);
				}
			}
			if (sheets.isEmpty()) {
				throw new IOException("Sheet \"Full Report\" was not found in " + report);
			}

			for (String sheet : sheets) {
				Iterator<List<String>> rows = reader.rows(sheet);
				if (!rows.hasNext()) {
					continue;
				}
				int[] columns = packageColumns(rows.next(), sheet, report);
				log.info("indexPackageReport", "Reading sheet " + sheet);

				while (rows.hasNext()) {
					List<String> row = rows.next();
					if (!hasContent(row)) {
						continue;
					}
					String botId = cell(row, columns[0]);
					String botName = cell(row, columns[1]);
					String botPath = cell(row, columns[2]);
					String packageName = cell(row, columns[3]);
					String artifact = cell(row, columns[4]).trim();
					String version = cell(row, columns[5]);

					byArtifact.add(List.of(artifact, botId, botName, botPath, packageName, version));
					byBot.add(List.of(botId, botName, botPath, packageName, artifact, version));

					index.histograms.computeIfAbsent(artifact, name -> new LinkedHashMap<>())
							.merge(version, 1, Integer::sum);
					index.packageNames.putIfAbsent(artifact, packageName);
					packageRows++;
				}
			}
		} catch (ZipException e) {
			// A half-written workbook cannot be read: tell the user how to fix it instead of
			// showing the raw "zip END header not found".
			throw new IOException("The package report '" + report + "' is incomplete or damaged. "
					+ "Run the package scan action (Trace Packages and Commands) again to rebuild it", e);
		}
		log.info("indexPackageReport", "Package report: " + packageRows + " rows, "
				+ index.histograms.size() + " artifacts");

		index.sortedByArtifact = byArtifact.finish();
		index.sortedByBot = byBot.finish();

		// The rows of one artifact are next to each other, so the byte offset of each group is kept
		try (TsvFile.RandomReader sorted = new TsvFile.RandomReader(index.sortedByArtifact)) {
			String previous = null;
			long[] group = null;
			while (true) {
				long offset = sorted.position();
				List<String> row = sorted.read();
				if (row == null) {
					break;
				}
				String artifact = row.get(0);
				if (!artifact.equals(previous)) {
					group = new long[]{offset, 0};
					index.offsets.put(artifact, group);
					previous = artifact;
				}
				group[1]++;
			}
		}
		return index;
	}

	/** The bot counts per status for every CVE and package, from the version counts. */
	private static Map<String, int[]> countStatuses(Findings findings, Map<String, ReleaseInfo> infos,
			Map<String, Map<String, Integer>> histograms) {
		Map<String, int[]> counts = new HashMap<>();
		for (Map.Entry<String, Map<String, Set<Version>>> byCve : findings.cves.entrySet()) {
			for (String artifact : byCve.getValue().keySet()) {
				ReleaseInfo info = infos.get(key(byCve.getKey(), artifact));
				int[] statusCounts = new int[PACKAGE_STATUS_ORDER.size()];
				Map<String, Integer> histogram = histograms.get(artifact);
				if (histogram != null) {
					for (Map.Entry<String, Integer> version : histogram.entrySet()) {
						statusCounts[statusRank(evaluate(version.getKey(), info)[0])] += version.getValue();
					}
				}
				counts.put(key(byCve.getKey(), artifact), statusCounts);
			}
		}
		return counts;
	}

	/** Writes the three report sheets. */
	private void fillWorkbook(StreamingXlsxWriter writer, Findings findings, Map<String, ReleaseInfo> infos,
			Map<String, int[]> counts, PackageIndex index, Map<String, List<String>> cvesByArtifact)
			throws IOException {

		List<String> cves = sortedCves(findings);
		StreamingXlsxWriter.Sheet summarySheet =
				writer.addSheet("CVE Summary", SUMMARY_HEADER, SUMMARY_WIDTHS, false);
		for (String cve : cves) {
			for (String artifact : sortedArtifacts(findings, cve)) {
				ReleaseInfo info = infos.get(key(cve, artifact));
				int[] statusCounts = counts.get(key(cve, artifact));
				List<Object> row = new ArrayList<>(SUMMARY_HEADER.size());
				row.add(cve);
				row.add(findings.severity.getOrDefault(cve, ""));
				row.add(artifact);
				row.add(index.packageNames.getOrDefault(artifact, ""));
				row.add(info.text);
				row.add(total(statusCounts));
				for (int status = 0; status < STATUS_ORDER.size(); status++) {
					row.add(statusCounts[status]);
				}
				summarySheet.add(row);
			}
		}

		StreamingXlsxWriter.Sheet groupedSheet =
				writer.addSheet("CVE-wise report", GROUPED_HEADER, GROUPED_WIDTHS, true);
		try (TsvFile.RandomReader sorted = new TsvFile.RandomReader(index.sortedByArtifact)) {
			for (String cve : cves) {
				List<String> artifacts = sortedArtifacts(findings, cve);
				int[] totals = new int[PACKAGE_STATUS_ORDER.size()];
				for (String artifact : artifacts) {
					int[] statusCounts = counts.get(key(cve, artifact));
					for (int status = 0; status < totals.length; status++) {
						totals[status] += statusCounts[status];
					}
				}

				List<Object> mainRow = emptyRow(GROUPED_HEADER.size());
				mainRow.set(0, cve);
				mainRow.set(9, "Severity " + findings.severity.getOrDefault(cve, "n/a") + " | " + artifacts.size()
						+ " packages | " + statusCountsText(totals, "bots"));
				groupedSheet.add(mainRow, 0, StreamingXlsxWriter.STYLE_CVE, true);

				for (String artifact : artifacts) {
					ReleaseInfo info = infos.get(key(cve, artifact));
					int[] statusCounts = counts.get(key(cve, artifact));
					String packageName = index.packageNames.getOrDefault(artifact, "");
					int botsUsing = total(statusCounts);

					List<Object> groupRow = emptyRow(GROUPED_HEADER.size());
					groupRow.set(1, artifact);
					groupRow.set(5, packageName);
					groupRow.set(6, info.text);
					groupRow.set(9, statusCountsText(statusCounts, "bots"));
					groupedSheet.add(groupRow, 1, StreamingXlsxWriter.STYLE_GROUP, false);

					if (botsUsing == 0) {
						continue;
					}
					long[] group = index.offsets.get(artifact);
					if (group == null) {
						continue;
					}
					// Most urgent status first, then the path, so the group is read once per status
					for (int rank = 0; rank < STATUS_ORDER.size(); rank++) {
						sorted.seek(group[0]);
						for (long rowIndex = 0; rowIndex < group[1]; rowIndex++) {
							List<String> row = sorted.read();
							String version = row.get(5);
							String[] result = evaluate(version, info);
							if (statusRank(result[0]) != rank) {
								continue;
							}
							List<Object> botRow = emptyRow(GROUPED_HEADER.size());
							botRow.set(2, row.get(1));
							botRow.set(3, row.get(2));
							botRow.set(4, row.get(3));
							botRow.set(5, packageName);
							botRow.set(6, info.text);
							botRow.set(7, version);
							botRow.set(8, result[0]);
							botRow.set(9, result[1].isEmpty() ? null : result[1]);
							groupedSheet.add(botRow, 2, StreamingXlsxWriter.STYLE_DEFAULT, false);
							cveWiseBotRows++;
							if (cveWiseBotRows % 500_000 == 0) {
								log.info("fillWorkbook", "CVE-wise report: " + cveWiseBotRows + " bot rows written, at " + cve);
							}
						}
					}
				}
			}
		}
		log.info("fillWorkbook", "CVE-wise report done: " + cveWiseBotRows + " bot rows");

		StreamingXlsxWriter.Sheet botSheet = writer.addSheet("Bot-wise report", BOT_GROUPED_HEADER, BOT_GROUPED_WIDTHS, true);
		writeBotWiseSheet(botSheet, findings, infos, index, cvesByArtifact);
	}

	/** Bot (level 0) &gt; package (level 1) &gt; CVE (level 2). One bot at a time is held in memory. */
	private void writeBotWiseSheet(StreamingXlsxWriter.Sheet botSheet, Findings findings,
			Map<String, ReleaseInfo> infos, PackageIndex index, Map<String, List<String>> cvesByArtifact)
			throws IOException {

		Map<String, List<CveRow>> cveRowsCache = new HashMap<>();
		int botsWritten = 0;

		try (TsvFile.Reader sorted = new TsvFile.Reader(index.sortedByBot)) {
			List<String> row = sorted.read();
			while (row != null) {
				String botId = row.get(0);
				String botName = row.get(1);
				String botPath = row.get(2);

				List<List<String>> botRows = new ArrayList<>();
				do {
					botRows.add(row);
					row = sorted.read();
				} while (row != null && row.get(0).equals(botId) && row.get(1).equals(botName)
						&& row.get(2).equals(botPath));

				List<BotEntry> entries = new ArrayList<>(botRows.size());
				for (List<String> botRow : botRows) {
					String packageName = botRow.get(3);
					String artifact = botRow.get(4);
					String version = botRow.get(5);
					if (artifact.isEmpty()) {
						entries.add(new BotEntry(packageName, "", version, STATUS_NO_ARTIFACT, List.of()));
						continue;
					}
					List<CveRow> cveRows = cveRowsFor(artifact, version, findings, infos, cvesByArtifact, cveRowsCache);
					Set<String> statuses = new HashSet<>();
					for (CveRow cveRow : cveRows) {
						statuses.add(cveRow.status);
					}
					entries.add(new BotEntry(packageName, artifact, version, overallStatus(statuses), cveRows));
				}
				entries.sort(Comparator.comparingInt((BotEntry entry) -> PACKAGE_STATUS_ORDER.indexOf(entry.status))
						.thenComparing(entry -> entry.packageName.toLowerCase(Locale.ROOT)));

				int[] packageStatuses = new int[PACKAGE_STATUS_ORDER.size()];
				Set<String> botStatuses = new HashSet<>();
				for (BotEntry entry : entries) {
					packageStatuses[PACKAGE_STATUS_ORDER.indexOf(entry.status)]++;
					botStatuses.add(entry.status);
				}

				List<Object> botRow = emptyRow(BOT_GROUPED_HEADER.size());
				botRow.set(0, botId);
				botRow.set(1, botName);
				botRow.set(2, botPath);
				botRow.set(9, overallStatus(botStatuses));
				botRow.set(10, statusCountsText(packageStatuses, "packages"));
				botSheet.add(botRow, 0, StreamingXlsxWriter.STYLE_CVE, true);

				for (BotEntry entry : entries) {
					int[] cveStatuses = new int[PACKAGE_STATUS_ORDER.size()];
					for (CveRow cveRow : entry.cveRows) {
						cveStatuses[PACKAGE_STATUS_ORDER.indexOf(cveRow.status)]++;
					}
					String summary = entry.cveRows.isEmpty()
							? entry.status : statusCountsText(cveStatuses, "CVEs");

					List<Object> packageRow = emptyRow(BOT_GROUPED_HEADER.size());
					packageRow.set(3, entry.packageName);
					packageRow.set(4, entry.artifact.isEmpty() ? null : entry.artifact);
					packageRow.set(5, entry.version);
					packageRow.set(9, entry.status);
					packageRow.set(10, summary);
					botSheet.add(packageRow, 1, StreamingXlsxWriter.STYLE_GROUP, false);

					for (CveRow cveRow : entry.cveRows) {
						List<Object> cveRowCells = emptyRow(BOT_GROUPED_HEADER.size());
						cveRowCells.set(6, cveRow.cve);
						cveRowCells.set(7, cveRow.severity);
						cveRowCells.set(8, cveRow.versions);
						cveRowCells.set(9, cveRow.status);
						cveRowCells.set(10, cveRow.note.isEmpty() ? null : cveRow.note);
						botSheet.add(cveRowCells, 2, StreamingXlsxWriter.STYLE_DEFAULT, false);
					}
				}

				botsWritten++;
				if (botsWritten % 50_000 == 0) {
					log.info("writeBotWiseSheet", "Bot-wise report: " + botsWritten + " bots written");
				}
			}
		}
		log.info("writeBotWiseSheet", "Bot-wise report done: " + botsWritten + " bots");
	}

	/**
	 * The CVEs tagged to one package, with the status of one package version. The result is the same
	 * for every bot using that version, so it is remembered.
	 */
	private static List<CveRow> cveRowsFor(String artifact, String version, Findings findings,
			Map<String, ReleaseInfo> infos, Map<String, List<String>> cvesByArtifact,
			Map<String, List<CveRow>> cache) {

		String cacheKey = artifact + '\u0000' + version;
		List<CveRow> rows = cache.get(cacheKey);
		if (rows != null) {
			return rows;
		}

		rows = new ArrayList<>();
		for (String cve : cvesByArtifact.getOrDefault(artifact, List.of())) {
			ReleaseInfo info = infos.get(key(cve, artifact));
			String[] result = evaluate(version, info);
			rows.add(new CveRow(cve, findings.severity.getOrDefault(cve, ""), info.text, result[0], result[1]));
		}
		rows.sort(Comparator.comparingInt((CveRow row) -> statusRank(row.status)).thenComparing(row -> row.cve));
		cache.put(cacheKey, rows);
		return rows;
	}

	/**
	 * Checks whether a package version of a bot is one of the unreachable versions of one CVE and
	 * package. The result is remembered per version because the same versions repeat a lot.
	 */
	private static String[] evaluate(String botVersion, ReleaseInfo info) {
		String[] result = info.cache.get(botVersion);
		if (result != null) {
			return result;
		}

		Version version = Version.parse(botVersion);
		if (version == null) {
			result = new String[]{STATUS_CHECK, "Could not read bot version '" + botVersion + "'"};
		} else if (info.versions.contains(version)) {
			result = new String[]{STATUS_UNREACHABLE, ""};
		} else {
			result = new String[]{STATUS_NOT_LISTED, ""};
		}
		info.cache.put(botVersion, result);
		return result;
	}

	/** One status for a package or bot, from the statuses of its CVEs. The most urgent one wins. */
	private static String overallStatus(Set<String> statuses) {
		for (String status : STATUS_ORDER) {
			if (statuses.contains(status)) {
				return status;
			}
		}
		return STATUS_NO_FINDINGS;
	}

	private static String statusCountsText(int[] counts, String noun) {
		StringBuilder text = new StringBuilder();
		for (int status = 0; status < PACKAGE_STATUS_ORDER.size(); status++) {
			if (counts[status] == 0) {
				continue;
			}
			if (text.length() > 0) {
				text.append(", ");
			}
			text.append(counts[status]).append(' ').append(PACKAGE_STATUS_ORDER.get(status));
		}
		String head = total(counts) + " " + noun;
		return text.length() == 0 ? head : head + ": " + text;
	}

	private static int total(int[] counts) {
		int total = 0;
		for (int count : counts) {
			total += count;
		}
		return total;
	}

	private static int statusRank(String status) {
		return STATUS_ORDER.indexOf(status);
	}

	/** Saves the workbook, using a name with the time added when the report cannot be written. */
	private void saveWorkbook(StreamingXlsxWriter writer) throws IOException {
		try {
			writer.finish();
		} catch (IOException e) {
			Path alternative = folder.resolve("CVEBotReport_" + LocalDateTime.now().format(FALLBACK_NAME) + ".xlsx");
			log.warn("saveWorkbook", outputPath + " cannot be written (is it open in Excel?): " + describe(e)
					+ ". Saving as " + alternative);
			writer.save(alternative);
			outputPath = alternative;
		}
	}

	/** Sheet that tells the reader that the report is incomplete and why. */
	private static void addRunStatusSheet(StreamingXlsxWriter writer, Throwable error) throws IOException {
		List<Object> first = List.<Object>of("Status",
				"INCOMPLETE - the report stopped with an error. The rows written before it are saved.");
		StreamingXlsxWriter.Sheet sheet = writer.addSheet("Run Status", first, new double[]{22, 120}, false);
		sheet.add(List.<Object>of("Error", describe(error)));
		sheet.add(List.<Object>of("Time", LocalDateTime.now().format(RUN_TIME)));
		sheet.add(List.<Object>of("Next step",
				"See " + LOG_FILE_NAME + " for the full error, fix the cause and run the action again."));
	}

	private static int[] packageColumns(List<String> header, String sheet, Path report) throws IOException {
		List<String> names = new ArrayList<>(header.size());
		for (String cell : header) {
			names.add(cell == null ? "" : cell.trim());
		}

		int[] columns = new int[PACKAGE_COLUMNS.length];
		List<String> missing = new ArrayList<>();
		for (int index = 0; index < PACKAGE_COLUMNS.length; index++) {
			columns[index] = names.indexOf(PACKAGE_COLUMNS[index]);
			if (columns[index] < 0) {
				missing.add(PACKAGE_COLUMNS[index]);
			}
		}
		if (!missing.isEmpty()) {
			throw new IOException("Columns " + missing + " were not found on sheet \"" + sheet + "\" of " + report
					+ ". Run the package scan action again to get the Artifact Name column");
		}
		return columns;
	}

	private static List<String> sortedCves(Findings findings) {
		List<String> cves = new ArrayList<>(findings.cves.keySet());
		cves.sort(Comparator.naturalOrder());
		return cves;
	}

	private static List<String> sortedArtifacts(Findings findings, String cve) {
		List<String> artifacts = new ArrayList<>(findings.cves.get(cve).keySet());
		artifacts.sort(Comparator.naturalOrder());
		return artifacts;
	}

	private static List<Object> emptyRow(int columns) {
		List<Object> row = new ArrayList<>(columns);
		for (int column = 0; column < columns; column++) {
			row.add(null);
		}
		return row;
	}

	private static String key(String cve, String artifact) {
		return cve + '\u0000' + artifact;
	}

	private static String cell(List<String> row, int index) {
		return index >= 0 && index < row.size() && row.get(index) != null ? row.get(index) : "";
	}

	private static boolean hasContent(List<String> row) {
		for (String value : row) {
			if (value != null && !value.isEmpty()) {
				return true;
			}
		}
		return false;
	}

	private static String titleCase(String value) {
		StringBuilder result = new StringBuilder(value.length());
		boolean startOfWord = true;
		for (int index = 0; index < value.length(); index++) {
			char character = value.charAt(index);
			if (Character.isLetter(character)) {
				result.append(startOfWord ? Character.toUpperCase(character) : Character.toLowerCase(character));
				startOfWord = false;
			} else {
				result.append(character);
				startOfWord = true;
			}
		}
		return result.toString();
	}

	private static String describe(Throwable error) {
		String message = error.getMessage();
		return error.getClass().getSimpleName() + (message == null ? "" : ": " + message);
	}

	private static void deleteTree(Path folder) {
		try (java.util.stream.Stream<Path> paths = Files.walk(folder)) {
			for (Path path : paths.sorted(Comparator.reverseOrder()).toArray(Path[]::new)) {
				Files.deleteIfExists(path);
			}
		} catch (IOException ignored) {
			// Only temporary files; the next run uses a new folder.
		}
	}

	/** The unreachable versions of every CVE and package, read from the findings report. */
	private static final class Findings {

		private final Map<String, Map<String, Set<Version>>> cves = new LinkedHashMap<>();
		private final Map<String, String> severity = new LinkedHashMap<>();

		void add(String cve, String artifact, Version version) {
			cves.computeIfAbsent(cve, name -> new LinkedHashMap<>())
					.computeIfAbsent(artifact, name -> new HashSet<>())
					.add(version);
		}

		void setSeverity(String cve, String value) {
			severity.putIfAbsent(cve, value);
		}

		int pairs() {
			int pairs = 0;
			for (Map<String, Set<Version>> byArtifact : cves.values()) {
				pairs += byArtifact.size();
			}
			return pairs;
		}
	}

	/** Everything needed to compare a package version with one CVE and package. */
	private static final class ReleaseInfo {

		private final Set<Version> versions;
		private final String text;
		private final Map<String, String[]> cache = new HashMap<>();

		ReleaseInfo(Set<Version> versions) {
			List<Version> ordered = new ArrayList<>(versions);
			ordered.sort(Comparator.naturalOrder());
			this.versions = new HashSet<>(ordered);

			StringBuilder text = new StringBuilder();
			for (Version version : ordered) {
				if (text.length() > 0) {
					text.append(", ");
				}
				text.append(version);
			}
			this.text = text.toString();
		}
	}

	/** The package rows of one run, sorted on disk and counted per version. */
	private static final class PackageIndex {

		private final Map<String, Map<String, Integer>> histograms = new LinkedHashMap<>();
		private final Map<String, String> packageNames = new LinkedHashMap<>();
		private final Map<String, long[]> offsets = new HashMap<>();

		private Path sortedByArtifact;
		private Path sortedByBot;
	}

	/** One package of one bot in the bot-wise report. */
	private static final class BotEntry {

		private final String packageName;
		private final String artifact;
		private final String version;
		private final String status;
		private final List<CveRow> cveRows;

		BotEntry(String packageName, String artifact, String version, String status, List<CveRow> cveRows) {
			this.packageName = packageName;
			this.artifact = artifact;
			this.version = version;
			this.status = status;
			this.cveRows = cveRows;
		}
	}

	/** One CVE of one package version in the bot-wise report. */
	private static final class CveRow {

		private final String cve;
		private final String severity;
		private final String versions;
		private final String status;
		private final String note;

		CveRow(String cve, String severity, String versions, String status, String note) {
			this.cve = cve;
			this.severity = severity;
			this.versions = versions;
			this.status = status;
			this.note = note;
		}
	}

	/**
	 * A version reduced to its numbers, so "2.15.0-snapshot.202608290655+8ead5ef",
	 * "2.15.0-20250715-190141" and "2.15.0" are all 2.15.0. Versions with fewer than three numbers
	 * are filled up with zeros ("2.15" is 2.15.0); the text after the numbers is ignored.
	 */
	static final class Version implements Comparable<Version> {

		private final long[] parts;

		private Version(long[] parts) {
			this.parts = parts;
		}

		/** The version of a text, or null when the text does not start with a number. */
		static Version parse(String text) {
			Matcher matcher = VERSION_PATTERN.matcher(text == null ? "" : text);
			if (!matcher.lookingAt()) {
				return null;
			}
			String[] numbers = matcher.group(1).split("\\.");
			long[] parts = new long[Math.max(numbers.length, 3)];
			try {
				for (int index = 0; index < numbers.length; index++) {
					parts[index] = Long.parseLong(numbers[index]);
				}
			} catch (NumberFormatException e) {
				return null;
			}
			return new Version(parts);
		}

		@Override
		public int compareTo(Version other) {
			int common = Math.min(parts.length, other.parts.length);
			for (int index = 0; index < common; index++) {
				int result = Long.compare(parts[index], other.parts[index]);
				if (result != 0) {
					return result;
				}
			}
			return Integer.compare(parts.length, other.parts.length);
		}

		@Override
		public boolean equals(Object other) {
			return other instanceof Version && Arrays.equals(parts, ((Version) other).parts);
		}

		@Override
		public int hashCode() {
			return Arrays.hashCode(parts);
		}

		@Override
		public String toString() {
			StringBuilder text = new StringBuilder();
			for (long part : parts) {
				if (text.length() > 0) {
					text.append('.');
				}
				text.append(part);
			}
			return text.toString();
		}
	}
}
