/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.helpers;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Minimal SpreadsheetML (xlsx) writer for the two sheet report. Only the parts of the format the
 * report needs are produced, so the package stays free of third party dependencies.
 *
 * <p>Rows are streamed straight from the caller's iterator into the workbook, so the memory used
 * does not grow with the number of rows. Sheets carry a bold header row, a frozen header, and fixed
 * column widths; a sheet that is full is continued by the caller on the next sheet.</p>
 */
public final class XlsxReportWriter {

	private static final String XML_DECLARATION = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
	private static final String MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
	private static final int STYLE_DEFAULT = 0;
	private static final int STYLE_HEADER = 1;
	private static final int BUFFER_SIZE = 1 << 16;

	/** One worksheet of the report. */
	public static final class Sheet {

		private final String name;
		private final List<Object> header;
		private final double[] widths;
		private final Iterator<List<Object>> rows;
		private final int rowCount;

		public Sheet(String name, List<Object> header, double[] widths, Iterator<List<Object>> rows, int rowCount) {
			this.name = name;
			this.header = header;
			this.widths = widths;
			this.rows = rows;
			this.rowCount = rowCount;
		}
	}

	public void write(Path target, List<Sheet> sheets) throws IOException {
		try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(target))) {
			addEntry(zip, "[Content_Types].xml", contentTypes(sheets.size()));
			addEntry(zip, "_rels/.rels", packageRelationships());
			addEntry(zip, "docProps/core.xml", coreProperties());
			addEntry(zip, "docProps/app.xml", applicationProperties());
			addEntry(zip, "xl/workbook.xml", workbook(sheets));
			addEntry(zip, "xl/_rels/workbook.xml.rels", workbookRelationships(sheets.size()));
			addEntry(zip, "xl/styles.xml", styles());
			for (int index = 0; index < sheets.size(); index++) {
				writeWorksheet(zip, "xl/worksheets/sheet" + (index + 1) + ".xml", sheets.get(index));
			}
		}
	}

	private static void addEntry(ZipOutputStream zip, String name, String content) throws IOException {
		zip.putNextEntry(new ZipEntry(name));
		byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
		zip.write(bytes, 0, bytes.length);
		zip.closeEntry();
	}

	/** Streams one worksheet, so the workbook is built without holding the rows in memory. */
	private static void writeWorksheet(ZipOutputStream zip, String entryName, Sheet sheet) throws IOException {
		int columnCount = sheet.header.size();
		String lastColumn = columnName(columnCount);
		String range = "A1:" + lastColumn + Math.max(sheet.rowCount + 1, 1);

		zip.putNextEntry(new ZipEntry(entryName));
		Writer writer = new BufferedWriter(new OutputStreamWriter(zip, StandardCharsets.UTF_8), BUFFER_SIZE);

		writer.write(XML_DECLARATION);
		writer.write("<worksheet xmlns=\"" + MAIN_NS + "\">");
		writer.write("<dimension ref=\"" + range + "\"/>");
		writer.write("<sheetViews><sheetView workbookViewId=\"0\">"
				+ "<pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/>"
				+ "<selection pane=\"bottomLeft\" activeCell=\"A2\" sqref=\"A2\"/>"
				+ "</sheetView></sheetViews>");
		writer.write("<sheetFormatPr defaultRowHeight=\"15\"/>");
		writer.write("<cols>");
		for (int column = 0; column < columnCount; column++) {
			double width = column < sheet.widths.length ? sheet.widths[column] : 0;
			writer.write("<col min=\"" + (column + 1) + "\" max=\"" + (column + 1) + "\" width=\"" + width
					+ "\" customWidth=\"1\"/>");
		}
		writer.write("</cols><sheetData>");

		writeRow(writer, 1, sheet.header, columnCount, true);
		int rowNumber = 1;
		while (sheet.rows.hasNext()) {
			rowNumber++;
			writeRow(writer, rowNumber, sheet.rows.next(), columnCount, false);
		}

		writer.write("</sheetData></worksheet>");
		writer.flush();
		zip.closeEntry();
	}

	private static void writeRow(Writer writer, int rowNumber, List<Object> cells, int columnCount, boolean header)
			throws IOException {
		StringBuilder xml = new StringBuilder(256);
		xml.append("<row r=\"").append(rowNumber).append("\">");
		for (int column = 0; column < cells.size() && column < columnCount; column++) {
			Object value = cells.get(column);
			if (value == null) {
				continue;
			}
			xml.append("<c r=\"").append(columnName(column + 1)).append(rowNumber).append('"');
			if (header) {
				xml.append(" s=\"").append(STYLE_HEADER).append('"');
			}
			if (value instanceof Number) {
				xml.append("><v>").append(value).append("</v></c>");
			} else {
				xml.append(" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
						.append(escape(String.valueOf(value))).append("</t></is></c>");
			}
		}
		xml.append("</row>");
		writer.write(xml.toString());
	}

	private static String contentTypes(int sheetCount) {
		StringBuilder xml = new StringBuilder(XML_DECLARATION);
		xml.append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">");
		xml.append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>");
		xml.append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>");
		xml.append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>");
		xml.append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
		for (int index = 1; index <= sheetCount; index++) {
			xml.append("<Override PartName=\"/xl/worksheets/sheet").append(index)
					.append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
		}
		xml.append("<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>");
		xml.append("<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>");
		xml.append("</Types>");
		return xml.toString();
	}

	private static String packageRelationships() {
		return XML_DECLARATION
				+ "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
				+ "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
				+ "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
				+ "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>"
				+ "</Relationships>";
	}

	private static String coreProperties() {
		return XML_DECLARATION
				+ "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\""
				+ " xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\""
				+ " xmlns:dcmitype=\"http://purl.org/dc/dcmitype/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<dc:creator>BotPackageInventory</dc:creator>"
				+ "<cp:lastModifiedBy>BotPackageInventory</cp:lastModifiedBy>"
				+ "</cp:coreProperties>";
	}

	private static String applicationProperties() {
		return XML_DECLARATION
				+ "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\""
				+ " xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\">"
				+ "<Application>BotPackageInventory</Application>"
				+ "</Properties>";
	}

	private static String workbook(List<Sheet> sheets) {
		StringBuilder xml = new StringBuilder(XML_DECLARATION);
		xml.append("<workbook xmlns=\"").append(MAIN_NS)
				.append("\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");
		xml.append("<sheets>");
		for (int index = 0; index < sheets.size(); index++) {
			xml.append("<sheet name=\"").append(escape(sheets.get(index).name)).append("\" sheetId=\"").append(index + 1)
					.append("\" r:id=\"rId").append(index + 1).append("\"/>");
		}
		xml.append("</sheets></workbook>");
		return xml.toString();
	}

	private static String workbookRelationships(int sheetCount) {
		StringBuilder xml = new StringBuilder(XML_DECLARATION);
		xml.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
		for (int index = 1; index <= sheetCount; index++) {
			xml.append("<Relationship Id=\"rId").append(index)
					.append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
					.append(index).append(".xml\"/>");
		}
		xml.append("<Relationship Id=\"rId").append(sheetCount + 1)
				.append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>");
		xml.append("</Relationships>");
		return xml.toString();
	}

	private static String styles() {
		return XML_DECLARATION
				+ "<styleSheet xmlns=\"" + MAIN_NS + "\">"
				+ "<fonts count=\"2\">"
				+ "<font><sz val=\"11\"/><color theme=\"1\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
				+ "<font><b/><sz val=\"11\"/><color theme=\"1\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
				+ "</fonts>"
				+ "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill>"
				+ "<fill><patternFill patternType=\"gray125\"/></fill></fills>"
				+ "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
				+ "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
				+ "<cellXfs count=\"2\">"
				+ "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
				+ "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>"
				+ "</cellXfs>"
				+ "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
				+ "<dxfs count=\"0\"/>"
				+ "</styleSheet>";
	}

	private static String columnName(int columnNumber) {
		StringBuilder name = new StringBuilder();
		int remaining = columnNumber;
		while (remaining > 0) {
			int letter = (remaining - 1) % 26;
			name.insert(0, (char) ('A' + letter));
			remaining = (remaining - letter) / 26;
		}
		return name.toString();
	}

	private static String escape(String value) {
		StringBuilder escaped = new StringBuilder(value.length() + 16);
		for (int index = 0; index < value.length(); index++) {
			char character = value.charAt(index);
			switch (character) {
				case '&':
					escaped.append("&amp;");
					break;
				case '<':
					escaped.append("&lt;");
					break;
				case '>':
					escaped.append("&gt;");
					break;
				case '"':
					escaped.append("&quot;");
					break;
				case '\'':
					escaped.append("&apos;");
					break;
				default:
					// Characters that XML 1.0 does not allow would make the workbook unreadable.
					if (character == '\t' || character == '\n' || character == '\r' || character >= 0x20) {
						escaped.append(character);
					}
					break;
			}
		}
		return escaped.toString();
	}
}
