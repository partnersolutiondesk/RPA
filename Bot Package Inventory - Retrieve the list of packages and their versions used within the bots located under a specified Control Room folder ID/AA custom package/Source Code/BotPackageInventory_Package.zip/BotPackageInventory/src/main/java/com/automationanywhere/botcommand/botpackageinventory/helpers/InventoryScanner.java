/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.helpers;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AccessDeniedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.automationanywhere.botcommand.botpackageinventory.helpers.BotPackageAnalyzer.PackageUsage;
import com.automationanywhere.botcommand.botpackageinventory.helpers.ControlRoomClient.BotItem;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * Walks a Control Room folder (and every subfolder, at any depth), reads each taskbot and reports
 * the packages and versions it uses into {@code PackageReport.xlsx}:
 *
 * <ul>
 * <li>"Full Report" - one row per bot per package</li>
 * <li>"Bot Level Report" - one row per bot, with all of its packages summarised</li>
 * </ul>
 *
 * <p>Built for large Control Rooms: bots are fetched in parallel and every finished batch is
 * written to progress files straight away, so nothing is held in memory and a stopped run can be
 * resumed by running it again. The workbook is written in streaming mode and continues on
 * "Full Report 2", "Full Report 3", ... when a sheet is full. Whatever has been collected is saved
 * even when the run stops part way.</p>
 */
public class InventoryScanner {

	public static final String REPORT_FILE_NAME = "PackageReport.xlsx";
	public static final String LOG_FILE_NAME = "BotPackageInventory.log";

	private static final String PROGRESS_META_FILE = "PackageReport_progress_meta.json";
	private static final String PROGRESS_FULL_FILE = "PackageReport_progress_full.csv";
	private static final String PROGRESS_BOTS_FILE = "PackageReport_progress_bots.csv";

	/** Bots fetched in parallel; lower it if the Control Room throttles. */
	private static final int MAX_WORKERS = 5;
	/** Folder listing page size. */
	private static final int PAGE_SIZE = 100;
	/** Excel allows 1,048,576 rows per sheet; the header takes one of them. */
	private static final int MAX_ROWS_PER_SHEET = 1_000_000;
	/** Log progress after this many bots. */
	private static final int LOG_EVERY = 500;

	private static final List<Object> FULL_REPORT_HEADER = List.<Object>of(
			"Bot Id", "Bot Name", "Bot Path", "Package", "Artifact Name", "Version", "Commands Used");
	private static final double[] FULL_REPORT_WIDTHS = {14, 32, 70, 22, 30, 24, 15};
	private static final List<Object> BOT_REPORT_HEADER = List.<Object>of(
			"Bot Id", "Bot Name", "Bot Path", "Status", "Package Count", "Total Commands", "Packages");
	private static final double[] BOT_REPORT_WIDTHS = {14, 32, 70, 22, 15, 16, 60};

	private static final int FULL_COLUMNS = 7;
	private static final int BOT_COLUMNS = 7;

	private static final String STATUS_OK = "OK";
	private static final String STATUS_CONTENT_NOT_RETRIEVED = "Content not retrieved";
	private static final String STATUS_PARSE_ERROR = "Parse error";

	/** First sheet of the report: tells the reader whether the run read everything. */
	private static final String RUN_STATUS_SHEET = "Run Status";
	private static final String RUN_COMPLETE = "COMPLETE";
	private static final String RUN_INCOMPLETE = "INCOMPLETE";
	private static final List<Object> RUN_STATUS_HEADER = List.<Object>of("Field", "Value");
	private static final double[] RUN_STATUS_WIDTHS = {30, 120};

	private static final DateTimeFormatter FILE_TIMESTAMP = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
	private static final DateTimeFormatter RUN_TIME =
			DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm:ss a", Locale.ENGLISH);
	private static final ObjectMapper MAPPER = new ObjectMapper();

	private final ControlRoomClient client;
	private final ReportLogger log;
	private final Path outputFolder;
	private final Map<String, Integer> stats = new LinkedHashMap<>();
	/** Folder id to a readable "name (path)", for the folders that could not be read. */
	private final Map<String, String> folderLabels = new LinkedHashMap<>();
	private final List<String> failedFolders = new ArrayList<>();

	private Path reportWritten;
	private String rootFolderId;
	private String stopReason;
	private boolean completedRun;

	public InventoryScanner(ControlRoomClient client, ReportLogger log, Path outputFolder) {
		this.client = client;
		this.log = log;
		this.outputFolder = outputFolder;
	}

	/**
	 * Scans the folder tree and writes the report.
	 *
	 * @return the scan summary as JSON, including the path of the generated report
	 */
	public String scan(String rootFolderId) throws IOException {
		this.rootFolderId = rootFolderId;

		// A first listing check, so a wrong URL or a Control Room that is down fails in seconds
		// instead of after the whole run.
		if (client.listFolder(rootFolderId, 0) == null) {
			throw new ScanStoppedException("The Control Room at " + client.getControlRoomUrl()
					+ " did not answer for folder " + rootFolderId
					+ ". Check the Control Room URL, the folder ID and the network, then run again.");
		}

		Map<String, String> artifacts = client.listPackageArtifacts();
		Set<String> doneIds = loadProgress(rootFolderId);
		long started = System.currentTimeMillis();

		ExecutorService executor = Executors.newFixedThreadPool(MAX_WORKERS);
		boolean completed = false;

		try (BufferedWriter fullFile = openForAppend(outputFolder.resolve(PROGRESS_FULL_FILE));
				BufferedWriter botsFile = openForAppend(outputFolder.resolve(PROGRESS_BOTS_FILE))) {
			scan(executor, rootFolderId, artifacts, doneIds, new CsvWriter(fullFile), new CsvWriter(botsFile),
					fullFile, botsFile, started);
			// Only a run that read everything is complete. Anything else keeps the progress files,
			// so the next run continues instead of starting from scratch.
			completed = count("folders_failed") == 0 && count("bots_failed") == 0;
			if (!completed) {
				log.warn("scan", "Not everything could be read (" + count("folders_failed") + " folders, "
						+ count("bots_failed") + " bots). The progress is kept; run again to fill the gaps");
			}
		} catch (RuntimeException e) {
			stopReason = e.getMessage();
			log.error("scan", "Scan stopped before it finished. Progress is saved; run again to continue: "
					+ e);
			throw e;
		} finally {
			executor.shutdownNow();
			completedRun = completed;
			writeReportAndFinish(completed, started);
		}

		return summary();
	}

	private void scan(ExecutorService executor, String rootFolderId, Map<String, String> artifacts,
			Set<String> doneIds, CsvWriter fullWriter, CsvWriter botsWriter, BufferedWriter fullFile,
			BufferedWriter botsFile, long started) throws IOException {

		Deque<String> pendingFolders = new ArrayDeque<>();
		Set<String> processedFolders = new HashSet<>();
		Set<String> retriedFolders = new HashSet<>();
		pendingFolders.push(rootFolderId);
		folderLabels.putIfAbsent(rootFolderId, "root folder " + rootFolderId);

		while (!pendingFolders.isEmpty()) {
			if (client.isAborted()) {
				throw new ScanStoppedException(connectionLost());
			}

			String folderId = pendingFolders.pop();
			if (!processedFolders.add(folderId)) {
				continue;
			}

			if (!retriedFolders.contains(folderId)) {
				increment("folders");
			}
			log.debug("scan", "inside fetch folder " + folderId);
			int offset = 0;
			Set<String> seenItems = new HashSet<>();

			while (true) {
				List<BotItem> page = client.listFolder(folderId, offset);
				if (page == null) {
					if (client.isAborted()) {
						throw new ScanStoppedException(connectionLost());
					}
					if (retriedFolders.add(folderId)) {
						// A short network problem often clears up on its own: try the folder again
						// once, after the rest of the tree has been read.
						log.warn("scan", "Folder " + folderLabel(folderId)
								+ " could not be listed. Retrying it once at the end of the run");
						processedFolders.remove(folderId);
						pendingFolders.addLast(folderId);
					} else {
						increment("folders_failed");
						failedFolders.add(folderLabel(folderId));
						log.error("scan", "Folder " + folderLabel(folderId)
								+ " could not be listed. Its content is missing from the report");
					}
					break;
				}

				List<BotItem> newItems = new ArrayList<>();
				for (BotItem item : page) {
					if (seenItems.add(item.getId())) {
						newItems.add(item);
					}
				}
				// Stop pagination if no new items are received.
				if (newItems.isEmpty()) {
					break;
				}

				List<BotItem> batch = new ArrayList<>();
				for (BotItem item : newItems) {
					if (item.isTaskbot()) {
						if (doneIds.contains(item.getId())) {
							increment("bots_skipped");
						} else {
							batch.add(item);
						}
					} else if (item.isDirectory()) {
						folderLabels.putIfAbsent(item.getId(), item.getName() + " (" + item.getPath() + ")");
						pendingFolders.push(item.getId());
					}
				}

				if (!batch.isEmpty()) {
					saveBatch(analyseBatch(executor, batch), artifacts, fullWriter, botsWriter);
					fullFile.flush();
					botsFile.flush();
					logProgress(batch.size(), started);
				}

				offset += PAGE_SIZE;
			}
		}
	}

	private List<BotResult> analyseBatch(ExecutorService executor, List<BotItem> batch) {
		List<Callable<BotResult>> tasks = new ArrayList<>(batch.size());
		for (BotItem item : batch) {
			tasks.add(() -> analyseBot(item));
		}

		try {
			List<Future<BotResult>> futures = executor.invokeAll(tasks);
			List<BotResult> results = new ArrayList<>(batch.size());
			for (Future<BotResult> future : futures) {
				results.add(future.get());
			}
			return results;
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new ScanStoppedException("The run was stopped before it finished. The bots read so far are "
					+ "saved; run the action again to continue where it stopped.");
		} catch (ExecutionException e) {
			throw new ScanStoppedException("Reading a bot of the batch failed: " + e.getCause()
					+ ". The bots read so far are saved; run the action again to continue where it stopped.");
		}
	}

	/** Runs in a worker thread: downloads one bot and reads its packages. */
	private BotResult analyseBot(BotItem item) {
		try {
			String content = client.getFileContent(item.getId());
			if (content == null || content.isEmpty()) {
				log.error("analyseBot", "Content not retrieved for bot " + item.getId() + " " + item.getName());
				return new BotResult(item, STATUS_CONTENT_NOT_RETRIEVED, List.of());
			}
			return new BotResult(item, STATUS_OK, BotPackageAnalyzer.extractBotPackages(content));
		} catch (Exception e) {
			log.error("analyseBot", "Parse error for bot " + item.getId() + " " + item.getName() + ": " + e);
			return new BotResult(item, STATUS_PARSE_ERROR, List.of());
		}
	}

	private void saveBatch(List<BotResult> results, Map<String, String> artifacts, CsvWriter fullWriter,
			CsvWriter botsWriter) throws IOException {

		for (BotResult result : results) {
			BotItem item = result.item;
			for (PackageUsage usage : result.usages) {
				fullWriter.write(Arrays.<Object>asList(item.getId(), item.getName(), item.getPath(), usage.getName(),
						artifacts.getOrDefault(usage.getName().toLowerCase(Locale.ROOT), ""), usage.getVersion(),
						usage.getCommands()));
			}

			int totalCommands = 0;
			for (PackageUsage usage : result.usages) {
				totalCommands += usage.getCommands();
			}
			botsWriter.write(Arrays.<Object>asList(item.getId(), item.getName(), item.getPath(), result.status,
					result.usages.size(), totalCommands, BotPackageAnalyzer.describePackages(result.usages)));

			increment(STATUS_OK.equals(result.status) ? "bots_ok" : "bots_failed");
			increment("full_rows", result.usages.size());
		}
	}

	private void logProgress(int batchSize, long started) {
		int done = count("bots_ok") + count("bots_failed");
		if (done / LOG_EVERY != (done - batchSize) / LOG_EVERY) {
			double seconds = Math.max((System.currentTimeMillis() - started) / 1000.0, 1);
			log.info("scan", "Progress: " + done + " bots read (" + count("bots_failed") + " failed), "
					+ count("folders") + " folders, " + String.format(Locale.ROOT, "%.1f", done / seconds) + " bots/s");
		}
	}

	/**
	 * Reads what an earlier run saved. Returns the ids of bots that were read fine and can be
	 * skipped. Progress from a different folder or Control Room is thrown away.
	 */
	private Set<String> loadProgress(String folderId) throws IOException {
		Path metaPath = outputFolder.resolve(PROGRESS_META_FILE);
		Path fullPath = outputFolder.resolve(PROGRESS_FULL_FILE);
		Path botsPath = outputFolder.resolve(PROGRESS_BOTS_FILE);

		boolean sameScope = false;
		if (Files.exists(metaPath)) {
			try {
				JsonNode previous = MAPPER.readTree(Files.readAllBytes(metaPath));
				sameScope = previous != null && previous.isObject()
						&& folderId.equals(previous.path("folder_id").asText(null))
						&& client.getControlRoomUrl().equals(previous.path("cr_url").asText(null));
			} catch (IOException e) {
				log.warn("loadProgress", "Progress file " + metaPath + " could not be read: " + e.getMessage());
			}
		}

		if (sameScope && Files.exists(botsPath)) {
			Set<String> doneIds = new HashSet<>();
			try (CsvReader reader = new CsvReader(botsPath)) {
				List<String> row;
				while ((row = reader.next()) != null) {
					if (row.size() >= 4 && STATUS_OK.equals(row.get(3))) {
						doneIds.add(row.get(0));
					}
				}
			}
			log.info("loadProgress", "Resuming an earlier run: " + doneIds.size()
					+ " bots already done and will be skipped");
			return doneIds;
		}

		for (Path path : Arrays.asList(fullPath, botsPath)) {
			if (Files.exists(path)) {
				log.info("loadProgress", "Removing progress file of an earlier run for another folder: " + path);
				Files.deleteIfExists(path);
			}
		}

		ObjectNode scope = MAPPER.createObjectNode();
		scope.put("folder_id", folderId);
		scope.put("cr_url", client.getControlRoomUrl());
		Files.write(metaPath, scope.toString().getBytes(StandardCharsets.UTF_8));
		return new HashSet<>();
	}

	/** Writes the workbook from the progress files and clears them once the scan is complete. */
	private void writeReportAndFinish(boolean completed, long started) {
		boolean reportWritten = false;
		try {
			writeReportFromProgress();
			reportWritten = true;
		} catch (IOException e) {
			log.error("writeReportFromProgress", "Could not write the Excel report. Progress files are kept: " + e);
		}

		if (completed && reportWritten) {
			for (String name : Arrays.asList(PROGRESS_META_FILE, PROGRESS_FULL_FILE, PROGRESS_BOTS_FILE)) {
				try {
					Files.deleteIfExists(outputFolder.resolve(name));
				} catch (IOException e) {
					log.warn("writeReportAndFinish", "Progress file " + name + " could not be removed: " + e.getMessage());
				}
			}
		}

		log.info("scan", "Finished: " + stats + " in "
				+ Math.round((System.currentTimeMillis() - started) / 1000.0) + "s, scan complete: " + completed);
	}

	/** Builds the Excel report from the progress files, in streaming mode. */
	private void writeReportFromProgress() throws IOException {
		Path fullPath = outputFolder.resolve(PROGRESS_FULL_FILE);
		Path botsPath = outputFolder.resolve(PROGRESS_BOTS_FILE);
		int fullRows = countRows(fullPath, FULL_COLUMNS);

		Set<String> okBotIds = readOkBotIds(botsPath);
		int bots = countBotRows(botsPath, okBotIds);

		Path target = outputFolder.resolve(REPORT_FILE_NAME);
		Path written = target;
		try {
			new XlsxReportWriter().write(target, buildSheets(fullPath, botsPath, okBotIds));
		} catch (AccessDeniedException e) {
			// The report is most likely open in Excel; save it under a new name so the data is not lost.
			written = alternativeName(target);
			log.error("writeReportFromProgress", target + " cannot be written (is it open in Excel?). Saving as "
					+ written);
			new XlsxReportWriter().write(written, buildSheets(fullPath, botsPath, okBotIds));
		}

		reportWritten = written;
		log.info("writeReportFromProgress", "Report saved to " + written + ": " + fullRows
				+ " full report rows, " + bots + " bots");
	}

	private List<XlsxReportWriter.Sheet> buildSheets(Path fullPath, Path botsPath, Set<String> okBotIds)
			throws IOException {
		List<XlsxReportWriter.Sheet> sheets = new ArrayList<>();
		sheets.add(runStatusSheet());
		sheets.addAll(planSheets("Full Report", FULL_REPORT_HEADER, FULL_REPORT_WIDTHS, fullPath, FULL_COLUMNS, null));
		sheets.addAll(planSheets("Bot Level Report", BOT_REPORT_HEADER, BOT_REPORT_WIDTHS, botsPath, BOT_COLUMNS, okBotIds));
		return sheets;
	}

	/**
	 * First sheet of the report: tells the reader at a glance whether the run read everything
	 * ("COMPLETE") or stopped early ("INCOMPLETE"), and what to do next.
	 */
	private XlsxReportWriter.Sheet runStatusSheet() {
		List<List<Object>> rows = new ArrayList<>();
		rows.add(List.<Object>of("Status", completedRun ? RUN_COMPLETE : RUN_INCOMPLETE));
		rows.add(List.<Object>of("Folder", rootFolderId == null ? "" : rootFolderId));
		rows.add(List.<Object>of("Bots read", count("bots_ok") + count("bots_failed")));
		rows.add(List.<Object>of("Bots read fine", count("bots_ok")));
		rows.add(List.<Object>of("Bots failed", count("bots_failed")));
		rows.add(List.<Object>of("Bots skipped from an earlier run", count("bots_skipped")));
		rows.add(List.<Object>of("Folders read", count("folders")));
		rows.add(List.<Object>of("Folders failed", count("folders_failed")));
		if (!failedFolders.isEmpty()) {
			rows.add(List.<Object>of("Folders missing from the report", String.join("; ", failedFolders)));
		}
		if (stopReason != null && !stopReason.isEmpty()) {
			rows.add(List.<Object>of("Stopped because", stopReason));
		}
		rows.add(List.<Object>of("Run time", LocalDateTime.now().format(RUN_TIME)));
		rows.add(List.<Object>of("Next step", completedRun
				? "Nothing to do. Everything could be read."
				: "Run the action again with the same inputs to fill the gaps. "
						+ "See " + LOG_FILE_NAME + " for details."));
		return new XlsxReportWriter.Sheet(RUN_STATUS_SHEET, RUN_STATUS_HEADER, RUN_STATUS_WIDTHS,
				rows.iterator(), rows.size());
	}

	/**
	 * Splits one report into as many sheets as the row count needs, in the same way the workbook
	 * writer continues a full sheet on "&lt;name&gt; 2", "&lt;name&gt; 3", ...
	 */
	private List<XlsxReportWriter.Sheet> planSheets(String baseName, List<Object> header, double[] widths, Path path,
			int columns, Set<String> okBotIds) throws IOException {

		int dataRows = okBotIds == null ? countRows(path, columns) : countBotRows(path, okBotIds);
		int rowsPerSheet = MAX_ROWS_PER_SHEET - 1;
		int parts = Math.max(1, (int) Math.ceil(dataRows / (double) rowsPerSheet));

		List<XlsxReportWriter.Sheet> sheets = new ArrayList<>(parts);
		int skip = 0;
		for (int part = 0; part < parts; part++) {
			int take = Math.min(rowsPerSheet, dataRows - skip);
			String name = part == 0 ? baseName : baseName + " " + (part + 1);
			sheets.add(new XlsxReportWriter.Sheet(name, header, widths,
					new CsvRowIterator(path, columns, okBotIds, skip, take), take));
			skip += take;
		}
		return sheets;
	}

	private Set<String> readOkBotIds(Path botsPath) throws IOException {
		Set<String> okIds = new HashSet<>();
		if (!Files.exists(botsPath)) {
			return okIds;
		}
		try (CsvReader reader = new CsvReader(botsPath)) {
			List<String> row;
			while ((row = reader.next()) != null) {
				if (row.size() == BOT_COLUMNS && STATUS_OK.equals(row.get(3))) {
					okIds.add(row.get(0));
				}
			}
		}
		return okIds;
	}

	private static int countRows(Path path, int columns) throws IOException {
		if (!Files.exists(path)) {
			return 0;
		}
		int rows = 0;
		try (CsvReader reader = new CsvReader(path)) {
			List<String> row;
			while ((row = reader.next()) != null) {
				if (row.size() == columns) {
					rows++;
				}
			}
		}
		return rows;
	}

	/**
	 * Counts the bot rows that end up in the report. A bot that failed in one run and was read fine
	 * in the next run appears twice in the progress file, and only the good row is kept.
	 */
	private static int countBotRows(Path path, Set<String> okIds) throws IOException {
		if (!Files.exists(path)) {
			return 0;
		}
		int rows = 0;
		Set<String> seenFailed = new HashSet<>();
		try (CsvReader reader = new CsvReader(path)) {
			List<String> row;
			while ((row = reader.next()) != null) {
				if (row.size() != BOT_COLUMNS) {
					continue;
				}
				if (!STATUS_OK.equals(row.get(3)) && !keepFailed(row.get(0), okIds, seenFailed)) {
					continue;
				}
				rows++;
			}
		}
		return rows;
	}

	private static boolean keepFailed(String botId, Set<String> okIds, Set<String> seenFailed) {
		return !okIds.contains(botId) && seenFailed.add(botId);
	}

	private Path alternativeName(Path target) {
		String name = target.getFileName().toString();
		int extension = name.lastIndexOf('.');
		String base = extension < 0 ? name : name.substring(0, extension);
		String suffix = extension < 0 ? "" : name.substring(extension);
		return target.resolveSibling(base + "_" + LocalDateTime.now().format(FILE_TIMESTAMP) + suffix);
	}

	private String folderLabel(String folderId) {
		return folderLabels.getOrDefault(folderId, "folder " + folderId);
	}

	/** Message used when the Control Room stops answering in the middle of the run. */
	private String connectionLost() {
		return "The Control Room stopped answering (the network was lost or the Control Room became "
				+ "unreachable). The bots read so far are saved; run the action again to continue "
				+ "where it stopped.";
	}

	private String summary() {
		Path report = reportWritten == null ? outputFolder.resolve(REPORT_FILE_NAME) : reportWritten;
		StringBuilder json = new StringBuilder(256);
		json.append("{\n");
		json.append("    \"scan_complete\": ").append(completedRun).append(",\n");
		json.append("    \"bots_read\": ").append(count("bots_ok") + count("bots_failed")).append(",\n");
		json.append("    \"bots_failed\": ").append(count("bots_failed")).append(",\n");
		json.append("    \"bots_skipped_from_earlier_run\": ").append(count("bots_skipped")).append(",\n");
		json.append("    \"folders_failed\": ").append(count("folders_failed")).append(",\n");
		json.append("    \"report\": \"").append(jsonEscape(report.toString())).append("\"\n");
		json.append("}");
		return json.toString();
	}

	private static String jsonEscape(String value) {
		StringBuilder escaped = new StringBuilder(value.length() + 16);
		for (int index = 0; index < value.length(); index++) {
			char character = value.charAt(index);
			switch (character) {
				case '\\':
					escaped.append("\\\\");
					break;
				case '"':
					escaped.append("\\\"");
					break;
				case '\n':
					escaped.append("\\n");
					break;
				case '\r':
					escaped.append("\\r");
					break;
				case '\t':
					escaped.append("\\t");
					break;
				default:
					escaped.append(character);
					break;
			}
		}
		return escaped.toString();
	}

	private void increment(String key) {
		increment(key, 1);
	}

	private void increment(String key, int amount) {
		stats.merge(key, amount, Integer::sum);
	}

	private int count(String key) {
		return stats.getOrDefault(key, 0);
	}

	private static BufferedWriter openForAppend(Path path) throws IOException {
		return Files.newBufferedWriter(path, StandardCharsets.UTF_8,
				StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
	}

	/**
	 * Raised when the run cannot go on because the Control Room cannot be reached any more. The
	 * report of what was read so far is still written and the progress files are kept.
	 */
	public static final class ScanStoppedException extends RuntimeException {

		public ScanStoppedException(String message) {
			super(message);
		}
	}

	/** One bot read by a worker thread. */
	private static final class BotResult {

		private final BotItem item;
		private final String status;
		private final List<PackageUsage> usages;

		BotResult(BotItem item, String status, List<PackageUsage> usages) {
			this.item = item;
			this.status = status;
			this.usages = usages;
		}
	}

	/** Reads the progress file row by row, turning the stored columns back into sheet cells. */
	private static final class CsvRowIterator implements Iterator<List<Object>> {

		private final CsvReader reader;
		private final int columns;
		private final Set<String> okIds;
		private final Set<String> seenFailed = new HashSet<>();

		private int toSkip;
		private int remaining;
		private List<Object> next;

		CsvRowIterator(Path path, int columns, Set<String> okIds, int skip, int limit) throws IOException {
			this.reader = new CsvReader(path);
			this.columns = columns;
			this.okIds = okIds;
			this.toSkip = skip;
			this.remaining = limit;
			this.next = advance();
		}

		@Override
		public boolean hasNext() {
			return next != null;
		}

		@Override
		public List<Object> next() {
			if (next == null) {
				throw new NoSuchElementException();
			}
			List<Object> current = next;
			next = advance();
			return current;
		}

		private List<Object> advance() {
			try {
				if (remaining <= 0) {
					reader.close();
					return null;
				}
				List<String> row;
				while ((row = reader.next()) != null) {
					if (row.size() != columns) {
						continue;
					}
					// A bot that failed in one run and was read fine in the next appears twice: keep the good row only.
					if (okIds != null && !STATUS_OK.equals(row.get(3))
							&& !keepFailed(row.get(0), okIds, seenFailed)) {
						continue;
					}
					if (toSkip > 0) {
						toSkip--;
						continue;
					}
					remaining--;
					return okIds == null ? fullRow(row) : botRow(row);
				}
				reader.close();
				return null;
			} catch (IOException e) {
				throw new IllegalStateException("Progress file could not be read: " + e, e);
			}
		}

		private static List<Object> fullRow(List<String> row) {
			return Arrays.<Object>asList(row.get(0), row.get(1), row.get(2), row.get(3), row.get(4), row.get(5),
					number(row.get(6)));
		}

		private static List<Object> botRow(List<String> row) {
			return Arrays.<Object>asList(row.get(0), row.get(1), row.get(2), row.get(3), number(row.get(4)),
					number(row.get(5)), row.get(6));
		}

		private static Integer number(String value) {
			try {
				return Integer.valueOf(value.trim());
			} catch (NumberFormatException e) {
				return 0;
			}
		}
	}

	/** Writes progress rows in the standard CSV form used by the report scripts. */
	private static final class CsvWriter {

		private final Writer writer;

		CsvWriter(Writer writer) {
			this.writer = writer;
		}

		void write(List<Object> values) throws IOException {
			StringBuilder line = new StringBuilder(160);
			for (int index = 0; index < values.size(); index++) {
				if (index > 0) {
					line.append(',');
				}
				line.append(escapeCsv(values.get(index)));
			}
			line.append('\n');
			writer.write(line.toString());
		}

		private static String escapeCsv(Object value) {
			String text = value == null ? "" : String.valueOf(value);
			boolean quoted = text.indexOf(',') >= 0 || text.indexOf('"') >= 0
					|| text.indexOf('\n') >= 0 || text.indexOf('\r') >= 0;
			if (!quoted) {
				return text;
			}
			return '"' + text.replace("\"", "\"\"") + '"';
		}
	}

	/**
	 * Reads a progress file record by record. Fields may hold line breaks, so a record is only
	 * complete once the quotes in it are balanced.
	 */
	private static final class CsvReader implements Closeable {

		private final BufferedReader reader;
		private final StringBuilder record = new StringBuilder();

		CsvReader(Path path) throws IOException {
			this.reader = Files.newBufferedReader(path, StandardCharsets.UTF_8);
		}

		List<String> next() throws IOException {
			record.setLength(0);
			boolean read = false;
			String line;

			while ((line = reader.readLine()) != null) {
				read = true;
				if (record.length() > 0) {
					record.append('\n');
				}
				record.append(line);
				if (countQuotes(record) % 2 == 0) {
					break;
				}
			}

			return read ? parseRecord(record) : null;
		}

		@Override
		public void close() throws IOException {
			reader.close();
		}

		private static int countQuotes(CharSequence text) {
			int quotes = 0;
			for (int index = 0; index < text.length(); index++) {
				if (text.charAt(index) == '"') {
					quotes++;
				}
			}
			return quotes;
		}

		private static List<String> parseRecord(CharSequence text) {
			List<String> fields = new ArrayList<>();
			StringBuilder field = new StringBuilder();
			boolean inQuotes = false;

			for (int index = 0; index < text.length(); index++) {
				char character = text.charAt(index);
				if (inQuotes) {
					if (character == '"') {
						if (index + 1 < text.length() && text.charAt(index + 1) == '"') {
							field.append('"');
							index++;
						} else {
							inQuotes = false;
						}
					} else {
						field.append(character);
					}
				} else if (character == '"') {
					inQuotes = true;
				} else if (character == ',') {
					fields.add(field.toString());
					field.setLength(0);
				} else {
					field.append(character);
				}
			}

			fields.add(field.toString());
			return fields;
		}
	}
}
