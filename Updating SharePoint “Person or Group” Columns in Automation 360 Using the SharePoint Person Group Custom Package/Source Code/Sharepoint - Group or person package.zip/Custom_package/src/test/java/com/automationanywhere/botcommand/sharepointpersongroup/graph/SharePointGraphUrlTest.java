package com.automationanywhere.botcommand.sharepointpersongroup.graph;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.net.URI;

import org.testng.annotations.Test;

/**
 * Guards the shape of the URL used to read the hidden User Information List.
 *
 * <p>Two rules matter here and both were broken once: the list is addressed by name in SharePoint
 * style quotes, so the quotes have to stay literal, and the name contains spaces, which a URI path
 * does not allow, so the spaces have to be percent encoded.</p>
 */
public class SharePointGraphUrlTest {

	private static final String SITE_ID = "automationanywherestore.sharepoint.com,dcbe1da5-f614-4409-961d-e50a7865d4ea,"
			+ "0aac5da0-403a-4f99-941a-098f8d1f5f22";

	@Test
	public void keepsTheListQuotesLiteralAndEncodesOnlyTheSpaces() {
		String url = SharePointGraph.userInformationListItemsUrl(SITE_ID);

		assertTrue(url.endsWith("/lists('User%20Information%20List')/items"), url);
		assertFalse(url.contains("%27"), "Encoding the quotes makes Microsoft Graph return HTTP 404.");
		assertFalse(url.contains(" "), "A space in the path makes the request fail before it is sent.");
	}

	@Test
	public void buildsALegalUriForTheUserInformationList() {
		String path = URI.create(SharePointGraph.userInformationListItemsUrl(SITE_ID)).getPath();

		assertEquals(path, "/v1.0/sites/" + SITE_ID + "/lists('User Information List')/items");
	}

	@Test(expectedExceptions = IllegalArgumentException.class)
	public void anUnencodedListNameIsRejectedByTheHttpClient() {
		URI.create("https://graph.microsoft.com/v1.0/sites/x/lists('User Information List')/items");
	}
}
