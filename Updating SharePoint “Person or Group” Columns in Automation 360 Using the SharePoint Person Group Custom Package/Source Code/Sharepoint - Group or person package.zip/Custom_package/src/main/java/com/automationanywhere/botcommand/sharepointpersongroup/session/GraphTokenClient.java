package com.automationanywhere.botcommand.sharepointpersongroup.session;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;

import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.botcommand.sharepointpersongroup.graph.GraphHttp;
import com.automationanywhere.commandsdk.i18n.Messages;
import com.automationanywhere.commandsdk.i18n.MessagesFactory;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

/**
 * Exchanges the app registration client credentials for a Microsoft Graph access token.
 *
 * <p>The secret is only ever read to build the token request body. It is never logged, never stored
 * in a message and never returned.</p>
 */
public final class GraphTokenClient {

	private static final Messages MESSAGES = MessagesFactory
			.getMessages("com.automationanywhere.botcommand.sharepointpersongroup.messages");

	private static final String TOKEN_HOST = "login.microsoftonline.com";
	private static final String TOKEN_URL = "https://" + TOKEN_HOST + "/%s/oauth2/v2.0/token";
	private static final String GRAPH_SCOPE = "https://graph.microsoft.com/.default";
	private static final Duration TIMEOUT = Duration.ofSeconds(60);
	private static final int MAX_DESCRIPTION_LENGTH = 400;

	private GraphTokenClient() {
	}

	/** A freshly issued access token and the moment it stops being usable. */
	public static final class TokenResult {

		private final String accessToken;
		private final Instant expiresAt;

		TokenResult(String accessToken, Instant expiresAt) {
			this.accessToken = accessToken;
			this.expiresAt = expiresAt;
		}

		public String accessToken() {
			return accessToken;
		}

		public Instant expiresAt() {
			return expiresAt;
		}
	}

	/**
	 * Requests a token with the client credentials flow.
	 *
	 * @param clientSecret the secret value, read from the credential just before this call
	 */
	public static TokenResult request(HttpClient client, String tenantId, String clientId, String clientSecret) {
		String body = "grant_type=client_credentials"
				+ "&client_id=" + GraphHttp.urlEncode(clientId)
				+ "&client_secret=" + GraphHttp.urlEncode(clientSecret)
				+ "&scope=" + GraphHttp.urlEncode(GRAPH_SCOPE);

		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create(String.format(TOKEN_URL, GraphHttp.urlEncode(tenantId))))
				.timeout(TIMEOUT)
				.header("Content-Type", "application/x-www-form-urlencoded")
				.header("Accept", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
				.build();

		HttpResponse<String> response;
		try {
			response = client.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
		} catch (IOException e) {
			throw new BotCommandException(MESSAGES.getString("graphUnreachable", TOKEN_HOST, e.getMessage()));
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new BotCommandException(MESSAGES.getString("graphUnreachable", TOKEN_HOST, e.getMessage()));
		}

		String responseBody = response.body() == null ? "" : response.body();
		if (response.statusCode() != 200) {
			throw new BotCommandException(describeFailure(response.statusCode(), responseBody));
		}

		JsonObject json;
		try {
			JsonElement parsed = JsonParser.parseString(responseBody);
			json = parsed.isJsonObject() ? parsed.getAsJsonObject() : new JsonObject();
		} catch (JsonSyntaxException e) {
			throw new BotCommandException(MESSAGES.getString("tokenRequestFailed", String.valueOf(response.statusCode()),
					"The response could not be read."));
		}
		if (!json.has("access_token") || json.get("access_token").isJsonNull()) {
			throw new BotCommandException(MESSAGES.getString("tokenRequestFailed", String.valueOf(response.statusCode()),
					"The response did not contain an access token."));
		}
		long expiresIn = json.has("expires_in") && !json.get("expires_in").isJsonNull()
				? json.get("expires_in").getAsLong()
				: 3600L;
		return new TokenResult(json.get("access_token").getAsString(), Instant.now().plusSeconds(expiresIn));
	}

	/**
	 * Microsoft Entra ID reports the cause with an AADSTS code. The common ones are named so the bot
	 * developer knows what to change instead of reading a raw error.
	 */
	private static String describeFailure(int status, String body) {
		String code = extract(body, "error");
		String description = shorten(extract(body, "error_description"));

		if (code.contains("AADSTS7000215") || code.contains("AADSTS7000222") || "invalid_client".equals(code)
				|| code.contains("AADSTS700027") || status == 401) {
			return MESSAGES.getString("invalidClientSecret", description);
		}
		if (code.contains("AADSTS500011") || code.contains("AADSTS700016") || code.contains("AADSTS900971")
				|| "invalid_request".equals(code) || "unauthorized_client".equals(code)) {
			return MESSAGES.getString("invalidTenantOrClient", description);
		}
		return MESSAGES.getString("tokenRequestFailed", String.valueOf(status),
				description.isEmpty() ? "Microsoft Entra ID did not explain the failure." : description);
	}

	private static String extract(String body, String member) {
		if (body == null || body.trim().isEmpty()) {
			return "";
		}
		try {
			JsonElement parsed = JsonParser.parseString(body);
			if (!parsed.isJsonObject()) {
				return "";
			}
			JsonObject json = parsed.getAsJsonObject();
			if (member.equals("error") && json.has("error") && json.get("error").isJsonObject()) {
				return value(json.getAsJsonObject("error"), "code");
			}
			return value(json, member);
		} catch (JsonSyntaxException e) {
			return "";
		}
	}

	private static String value(JsonObject json, String member) {
		return json.has(member) && !json.get(member).isJsonNull() ? json.get(member).getAsString() : "";
	}

	private static String shorten(String description) {
		String cleaned = description == null ? "" : description.replaceAll("\\s+", " ").trim();
		return cleaned.length() <= MAX_DESCRIPTION_LENGTH
				? cleaned
				: cleaned.substring(0, MAX_DESCRIPTION_LENGTH) + "...";
	}
}
