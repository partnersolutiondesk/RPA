package com.automationanywhere.botcommand.sharepointpersongroup.graph;

/**
 * A failed Microsoft Graph call. Carries the HTTP status and the error description that Graph
 * returned so the caller can turn it into a message that makes sense to a bot developer.
 *
 * <p>Never carries the access token or the client secret.</p>
 */
public class GraphException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/** Graph answered 401 or 403, which almost always means missing admin consent. */
	public static final String ACCESS_DENIED = "ACCESS_DENIED";

	/** The connection itself failed. */
	public static final String UNREACHABLE = "UNREACHABLE";

	private final int status;
	private final String code;
	private final String detail;

	public GraphException(int status, String code, String detail) {
		super(code + " (" + status + "): " + detail);
		this.status = status;
		this.code = code;
		this.detail = detail;
	}

	public int getStatus() {
		return status;
	}

	public String getCode() {
		return code;
	}

	/** Short, human readable description from Graph. Safe to show, never contains credentials. */
	public String getDetail() {
		return detail;
	}

	public boolean isAccessDenied() {
		return ACCESS_DENIED.equals(code);
	}

	public boolean isUnreachable() {
		return UNREACHABLE.equals(code);
	}
}
