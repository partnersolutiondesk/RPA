package com.automationanywhere.botcommand.sharepointpersongroup.logic;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import com.automationanywhere.botcommand.data.Value;
import com.automationanywhere.botcommand.data.impl.ListValue;
import com.automationanywhere.botcommand.data.impl.StringValue;
import com.google.gson.Gson;

/**
 * Tests the Graph rules of the Person or Group columns without any network access: which column
 * matches, how a value is recognised as an email or a name, and how the PATCH body has to look for
 * a single value and a multi value column.
 */
public class PersonFieldLogicTest {

	@Test
	public void matchesDisplayNameOrInternalNameIgnoringCase() {
		assertTrue(PersonFieldLogic.nameMatches("Assigned To", "Assigned To", "AssignedTo"));
		assertTrue(PersonFieldLogic.nameMatches("assignedto", "Assigned To", "AssignedTo"));
		assertTrue(PersonFieldLogic.nameMatches("ASSIGNED TO", "Assigned To", "AssignedTo"));
	}

	@Test
	public void matchesInternalNameWhenDisplayNameHasSpaces() {
		assertTrue(PersonFieldLogic.nameMatches("External_x0020_Owner", "External Owner", "External_x0020_Owner"));
	}

	@Test
	public void doesNotMatchAnotherColumnOrABlankName() {
		assertFalse(PersonFieldLogic.nameMatches("Assigned To", "Created By", "CreatedBy"));
		assertFalse(PersonFieldLogic.nameMatches("", "Assigned To", "AssignedTo"));
		assertFalse(PersonFieldLogic.nameMatches(null, "Assigned To", "AssignedTo"));
	}

	@Test
	public void treatsAValueWithAnAtSignAsAnEmail() {
		assertTrue(PersonFieldLogic.isEmail("deva.kumar@contoso.com"));
		assertFalse(PersonFieldLogic.isEmail("Deva Kumar"));
		assertFalse(PersonFieldLogic.isEmail(null));
	}

	@Test
	public void looksPeopleUpOnEmailAndGroupsOnTitle() {
		assertEquals(PersonFieldLogic.lookupFieldFor("deva.kumar@contoso.com"), "EMail");
		assertEquals(PersonFieldLogic.lookupFieldFor("Deva Kumar"), "Title");
		assertEquals(PersonFieldLogic.lookupFieldFor("Support Team"), "Title");
	}

	@Test
	public void escapesSingleQuotesInTheODataFilter() {
		assertEquals(PersonFieldLogic.escapeODataString("O'Brien"), "O''Brien");
		assertEquals(PersonFieldLogic.escapeODataString("Plain"), "Plain");
	}

	@Test
	public void buildsTheLookupIdKeyFromTheInternalName() {
		assertEquals(PersonFieldLogic.lookupIdKey("AssignedTo"), "AssignedToLookupId");
	}

	@Test
	public void writesASingleValueColumnAsOneId() {
		Map<String, Object> body = new LinkedHashMap<>();
		PersonFieldLogic.addPersonEntry(body, "AssignedTo", false, Arrays.asList("42"));

		assertEquals(body.size(), 1);
		assertEquals(body.get("AssignedToLookupId"), "42");
	}

	@Test
	public void writesAMultiValueColumnAsAStringCollection() {
		Map<String, Object> body = new LinkedHashMap<>();
		PersonFieldLogic.addPersonEntry(body, "Cc", true, Arrays.asList("7", "9"));

		assertEquals(body.get("CcLookupId@odata.type"), "Collection(Edm.String)");
		assertEquals(body.get("CcLookupId"), Arrays.asList("7", "9"));
	}

	@Test
	public void serializesTheBodyAsGraphExpects() {
		Map<String, Object> single = new LinkedHashMap<>();
		PersonFieldLogic.addPersonEntry(single, "AssignedTo", false, Arrays.asList("42"));
		assertEquals(new Gson().toJson(single), "{\"AssignedToLookupId\":\"42\"}");

		Map<String, Object> multiple = new LinkedHashMap<>();
		PersonFieldLogic.addPersonEntry(multiple, "Cc", true, Arrays.asList("7", "9"));
		assertEquals(new Gson().toJson(multiple),
				"{\"CcLookupId@odata.type\":\"Collection(Edm.String)\",\"CcLookupId\":[\"7\",\"9\"]}");
	}

	@Test
	public void rejectsMoreThanOnePersonForASingleValueColumn() {
		Map<String, Object> body = new LinkedHashMap<>();
		try {
			PersonFieldLogic.addPersonEntry(body, "AssignedTo", false, Arrays.asList("1", "2"));
			fail("A single value column must reject more than one person.");
		} catch (IllegalArgumentException expected) {
			assertTrue(expected.getMessage().contains("AssignedTo"));
		}
		assertTrue(body.isEmpty(), "Nothing may be written when the update is rejected.");
	}

	@Test
	public void ignoresAnEmptyPersonList() {
		Map<String, Object> body = new LinkedHashMap<>();
		PersonFieldLogic.addPersonEntry(body, "AssignedTo", true, Arrays.asList());
		assertTrue(body.isEmpty());
	}

	@Test
	public void readsSeveralPeopleOutOfAListValue() {
		Value<List<Value>> value = new ListValue<String>(new StringValue("Deva Kumar"), new StringValue("Support Team"));

		assertEquals(PersonFieldLogic.toPersonValues(value), Arrays.asList("Deva Kumar", "Support Team"));
	}

	@Test
	public void readsOnePersonOutOfASingleValue() {
		assertEquals(PersonFieldLogic.toPersonValues(new StringValue("deva.kumar@contoso.com")),
				Arrays.asList("deva.kumar@contoso.com"));
	}

	@Test
	public void dropsBlankPeopleAndTrimsTheRest() {
		Value<List<Value>> value = new ListValue<String>(new StringValue("  Deva Kumar  "), new StringValue(""),
				new StringValue("Support Team"));

		assertEquals(PersonFieldLogic.toPersonValues(value), Arrays.asList("Deva Kumar", "Support Team"));
	}
}
