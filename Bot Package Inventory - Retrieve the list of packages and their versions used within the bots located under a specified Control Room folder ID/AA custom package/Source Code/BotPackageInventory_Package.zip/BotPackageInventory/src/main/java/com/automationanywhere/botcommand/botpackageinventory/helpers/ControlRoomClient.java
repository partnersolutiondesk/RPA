/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.helpers;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * Thin client for the Automation Anywhere Control Room APIs used by the package scanner.
 *
 * <p>Calls carry a timeout and are retried on connection problems, 429 and 5xx answers with a
 * growing wait. A 401 makes one thread refresh the session token for everybody and the call is
 * repeated. Safe to use from several worker threads at once.</p>
 *
 * <p>Only Control Room URLs, folder ids and file ids are logged. The API key and the session token
 * are never written to any log.</p>
 */
public class ControlRoomClient {

	/** Control Room type of a taskbot. */
	public static final String TASKBOT_TYPE = "application/vnd.aa.taskbot";
	/** Control Room type of a folder. */
	public static final String DIRECTORY_TYPE = "application/vnd.aa.directory";

	private static final ObjectMapper MAPPER = new ObjectMapper();
	private static final int PAGE_LENGTH = 100;
	private static final int CONNECT_TIMEOUT_MS = 10_000;
	private static final int READ_TIMEOUT_MS = 120_000;
	private static final int MAX_RETRIES = 3;
	private static final int MAX_WAIT_SECONDS = 60;
	/**
	 * Calls that fail completely one after the other before the run is given up. A short network
	 * problem does not reach this, an unreachable Control Room does within a few minutes.
	 */
	private static final int MAX_CONSECUTIVE_FAILURES = 10;
	private static final Set<Integer> RETRY_STATUS = Collections.unmodifiableSet(
			new HashSet<>(Arrays.asList(429, 500, 502, 503, 504)));

	private final String controlRoomUrl;
	private final String username;
	private final String apiKey;
	private final ReportLogger log;
	private final Object tokenLock = new Object();
	private final AtomicInteger consecutiveFailures = new AtomicInteger();

	private volatile String token;
	private volatile boolean aborted;

	public ControlRoomClient(String controlRoomUrl, String username, String apiKey, ReportLogger log) {
		this.controlRoomUrl = stripTrailingSlash(controlRoomUrl.trim());
		this.username = username.trim();
		this.apiKey = apiKey;
		this.log = log;
	}

	public String getControlRoomUrl() {
		return controlRoomUrl;
	}

	/**
	 * Requests a session token for the given user and API key.
	 *
	 * @return true when a usable token was obtained
	 */
	public boolean authenticate() {
		ObjectNode payload = MAPPER.createObjectNode();
		payload.put("username", username);
		payload.put("apiKey", apiKey);

		ApiResponse response = execute("POST", controlRoomUrl + "/v2/authentication", payload.toString(), null);
		if (!isOk(response)) {
			log.error("authenticate", "Authentication failed with status " + statusOf(response)
					+ " for user '" + username + "' on " + controlRoomUrl);
			return false;
		}

		JsonNode body = parse(response.body);
		JsonNode tokenNode = body == null ? null : body.get("token");
		if (tokenNode == null || !tokenNode.isTextual() || tokenNode.asText().isEmpty()) {
			log.error("authenticate", "Authentication response for user '" + username + "' did not contain a token.");
			return false;
		}

		this.token = tokenNode.asText();
		log.info("authenticate", "Authenticated user '" + username + "' on " + controlRoomUrl);
		return true;
	}

	/**
	 * Returns {package name used inside bots (lower case) : artifact name} for every package in the
	 * Control Room. A failure is logged and an empty map is returned, so the scan still runs with a
	 * blank Artifact Name column.
	 */
	public Map<String, String> listPackageArtifacts() {
		Map<String, String> artifacts = new LinkedHashMap<>();
		int offset = 0;

		while (true) {
			ObjectNode payload = MAPPER.createObjectNode();
			ObjectNode filterRequest = payload.putObject("filterRequest");
			filterRequest.putArray("fields");
			filterRequest.putNull("filter");
			filterRequest.putArray("sort").addObject().put("field", "label").put("direction", "asc");
			filterRequest.putObject("page").put("offset", offset).put("length", PAGE_LENGTH);
			payload.put("includeDownloadUrls", false);

			ApiResponse response = call("POST", "/v3/packages/package/list", payload.toString());
			if (!isOk(response)) {
				log.error("listPackageArtifacts", "Packages list API failed: " + statusOf(response)
						+ ". Artifact Name column will be blank");
				return artifacts;
			}

			List<JsonNode> items = itemsOf(response);
			for (JsonNode item : items) {
				if (hasText(item, "name") && hasText(item, "artifactName")) {
					artifacts.put(item.get("name").asText().toLowerCase(Locale.ROOT), item.get("artifactName").asText());
				}
			}

			if (items.size() < PAGE_LENGTH) {
				break;
			}
			offset += PAGE_LENGTH;
		}

		log.debug("listPackageArtifacts", "Got artifact names for " + artifacts.size() + " packages");
		return artifacts;
	}

	/**
	 * Lists one page of a Control Room folder.
	 *
	 * @return the items of the page, or null when the folder could not be listed
	 */
	public List<BotItem> listFolder(String folderId, int offset) {
		ObjectNode payload = MAPPER.createObjectNode();
		payload.putObject("filter");
		payload.putArray("sort").addObject().put("field", "id").put("direction", "desc");
		payload.putObject("page").put("offset", offset).put("length", PAGE_LENGTH);

		ApiResponse response = call("POST", "/v2/repository/folders/" + folderId + "/list", payload.toString());
		if (!isOk(response)) {
			log.error("listFolder", "Listing folder " + folderId + " failed: " + statusOf(response)
					+ ". Its content is missing from the report");
			return null;
		}

		List<BotItem> items = new ArrayList<>();
		for (JsonNode item : itemsOf(response)) {
			items.add(new BotItem(readText(item, "id"), readText(item, "name"), readText(item, "path"), readText(item, "type")));
		}
		return items;
	}

	/**
	 * Reads the JSON definition of a bot.
	 *
	 * @return the file content, or null when it could not be retrieved
	 */
	public String getFileContent(String fileId) {
		ApiResponse response = call("GET", "/v2/repository/files/" + fileId + "/content", null);
		if (!isOk(response) || response.body == null || response.body.isEmpty()) {
			log.error("getFileContent", "Content not retrieved for file ID " + fileId + ": " + statusOf(response));
			return null;
		}
		return response.body;
	}

	/**
	 * Calls a Control Room API with a timeout. Timeouts, 429 and 5xx answers are retried with a
	 * growing wait and a 401 triggers one shared re-authentication.
	 *
	 * @return the response, or null when every attempt failed
	 */
	private ApiResponse call(String method, String path, String body) {
		if (aborted) {
			return null;
		}
		String url = controlRoomUrl + path;

		for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
			String attemptToken = token;
			log.trace("call", "calling " + method + " " + path + " (attempt " + attempt + " of " + MAX_RETRIES + ")");

			ApiResponse response = execute(method, url, body, attemptToken);
			if (response == null) {
				log.warn("call", method + " " + path + " attempt " + attempt + " of " + MAX_RETRIES + " failed");
				if (attempt < MAX_RETRIES) {
					sleep(attempt);
				}
				continue;
			}

			if (response.status == HttpURLConnection.HTTP_UNAUTHORIZED) {
				refreshToken(attemptToken);
				continue;
			}

			if (RETRY_STATUS.contains(response.status)) {
				int wait = Math.min(retryAfterSeconds(response, attempt), MAX_WAIT_SECONDS);
				log.warn("call", method + " " + path + " attempt " + attempt + " of " + MAX_RETRIES + " got status "
						+ response.status + ", waiting " + wait + "s");
				if (attempt < MAX_RETRIES) {
					sleepSeconds(wait);
				}
				continue;
			}

			consecutiveFailures.set(0);
			return response;
		}

		noteFailedCall(method, path);
		return null;
	}

	/**
	 * Counts a call that failed on every attempt. Once too many fail in a row the Control Room is
	 * treated as unreachable and every further call returns at once, so the run stops instead of
	 * retrying the same broken connection for hours.
	 */
	private void noteFailedCall(String method, String path) {
		log.error("call", method + " " + path + " failed after " + MAX_RETRIES + " attempts");

		int failures = consecutiveFailures.incrementAndGet();
		if (failures >= MAX_CONSECUTIVE_FAILURES && !aborted) {
			aborted = true;
			log.error("call", "Giving up: " + failures + " Control Room calls failed one after the other. "
					+ "The Control Room looks unreachable; the work done so far is kept");
		}
	}

	/** True once too many calls failed in a row and the Control Room is treated as unreachable. */
	public boolean isAborted() {
		return aborted;
	}

	/** Calls that failed one after the other; reset by every call that succeeds. */
	public int getConsecutiveFailures() {
		return consecutiveFailures.get();
	}

	/**
	 * Gets a new token unless another thread has already replaced the one that was rejected.
	 */
	private void refreshToken(String rejectedToken) {
		synchronized (tokenLock) {
			if (!Objects.equals(token, rejectedToken)) {
				return;
			}
			log.warn("refreshToken", "401 Unauthorized error. Re-authenticating for new token");
			if (!authenticate()) {
				log.error("refreshToken", "Re-authentication failed.");
			}
		}
	}

	private static int retryAfterSeconds(ApiResponse response, int attempt) {
		String header = response.retryAfter;
		if (header != null) {
			try {
				return Integer.parseInt(header.trim());
			} catch (NumberFormatException e) {
				// Fall through to the growing wait used for answers without a Retry-After header.
			}
		}
		return 1 << attempt;
	}

	private static void sleep(int attempt) {
		sleepSeconds(1 << attempt);
	}

	private static void sleepSeconds(int seconds) {
		try {
			Thread.sleep(seconds * 1000L);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	private ApiResponse execute(String method, String url, String body, String authToken) {
		HttpURLConnection connection = null;
		try {
			connection = (HttpURLConnection) new URL(url).openConnection();
			connection.setRequestMethod(method);
			connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
			connection.setReadTimeout(READ_TIMEOUT_MS);
			connection.setInstanceFollowRedirects(true);
			connection.setRequestProperty("X-Authorization", authToken == null ? "" : authToken);
			connection.setRequestProperty("Accept", "application/json");

			if (body != null) {
				connection.setDoOutput(true);
				connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
				try (OutputStream request = connection.getOutputStream()) {
					request.write(body.getBytes(StandardCharsets.UTF_8));
				}
			}

			int status = connection.getResponseCode();
			InputStream stream = status >= HttpURLConnection.HTTP_BAD_REQUEST
					? connection.getErrorStream()
					: connection.getInputStream();
			return new ApiResponse(status, readFully(stream), connection.getHeaderField("Retry-After"));
		} catch (IOException e) {
			log.warn(method, "Call to " + url + " failed: " + e.getMessage());
			return null;
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	private static String readFully(InputStream stream) throws IOException {
		if (stream == null) {
			return "";
		}
		try (InputStream input = stream) {
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			byte[] chunk = new byte[8192];
			int read;
			while ((read = input.read(chunk)) != -1) {
				buffer.write(chunk, 0, read);
			}
			return buffer.toString(StandardCharsets.UTF_8.name());
		}
	}

	private static List<JsonNode> itemsOf(ApiResponse response) {
		JsonNode body = parse(response.body);
		List<JsonNode> items = new ArrayList<>();
		if (body != null) {
			for (JsonNode item : body.path("list")) {
				items.add(item);
			}
		}
		return items;
	}

	private static JsonNode parse(String json) {
		try {
			return json == null || json.isEmpty() ? null : MAPPER.readTree(json);
		} catch (IOException e) {
			return null;
		}
	}

	private static boolean isOk(ApiResponse response) {
		return response != null && response.status >= 200 && response.status < 300;
	}

	private static String statusOf(ApiResponse response) {
		return response == null ? "no response" : String.valueOf(response.status);
	}

	private static boolean hasText(JsonNode node, String field) {
		JsonNode value = node.get(field);
		return value != null && value.isTextual() && !value.asText().isEmpty();
	}

	private static String readText(JsonNode node, String field) {
		JsonNode value = node.get(field);
		return value == null || value.isNull() ? "" : value.asText();
	}

	private static String stripTrailingSlash(String url) {
		String cleaned = url;
		while (cleaned.endsWith("/")) {
			cleaned = cleaned.substring(0, cleaned.length() - 1);
		}
		return cleaned;
	}

	/** One entry of a Control Room folder listing. */
	public static final class BotItem {

		private final String id;
		private final String name;
		private final String path;
		private final String type;

		BotItem(String id, String name, String path, String type) {
			this.id = id;
			this.name = name;
			this.path = path;
			this.type = type;
		}

		public String getId() {
			return id;
		}

		public String getName() {
			return name;
		}

		public String getPath() {
			return path;
		}

		public String getType() {
			return type;
		}

		public boolean isTaskbot() {
			return TASKBOT_TYPE.equals(type);
		}

		public boolean isDirectory() {
			return DIRECTORY_TYPE.equals(type);
		}
	}

	private static final class ApiResponse {

		private final int status;
		private final String body;
		private final String retryAfter;

		ApiResponse(int status, String body, String retryAfter) {
			this.status = status;
			this.body = body;
			this.retryAfter = retryAfter;
		}
	}
}
