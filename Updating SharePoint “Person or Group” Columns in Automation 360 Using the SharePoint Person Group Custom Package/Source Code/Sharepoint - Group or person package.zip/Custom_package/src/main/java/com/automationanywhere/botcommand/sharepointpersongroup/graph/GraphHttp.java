package com.automationanywhere.botcommand.sharepointpersongroup.graph;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.automationanywhere.botcommand.sharepointpersongroup.session.GraphSession;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

/**
 * Thin Microsoft Graph client built on the JDK {@link HttpClient}. It only knows how to send a
 * request, follow the {@code @odata.nextLink} paging chain, retry once when Graph throttles and
 * return the JSON. How a request is built and what a failure means for the bot is handled by the
 * callers.
 */
public class GraphHttp {

	public static final String GRAPH_BASE = "https://graph.microsoft.com/v1.0";

	private static final Gson GSON = new Gson();

	/** Guard against an endless paging chain. */
	private static final int MAX_PAGES = 100;

	private static final Duration REQUEST_TIMEOUT = Duration.ofSeconds(120);
	private static final Duration MAX_RETRY_AFTER = Duration.ofSeconds(60);
	private static final Duration DEFAULT_RETRY_AFTER = Duration.ofSeconds(5);
	private static final int MAX_DETAIL_LENGTH = 400;

	private final GraphSession session;

	public GraphHttp(GraphSession session) {
		this.session = session;
	}

	/** GET that fails when Graph answers with an error. */
	public JsonObject get(String url, Map<String, String> headers) {
		return toJsonOrFail(execute("GET", url, headers, null), "GET", url);
	}

	/**
	 * GET that returns {@code null} when Graph refuses the query itself (usually because the column
	 * is not indexed). Used to fall back to a paged scan done in code.
	 */
	public JsonObject getOrNull(String url, Map<String, String> headers) {
		HttpResponse<String> response = execute("GET", url, headers, null);
		int status = response.statusCode();
		if (status >= 200 && status < 300) {
			return toJson(response.body());
		}
		if (status == 400 || status == 404 || status == 501) {
			return null;
		}
		throw toGraphException(response, "GET", url);
	}

	/** PATCH the given fields to Graph and return the response body. */
	public JsonObject patch(String url, Map<String, String> headers, Map<String, Object> body) {
		return toJsonOrFail(execute("PATCH", url, headers, GSON.toJson(body)), "PATCH", url);
	}

	/**
	 * Collects every element of the {@code value} array, following {@code @odata.nextLink} until
	 * the last page.
	 */
	public List<JsonElement> getAll(String url, Map<String, String> headers) {
		List<JsonElement> all = new ArrayList<>();
		String next = url;
		int pages = 0;
		while (next != null && pages < MAX_PAGES) {
			JsonObject page = get(next, headers);
			pages++;
			if (page.has("value") && page.get("value").isJsonArray()) {
				JsonArray values = page.getAsJsonArray("value");
				for (JsonElement element : values) {
					all.add(element);
				}
			}
			next = page.has("@odata.nextLink") && !page.get("@odata.nextLink").isJsonNull()
					? page.get("@odata.nextLink").getAsString()
					: null;
		}
		return all;
	}

	private HttpResponse<String> execute(String method, String url, Map<String, String> headers, String body) {
		for (int attempt = 0; ; attempt++) {
			HttpRequest.Builder builder = HttpRequest.newBuilder()
					.uri(URI.create(url))
					.timeout(REQUEST_TIMEOUT)
					.header("Authorization", "Bearer " + session.accessToken())
					.header("Accept", "application/json");
			if (headers != null) {
				for (Map.Entry<String, String> header : headers.entrySet()) {
					builder.header(header.getKey(), header.getValue());
				}
			}
			if (body == null) {
				builder.method(method, HttpRequest.BodyPublishers.noBody());
			} else {
				builder.header("Content-Type", "application/json");
				builder.method(method, HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8));
			}

			HttpResponse<String> response;
			try {
				response = session.getHttpClient().send(builder.build(),
						HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
			} catch (IOException e) {
				throw new GraphException(0, GraphException.UNREACHABLE,
						"Could not reach " + hostOf(url) + ": " + e.getMessage());
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new GraphException(0, GraphException.UNREACHABLE,
						"The request to " + hostOf(url) + " was interrupted: " + e.getMessage());
			}

			int status = response.statusCode();
			if ((status == 429 || status == 503) && attempt == 0) {
				sleep(retryAfter(response));
				continue;
			}
			return response;
		}
	}

	private static Duration retryAfter(HttpResponse<String> response) {
		String value = response.headers().firstValue("Retry-After").orElse(null);
		if (value == null || value.trim().isEmpty()) {
			return DEFAULT_RETRY_AFTER;
		}
		String trimmed = value.trim();
		try {
			long seconds = Long.parseLong(trimmed);
			return seconds < 0 ? DEFAULT_RETRY_AFTER : cap(Duration.ofSeconds(seconds));
		} catch (NumberFormatException e) {
			// Retry-After may also be an HTTP date.
			try {
				Instant when = ZonedDateTime.parse(trimmed, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant();
				Duration wait = Duration.between(Instant.now(), when);
				return wait.isNegative() ? DEFAULT_RETRY_AFTER : cap(wait);
			} catch (RuntimeException ignored) {
				return DEFAULT_RETRY_AFTER;
			}
		}
	}

	private static Duration cap(Duration wait) {
		return wait.compareTo(MAX_RETRY_AFTER) > 0 ? MAX_RETRY_AFTER : wait;
	}

	private static void sleep(Duration wait) {
		try {
			Thread.sleep(wait.toMillis());
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	private static JsonObject toJsonOrFail(HttpResponse<String> response, String method, String url) {
		int status = response.statusCode();
		if (status < 200 || status >= 300) {
			throw toGraphException(response, method, url);
		}
		return toJson(response.body());
	}

	private static JsonObject toJson(String body) {
		if (body == null || body.trim().isEmpty()) {
			return new JsonObject();
		}
		try {
			JsonElement parsed = JsonParser.parseString(body);
			return parsed.isJsonObject() ? parsed.getAsJsonObject() : new JsonObject();
		} catch (JsonSyntaxException e) {
			throw new GraphException(200, "INVALID_RESPONSE",
					"Microsoft Graph returned a response that could not be read.");
		}
	}

	private static GraphException toGraphException(HttpResponse<String> response, String method, String url) {
		int status = response.statusCode();
		String code = "HTTP_" + status;
		String detail = "";
		String body = response.body();
		if (body != null && !body.trim().isEmpty()) {
			try {
				JsonElement parsed = JsonParser.parseString(body);
				if (parsed.isJsonObject() && parsed.getAsJsonObject().has("error")) {
					JsonElement error = parsed.getAsJsonObject().get("error");
					if (error.isJsonObject()) {
						JsonObject errorObject = error.getAsJsonObject();
						if (errorObject.has("code") && !errorObject.get("code").isJsonNull()) {
							code = errorObject.get("code").getAsString();
						}
						if (errorObject.has("message") && !errorObject.get("message").isJsonNull()) {
							detail = errorObject.get("message").getAsString();
						}
					}
				}
			} catch (JsonSyntaxException ignored) {
				detail = body;
			}
		}
		if (detail.trim().isEmpty()) {
			detail = method + " " + hostOf(url) + " failed.";
		}
		detail = shorten(detail.replaceAll("\\s+", " ").trim());
		if (status == 401 || status == 403) {
			return new GraphException(status, GraphException.ACCESS_DENIED, detail);
		}
		return new GraphException(status, code, detail);
	}

	private static String shorten(String detail) {
		return detail.length() <= MAX_DETAIL_LENGTH ? detail : detail.substring(0, MAX_DETAIL_LENGTH) + "...";
	}

	private static String hostOf(String url) {
		try {
			return URI.create(url).getHost();
		} catch (RuntimeException e) {
			return url;
		}
	}

	/** Percent encodes a query value. Spaces are encoded as %20, which OData filters require. */
	public static String urlEncode(String value) {
		try {
			return URLEncoder.encode(value, "UTF-8").replace("+", "%20");
		} catch (UnsupportedEncodingException e) {
			throw new IllegalStateException("UTF-8 is not supported by this Java runtime.", e);
		}
	}

	/** Builds a path below the Microsoft Graph base url, so callers never repeat the base. */
	public static String url(String path) {
		return GRAPH_BASE + path;
	}
}
