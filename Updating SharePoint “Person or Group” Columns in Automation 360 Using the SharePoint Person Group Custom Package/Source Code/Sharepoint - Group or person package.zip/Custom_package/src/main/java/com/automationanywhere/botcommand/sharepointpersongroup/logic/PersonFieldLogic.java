package com.automationanywhere.botcommand.sharepointpersongroup.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.automationanywhere.botcommand.data.Value;

/**
 * The Microsoft Graph specific rules for SharePoint "Person or Group" columns.
 *
 * <p>This is the part of the logic that has nothing to do with HTTP: how a column name is matched,
 * whether a value is an email or a display/group name, how the OData filter is escaped and how the
 * PATCH body has to look for single value and multi value columns. Keeping it here makes the rules
 * unit testable.</p>
 */
public final class PersonFieldLogic {

	public static final String MULTI_VALUE_ODATA_TYPE = "Collection(Edm.String)";

	private static final String LOOKUP_ID_SUFFIX = "LookupId";
	private static final String ODATA_TYPE_SUFFIX = "@odata.type";

	private PersonFieldLogic() {
	}

	/**
	 * A column matches when the requested name equals the column display name or the column
	 * internal name, ignoring case. SharePoint column internal names differ from display names as
	 * soon as the display name contains a space.
	 */
	public static boolean nameMatches(String requested, String displayName, String internalName) {
		String wanted = Inputs.clean(requested);
		if (wanted.isEmpty()) {
			return false;
		}
		return wanted.equalsIgnoreCase(Inputs.clean(displayName))
				|| wanted.equalsIgnoreCase(Inputs.clean(internalName));
	}

	/** A value containing {@code @} is treated as an email address, anything else as a name. */
	public static boolean isEmail(String value) {
		return value != null && value.indexOf('@') >= 0;
	}

	/** User Information List column used to look a person or group up. Groups are matched on Title. */
	public static String lookupFieldFor(String value) {
		return isEmail(value) ? "EMail" : "Title";
	}

	/** Microsoft Graph OData string literals escape a single quote by doubling it. */
	public static String escapeODataString(String value) {
		return value == null ? "" : value.replace("'", "''");
	}

	/** Graph writes people into {@code <InternalName>LookupId}. */
	public static String lookupIdKey(String internalName) {
		return internalName + LOOKUP_ID_SUFFIX;
	}

	/**
	 * Adds one "Person or Group" column to a PATCH body.
	 *
	 * <p>Multi value columns are sent as a string collection. Single value columns take exactly one
	 * person, so more than one lookup ID is rejected before anything is written to SharePoint.</p>
	 *
	 * @throws IllegalArgumentException when a single value column receives more than one person
	 */
	public static void addPersonEntry(Map<String, Object> body, String internalName,
			boolean allowMultipleSelection, List<String> lookupIds) {
		if (lookupIds == null || lookupIds.isEmpty()) {
			return;
		}
		String key = lookupIdKey(internalName);
		if (allowMultipleSelection) {
			body.put(key + ODATA_TYPE_SUFFIX, MULTI_VALUE_ODATA_TYPE);
			body.put(key, new ArrayList<>(lookupIds));
			return;
		}
		if (lookupIds.size() != 1) {
			throw new IllegalArgumentException(
					"Column '" + internalName + "' allows a single person but " + lookupIds.size() + " were provided.");
		}
		body.put(key, lookupIds.get(0));
	}

	/**
	 * Reads the people out of a dictionary value. A value may be a list of emails, display names or
	 * group names, or a single one of them. Blank entries are dropped.
	 */
	public static List<String> toPersonValues(Value value) {
		List<String> people = new ArrayList<>();
		if (value == null) {
			return people;
		}
		Object raw = value.get();
		if (raw instanceof List) {
			for (Object item : (List<?>) raw) {
				addPerson(people, unwrap(item));
			}
		} else {
			addPerson(people, unwrap(raw));
		}
		return people;
	}

	private static Object unwrap(Object item) {
		return item instanceof Value ? ((Value<?>) item).get() : item;
	}

	private static void addPerson(List<String> people, Object raw) {
		String person = Inputs.plainString(raw).trim();
		if (!person.isEmpty()) {
			people.add(person);
		}
	}
}
