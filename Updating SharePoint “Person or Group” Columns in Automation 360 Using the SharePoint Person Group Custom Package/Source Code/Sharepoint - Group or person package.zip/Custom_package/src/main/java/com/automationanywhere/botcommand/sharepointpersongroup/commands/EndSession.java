package com.automationanywhere.botcommand.sharepointpersongroup.commands;

import static com.automationanywhere.commandsdk.model.AttributeType.SESSION;
import static com.automationanywhere.commandsdk.model.DataType.STRING;

import java.util.Map;

import com.automationanywhere.botcommand.data.Value;
import com.automationanywhere.botcommand.data.impl.SessionValue;
import com.automationanywhere.botcommand.data.impl.StringValue;
import com.automationanywhere.botcommand.sharepointpersongroup.session.GraphSession;
import com.automationanywhere.commandsdk.annotations.BotCommand;
import com.automationanywhere.commandsdk.annotations.CommandPkg;
import com.automationanywhere.commandsdk.annotations.Execute;
import com.automationanywhere.commandsdk.annotations.Idx;
import com.automationanywhere.commandsdk.annotations.Pkg;
import com.automationanywhere.commandsdk.annotations.Sessions;
import com.automationanywhere.commandsdk.annotations.rules.SessionObject;
import com.automationanywhere.commandsdk.i18n.Messages;
import com.automationanywhere.commandsdk.i18n.MessagesFactory;
import com.automationanywhere.commandsdk.model.DataType;

/**
 * Ends a SharePoint session: the token is dropped, the site ID is cleared and the session is
 * removed from the bot, so the next Authenticate starts from a fresh token.
 */
@BotCommand
@CommandPkg(
		name = "endSession", label = "[[EndSession.label]]",
		node_label = "[[EndSession.node_label]]",
		description = "[[EndSession.description]]", icon = "pkg.svg",
		return_label = "[[EndSession.return_label]]",
		return_type = STRING, return_required = true)
public class EndSession {

	private static final Messages MESSAGES = MessagesFactory
			.getMessages("com.automationanywhere.botcommand.sharepointpersongroup.messages");

	@Sessions
	private Map<String, Object> sessionMap;

	@Execute
	public Value<String> end(
			@Idx(index = "1", type = SESSION)
			@Pkg(label = "[[EndSession.sessionName.label]]",
					default_value = "Default", default_value_type = DataType.SESSION)
			@SessionObject
			GraphSession session) {

		remove(session);
		session.close();
		return new StringValue(MESSAGES.getString("sessionEnded"));
	}

	/** Removes the session from the bot, whichever way the framework stored it. */
	private void remove(GraphSession session) {
		if (sessionMap != null) {
			sessionMap.values().removeIf(stored -> isSameSession(stored, session));
		}
	}

	private static boolean isSameSession(Object stored, GraphSession session) {
		if (stored == session) {
			return true;
		}
		return stored instanceof SessionValue && ((SessionValue) stored).getSession() == session;
	}

	// The framework injects the session map through this setter.
	public void setSessionMap(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}
}
