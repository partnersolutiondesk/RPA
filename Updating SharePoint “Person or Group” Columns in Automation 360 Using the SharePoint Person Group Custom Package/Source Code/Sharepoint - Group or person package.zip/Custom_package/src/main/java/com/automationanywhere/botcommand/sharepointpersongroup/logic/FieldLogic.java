package com.automationanywhere.botcommand.sharepointpersongroup.logic;

import java.util.Map;

import com.automationanywhere.botcommand.data.Value;

/**
 * Turns the values a bot supplies for normal columns into the values Microsoft Graph expects.
 *
 * <p>Text, numbers and booleans keep their type, because a number column rejects a quoted number.
 * Entries with a blank name or a blank value are skipped so a half filled dictionary is still
 * usable.</p>
 */
public final class FieldLogic {

	private FieldLogic() {
	}

	/**
	 * Adds one normal column to the PATCH body.
	 *
	 * @param internalName the internal name of the column, as Microsoft Graph uses it
	 * @return {@code true} when the entry was added, {@code false} when it was empty and skipped
	 */
	public static boolean addFieldEntry(Map<String, Object> body, String internalName, Value value) {
		String name = Inputs.clean(internalName);
		if (name.isEmpty() || value == null || value.get() == null) {
			return false;
		}
		Object raw = value.get();
		if (raw instanceof Boolean) {
			body.put(name, raw);
			return true;
		}
		if (raw instanceof Number) {
			body.put(name, numberValue((Number) raw));
			return true;
		}
		String text = Inputs.plainString(raw);
		if (Inputs.isBlank(text)) {
			return false;
		}
		body.put(name, text);
		return true;
	}

	/**
	 * A bot number arrives as a {@code Double}, so a whole number would be sent as {@code 7.0} and
	 * SharePoint number columns reject that. Whole values are sent as a long instead.
	 */
	private static Object numberValue(Number number) {
		if (number instanceof Double || number instanceof Float) {
			double value = number.doubleValue();
			if (!Double.isInfinite(value) && !Double.isNaN(value) && value == Math.rint(value)) {
				return (long) value;
			}
		}
		return number;
	}
}
