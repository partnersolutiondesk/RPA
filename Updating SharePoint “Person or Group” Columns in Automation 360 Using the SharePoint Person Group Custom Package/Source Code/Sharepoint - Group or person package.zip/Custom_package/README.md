# SharePoint Person Group

An Automation Anywhere 360 custom package that writes SharePoint **Person or Group** columns over
Microsoft Graph.

The built-in A360 SharePoint package cannot do this: Graph does not accept a name or an email
address in a `personOrGroup` column, it needs the numeric **lookup ID** that the site keeps in its
hidden *User Information List*. This package resolves every email address, display name or group
name to that ID and then writes the column.

It also writes normal (non person) columns in the same session, so a bot can fill a whole list item
in one run.

## Actions

| Action | Purpose |
| --- | --- |
| `Authenticate` | Starts a session: client credentials token + resolved site. Returns the session name. |
| `Update Person or Group column` | Resolves people/groups to lookup IDs and PATCHes one or more person columns of one item. |
| `Update other fields` | PATCHes normal columns of one item in the same session. |
| `End session` | Closes and removes the session. |

Every update action selects the item either **By item ID** or **By column match**. A column match
must find exactly one item, otherwise the action fails and lists the matching IDs (nothing is
updated). The updated item ID is returned as a String.

## Azure / Microsoft Entra ID setup

1. **App registration** – In Microsoft Entra ID (Azure portal) → *App registrations* → *New
   registration*. Single tenant is enough. Note the **Application (client) ID** and the
   **Directory (tenant) ID**.
2. **Graph permission** – *API permissions* → *Add a permission* → **Microsoft Graph** →
   **Application permissions** → `Sites.ReadWrite.All`.
   *Or* least privilege: `Sites.Selected`, plus a per-site grant
   (`POST /sites/{siteId}/permissions` with `write` role) for the site the bot updates.
3. **Admin consent** – Click *Grant admin consent* for the permission. Without it the first Graph
   call fails with HTTP 403 and the action says so.
4. **Client secret** – *Certificates & secrets* → *New client secret*. Copy the secret **Value**
   immediately (not the *Secret ID*, and not the value from *Certificates*). Note the expiry: an
   expired secret fails with `AADSTS7000215`.
5. **Session options** – Nothing else is needed; this package uses the client credentials flow
   (`https://graph.microsoft.com/.default`), so no redirect URI and no MSAL are involved.

In A360, store the secret in a **Credential** (or type it directly, the field allows both) and pass
that credential to `Authenticate`. The secret and the access token are never written to the log.

## Build

The build needs **JDK 11**. Gradle 7.2 plus the A360 2.7.0 command-codegen annotation processor
fail on newer JDKs with `ProcessingException: Incorrectly typed data found for annotation element
... CommandPkg.multiple_returns()`.

```powershell
$env:JAVA_HOME = 'C:\Program Files\Zulu\zulu-11'   # any JDK 11
.\gradlew.bat clean build
```

Artifacts:

- `build/libs/SharePointPersonGroup-1.0.0.jar` – shadow jar with every dependency (Gson) bundled,
  this is the file you upload.
- `build/resources/main/package.json` – the generated package definition.
- `build/reports/tests/test/index.html` – TestNG results for the pure logic tests (no network).

## Install in the Control Room

1. Sign in to the Control Room as an administrator.
2. Open the custom packages page (in current Control Room versions: **Manage → Custom packages**;
   the exact menu label depends on the Control Room version).
3. Upload `build/libs/SharePointPersonGroup-1.0.0.jar` and confirm the upload. The jar already
   contains `package.json`, `locales/en_US.json`, `icons/pkg.svg` and `messages.properties`.
4. In the bot editor the new actions appear under **SharePoint Person Group**.

## Example bot flow

```
1. SharePoint Person Group: Authenticate
     Session name      : Contoso
     Tenant ID         : 46019abb-88e2-4ba2-b79a-8f164f042134
     Client ID         : 8f3c0a4e-...-b1d2
     Client secret     : credential "SP-APP-SECRET"
     SharePoint host   : contoso.sharepoint.com
     Site name         : QARegDeskTest        (empty = root site)
   -> Session name = Contoso

2. SharePoint Person Group: Update Person or Group column
     Session name      : Contoso
     List name         : Requests
     Item selection    : By column match
     Match column      : Title
     Match value       : REQ-1042
     Person/Group updates (dictionary):
         Assigned To -> deva.kumar@contoso.com
         Approvers   -> [priya.sharma@contoso.com, Support Team]
   -> itemId = 42

3. SharePoint Person Group: Update other fields
     Session name      : Contoso
     List name         : Requests
     Item selection    : By item ID
     Item ID           : 42
     Field updates (dictionary):
         Request_x0020_Status -> Open
         Amount               -> 7
   -> itemId = 42

4. SharePoint Person Group: End session
     Session name      : Contoso
```

Notes on the inputs:

- **Person/Group updates** is a dictionary: the key is the column **display name or internal
  name**; the value is a single email / display name / group name, or a list of them.
  A value containing `@` is looked up on `EMail`, anything else on `Title` (that is how SharePoint
  groups are matched).
- A column that allows only one selection rejects more than one value; a multi selection column is
  written as a string collection, as Graph requires.
- **Field updates** keys are also accepted as display name *or* internal name. Values keep their
  type: text is sent as a string, a whole number as `7` (not `7.0`), a boolean as a boolean.
- A list field whose value already equals the new value returns a Graph error; it is safe to
  ignore or to check the returned item ID.

## Behaviour worth knowing

- The people you pass must exist in the site's **User Information List**: only site members (or
  users who have already been resolved on that site) are there. Otherwise the action fails with
  "The user or group '<x>' was not found in this site's User Information List" and tells you to add
  the person to the site.
- The site ID and the token are resolved once during `Authenticate`, and the token is refreshed
  automatically shortly before it expires, so long bots do not fail mid-run.
- Graph paging (`@odata.nextLink`) is followed, requests time out after 120 seconds, and a `429` or
  `503` answer is retried once after the `Retry-After` delay.
- Non indexed column filters are sent with `Prefer: HonorNonIndexedQueriesWarningMayFailRandomly`,
  and if SharePoint still refuses the filter the list is paged and matched in code.

## Assumptions

1. **JDK 11 is required and was found locally at `C:\Program Files\Zulu\zulu-11`.** The build in
   this repository was verified with that JDK; JDK 17/21 make the A360 annotation processor fail.
2. **`sharepoint.svg` was not found anywhere on this machine** (`*.svg` search across
   `C:\Users\DevaKumar\Downloads`), so, as you instructed, `icons/pkg.svg` is still used for the
   package and for every action. Drop `sharepoint.svg` into `src/main/resources/icons/` and replace
   `icon = "pkg.svg"` with `icon = "sharepoint.svg"` in the four `@CommandPkg` annotations to switch.
3. **Gson is the only third party runtime dependency.** It is used for JSON parsing and is bundled
   into the shadow jar, so the package runs with the JDK alone (no MSAL, no Azure SDK).
4. The list is resolved by display name or internal name; the first match wins if a site has both a
   list and a duplicate name.
5. `Site name` is the part after `/sites/`; empty means the root site (`/sites/{host}`).
6. `Update other fields` writes normal columns only. To write a `personOrGroup` column use
   `Update Person or Group column`, because that needs the lookup ID resolution.
