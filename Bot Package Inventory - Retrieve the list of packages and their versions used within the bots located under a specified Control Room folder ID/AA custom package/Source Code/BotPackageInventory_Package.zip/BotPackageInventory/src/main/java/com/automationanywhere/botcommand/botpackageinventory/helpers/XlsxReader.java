/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.helpers;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

/**
 * Reads the parts of an Excel workbook (.xlsx) that the CVE report needs, without any third party
 * library.
 *
 * <p>Sheets are read as a stream of rows, so a very large sheet is never held in memory. Shared
 * strings and inline strings are both understood, which covers the workbooks produced by Excel, by
 * openpyxl and by {@link XlsxReportWriter}.</p>
 */
public final class XlsxReader implements Closeable {

	private static final String SHARED_STRINGS = "xl/sharedStrings.xml";
	private static final String WORKBOOK = "xl/workbook.xml";
	private static final String WORKBOOK_RELATIONSHIPS = "xl/_rels/workbook.xml.rels";
	private static final String WORKSHEET_RELATIONSHIP =
			"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet";

	private final ZipFile zip;
	private final List<String> sharedStrings;
	private final List<String> sheetNames;
	private final Map<String, String> sheetTargets;

	private XlsxReader(ZipFile zip, List<String> sharedStrings, List<String> sheetNames,
			Map<String, String> sheetTargets) {
		this.zip = zip;
		this.sharedStrings = sharedStrings;
		this.sheetNames = sheetNames;
		this.sheetTargets = sheetTargets;
	}

	/** Opens a workbook for reading. The caller must close it. */
	public static XlsxReader open(Path file) throws IOException {
		ZipFile zip = new ZipFile(file.toFile());
		try {
			Map<String, String> relationships = readRelationships(zip, WORKBOOK_RELATIONSHIPS);
			Map<String, String> targets = new LinkedHashMap<>();
			List<String> names = new ArrayList<>();

			for (SheetRef ref : readWorkbook(zip)) {
				names.add(ref.name);
				String target = relationships.get(ref.relationshipId);
				if (target != null) {
					targets.put(ref.name, target);
				}
			}

			return new XlsxReader(zip, readSharedStrings(zip), names, targets);
		} catch (IOException | RuntimeException e) {
			zip.close();
			throw e;
		}
	}

	/** Names of the sheets of the workbook, in workbook order. */
	public List<String> sheetNames() {
		return sheetNames;
	}

	/**
	 * Streams the rows of one sheet.
	 *
	 * <p>The text of every cell is returned; a cell that is missing from the file is returned as an
	 * empty text, so the returned list can be indexed by column number.</p>
	 */
	public Iterator<List<String>> rows(String sheetName) throws IOException {
		String target = sheetTargets.get(sheetName);
		if (target == null) {
			throw new IOException("Sheet '" + sheetName + "' was not found in the workbook");
		}
		InputStream stream = open(zip, target);
		try {
			return new SheetRows(newReader(stream), stream, sharedStrings);
		} catch (XMLStreamException e) {
			closeQuietly(stream);
			throw new IOException("Sheet '" + sheetName + "' could not be read", e);
		}
	}

	@Override
	public void close() throws IOException {
		zip.close();
	}

	private static void closeQuietly(Closeable closeable) {
		try {
			closeable.close();
		} catch (IOException ignored) {
			// The error that made the caller close it is the one that matters.
		}
	}

	private static InputStream open(ZipFile zip, String entryName) throws IOException {
		ZipEntry entry = zip.getEntry(entryName);
		if (entry == null) {
			throw new IOException("'" + entryName + "' was not found in the workbook");
		}
		return zip.getInputStream(entry);
	}

	private static XMLStreamReader newReader(InputStream stream) throws XMLStreamException {
		XMLInputFactory factory = XMLInputFactory.newInstance();
		factory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
		factory.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
		return factory.createXMLStreamReader(stream, "UTF-8");
	}

	/** One sheet entry of workbook.xml. */
	private static final class SheetRef {

		private final String name;
		private final String relationshipId;

		SheetRef(String name, String relationshipId) {
			this.name = name;
			this.relationshipId = relationshipId;
		}
	}

	private static List<SheetRef> readWorkbook(ZipFile zip) throws IOException {
		List<SheetRef> sheets = new ArrayList<>();
		try (InputStream stream = open(zip, WORKBOOK)) {
			XMLStreamReader reader = newReader(stream);
			try {
				while (reader.hasNext()) {
					if (reader.next() == XMLStreamConstants.START_ELEMENT
							&& "sheet".equals(reader.getLocalName())) {
						sheets.add(new SheetRef(reader.getAttributeValue(null, "name"), relationshipId(reader)));
					}
				}
			} finally {
				reader.close();
			}
		} catch (XMLStreamException e) {
			throw new IOException("'" + WORKBOOK + "' could not be read", e);
		}
		return sheets;
	}

	/** The r:id of an element, whatever prefix the document uses for the relationships namespace. */
	private static String relationshipId(XMLStreamReader reader) {
		for (int index = 0; index < reader.getAttributeCount(); index++) {
			if ("id".equals(reader.getAttributeLocalName(index))) {
				return reader.getAttributeValue(index);
			}
		}
		return null;
	}

	private static Map<String, String> readRelationships(ZipFile zip, String entryName) throws IOException {
		Map<String, String> targets = new LinkedHashMap<>();
		if (zip.getEntry(entryName) == null) {
			return targets;
		}
		try (InputStream stream = open(zip, entryName)) {
			XMLStreamReader reader = newReader(stream);
			try {
				while (reader.hasNext()) {
					if (reader.next() != XMLStreamConstants.START_ELEMENT
							|| !"Relationship".equals(reader.getLocalName())) {
						continue;
					}
					if ("External".equals(reader.getAttributeValue(null, "TargetMode"))) {
						continue;
					}
					String id = reader.getAttributeValue(null, "Id");
					String type = reader.getAttributeValue(null, "Type");
					String target = reader.getAttributeValue(null, "Target");
					if (id != null && target != null && (type == null || type.endsWith("worksheet"))) {
						targets.put(id, normalizeTarget(target));
					}
				}
			} finally {
				reader.close();
			}
		} catch (XMLStreamException e) {
			throw new IOException("'" + entryName + "' could not be read", e);
		}
		return targets;
	}

	/** Relationship targets are relative to xl/ unless they start with a slash. */
	private static String normalizeTarget(String target) {
		if (target.startsWith("/")) {
			return target.substring(1);
		}
		return "xl/" + target;
	}

	private static List<String> readSharedStrings(ZipFile zip) throws IOException {
		List<String> strings = new ArrayList<>();
		if (zip.getEntry(SHARED_STRINGS) == null) {
			return strings;
		}
		try (InputStream stream = open(zip, SHARED_STRINGS)) {
			XMLStreamReader reader = newReader(stream);
			try {
				StringBuilder text = new StringBuilder();
				boolean inItem = false;
				while (reader.hasNext()) {
					int event = reader.next();
					if (event == XMLStreamConstants.START_ELEMENT) {
						String local = reader.getLocalName();
						if ("si".equals(local)) {
							text.setLength(0);
							inItem = true;
						} else if (inItem && "t".equals(local)) {
							// A shared string can be split over several runs, so every t is added.
							text.append(reader.getElementText());
						}
					} else if (event == XMLStreamConstants.END_ELEMENT && "si".equals(reader.getLocalName())) {
						strings.add(text.toString());
						inItem = false;
					}
				}
			} finally {
				reader.close();
			}
		} catch (XMLStreamException e) {
			throw new IOException("'" + SHARED_STRINGS + "' could not be read", e);
		}
		return strings;
	}

	/** Streams the rows of one worksheet, one row at a time. */
	private static final class SheetRows implements Iterator<List<String>>, Closeable {

		private final XMLStreamReader reader;
		private final InputStream stream;
		private final List<String> sharedStrings;

		private List<String> next;
		private boolean ended;

		SheetRows(XMLStreamReader reader, InputStream stream, List<String> sharedStrings) {
			this.reader = reader;
			this.stream = stream;
			this.sharedStrings = sharedStrings;
			this.next = advance();
		}

		@Override
		public boolean hasNext() {
			return next != null;
		}

		@Override
		public List<String> next() {
			if (next == null) {
				throw new NoSuchElementException();
			}
			List<String> current = next;
			next = advance();
			return current;
		}

		@Override
		public void close() throws IOException {
			try {
				reader.close();
			} catch (XMLStreamException ignored) {
				// The stream is being closed anyway.
			} finally {
				stream.close();
			}
		}

		private List<String> advance() {
			if (ended) {
				return null;
			}
			try {
				while (reader.hasNext()) {
					int event = reader.next();
					if (event == XMLStreamConstants.START_ELEMENT && "row".equals(reader.getLocalName())) {
						return readRow();
					}
					if (event == XMLStreamConstants.END_ELEMENT && "sheetData".equals(reader.getLocalName())) {
						break;
					}
				}
			} catch (XMLStreamException e) {
				throw new UncheckedIOException(new IOException("The worksheet could not be read", e));
			}
			ended = true;
			closeQuietly(this);
			return null;
		}

		private List<String> readRow() throws XMLStreamException {
			List<String> cells = new ArrayList<>();
			int column = 0;
			while (reader.hasNext()) {
				int event = reader.next();
				if (event == XMLStreamConstants.START_ELEMENT) {
					if ("c".equals(reader.getLocalName())) {
						String reference = reader.getAttributeValue(null, "r");
						String type = reader.getAttributeValue(null, "t");
						if (reference != null) {
							column = columnIndex(reference);
						}
						String value = readCell(type);
						while (cells.size() <= column) {
							cells.add("");
						}
						cells.set(column, value);
						column++;
					}
				} else if (event == XMLStreamConstants.END_ELEMENT && "row".equals(reader.getLocalName())) {
					break;
				}
			}
			return cells;
		}

		/** Reads the value of one cell; the reader is left on the end tag of the cell. */
		private String readCell(String type) throws XMLStreamException {
			StringBuilder value = new StringBuilder();
			boolean inline = false;
			while (reader.hasNext()) {
				int event = reader.next();
				if (event == XMLStreamConstants.START_ELEMENT) {
					String local = reader.getLocalName();
					if ("v".equals(local)) {
						value.append(reader.getElementText());
					} else if ("is".equals(local)) {
						inline = true;
					} else if (inline && "t".equals(local)) {
						value.append(reader.getElementText());
					}
				} else if (event == XMLStreamConstants.END_ELEMENT && "c".equals(reader.getLocalName())) {
					break;
				}
			}

			String text = value.toString();
			if (!"s".equals(type)) {
				return text;
			}
			try {
				int index = Integer.parseInt(text.trim());
				return index >= 0 && index < sharedStrings.size() ? sharedStrings.get(index) : "";
			} catch (NumberFormatException e) {
				return "";
			}
		}
	}

	/** "C12" -> 2 (zero based column number). */
	private static int columnIndex(String reference) {
		int column = 0;
		for (int index = 0; index < reference.length(); index++) {
			char character = reference.charAt(index);
			if (character >= 'A' && character <= 'Z') {
				column = column * 26 + (character - 'A' + 1);
			} else if (character >= 'a' && character <= 'z') {
				column = column * 26 + (character - 'a' + 1);
			} else {
				break;
			}
		}
		return column - 1;
	}
}
