/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.helpers;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Reads a taskbot definition and reports which packages it uses, at which version, and how many
 * commands of each package it calls.
 */
public final class BotPackageAnalyzer {

	private static final ObjectMapper MAPPER = new ObjectMapper();

	private BotPackageAnalyzer() {
	}

	/** One package used by a bot. */
	public static final class PackageUsage {

		private final String name;
		private final String version;
		private final int commands;

		public PackageUsage(String name, String version, int commands) {
			this.name = name;
			this.version = version;
			this.commands = commands;
		}

		public String getName() {
			return name;
		}

		public String getVersion() {
			return version;
		}

		public int getCommands() {
			return commands;
		}
	}

	/**
	 * Returns the packages of one bot, sorted by package name.
	 *
	 * <p>Versions come from the bot "packages" list, command counts come from the bot nodes. A
	 * package can be declared but unused (0 commands) or used without a version entry, so both
	 * sources are merged.</p>
	 *
	 * @throws java.io.IOException when the bot content is not valid JSON
	 */
	public static List<PackageUsage> extractBotPackages(String botContent) throws java.io.IOException {
		JsonNode root = MAPPER.readTree(botContent);

		Map<String, String> versions = new LinkedHashMap<>();
		for (JsonNode document : documentsOf(root)) {
			if (!document.isObject()) {
				continue;
			}
			for (JsonNode pkg : document.path("packages")) {
				if (pkg.isObject() && pkg.hasNonNull("name")) {
					versions.put(pkg.get("name").asText(), pkg.path("version").asText(""));
				}
			}
		}

		Map<String, Integer> counts = new HashMap<>();
		countCommands(root, counts);

		TreeSet<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
		names.addAll(versions.keySet());
		names.addAll(counts.keySet());

		List<PackageUsage> usages = new ArrayList<>(names.size());
		for (String name : names) {
			usages.add(new PackageUsage(name, versions.getOrDefault(name, ""), counts.getOrDefault(name, 0)));
		}
		return usages;
	}

	private static Iterable<JsonNode> documentsOf(JsonNode root) {
		return root.isArray() ? root : List.of(root);
	}

	/**
	 * Counts every command (node) per package. Commands can be nested at any depth, as if / loop /
	 * try blocks keep their children inside the node, so the whole structure is walked. The walk
	 * uses its own stack, so a deeply nested bot cannot overflow the call stack.
	 */
	private static void countCommands(JsonNode root, Map<String, Integer> counts) {
		Deque<JsonNode> stack = new ArrayDeque<>();
		stack.push(root);

		while (!stack.isEmpty()) {
			JsonNode item = stack.pop();
			if (item.isObject()) {
				JsonNode packageName = item.get("packageName");
				if (packageName != null && !packageName.isNull() && !packageName.asText().isEmpty()) {
					counts.merge(packageName.asText(), 1, Integer::sum);
				}
				for (JsonNode child : item) {
					if (child.isContainerNode()) {
						stack.push(child);
					}
				}
			} else if (item.isArray()) {
				for (JsonNode child : item) {
					if (child.isContainerNode()) {
						stack.push(child);
					}
				}
			}
		}
	}

	/** "packagea (version unknown)" style summary used by the bot level sheet. */
	public static String describePackages(List<PackageUsage> usages) {
		List<String> lines = new ArrayList<>(usages.size());
		for (PackageUsage usage : usages) {
			lines.add(usage.getName() + " (" + (usage.getVersion().isEmpty() ? "version unknown" : usage.getVersion()) + ")");
		}
		return String.join("\n", lines);
	}
}
