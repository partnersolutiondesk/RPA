/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.commands;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.automationanywhere.botcommand.data.Value;
import com.automationanywhere.botcommand.data.impl.StringValue;
import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.botcommand.botpackageinventory.helpers.ControlRoomClient;
import com.automationanywhere.botcommand.botpackageinventory.helpers.InventoryScanner;
import com.automationanywhere.botcommand.botpackageinventory.helpers.ReportLogger;
import com.automationanywhere.core.security.SecureString;
import com.automationanywhere.commandsdk.annotations.BotCommand;
import com.automationanywhere.commandsdk.annotations.CommandPkg;
import com.automationanywhere.commandsdk.annotations.Execute;
import com.automationanywhere.commandsdk.annotations.Idx;
import com.automationanywhere.commandsdk.annotations.Pkg;
import com.automationanywhere.commandsdk.annotations.rules.CredentialAllowPassword;
import com.automationanywhere.commandsdk.annotations.rules.FileFolder;
import com.automationanywhere.commandsdk.annotations.rules.LocalFile;
import com.automationanywhere.commandsdk.annotations.rules.NotEmpty;
import com.automationanywhere.commandsdk.i18n.Messages;
import com.automationanywhere.commandsdk.i18n.MessagesFactory;

import static com.automationanywhere.commandsdk.model.AttributeType.CREDENTIAL;
import static com.automationanywhere.commandsdk.model.AttributeType.FILE;
import static com.automationanywhere.commandsdk.model.AttributeType.TEXT;
import static com.automationanywhere.commandsdk.model.DataType.STRING;

/**
 * Walks the given Control Room folder and every subfolder below it, reads each taskbot and writes
 * the packages, their artifact names, versions and command usage into PackageReport.xlsx.
 *
 * <p>The scan writes the report and its log into the provided output folder and returns a JSON
 * summary of the run (bots read, bots failed, skipped, folders failed, report path). The Control
 * Room API key is taken from a credential and is never written to the log.</p>
 */
@BotCommand
@CommandPkg(
		name = "tracePackagesAndCommands", label = "[[TracePackagesAndCommands.label]]",
		node_label = "[[TracePackagesAndCommands.node_label]]",
		description = "[[TracePackagesAndCommands.description]]", icon = "pkg.svg",
		return_label = "[[TracePackagesAndCommands.return_label]]", return_type = STRING, return_required = true)
public class TracePackagesAndCommands {

	private static final Messages MESSAGES = MessagesFactory
			.getMessages("com.automationanywhere.botcommand.botpackageinventory.messages");

	@Execute
	public Value<String> action(
			@Idx(index = "1", type = TEXT)
			@Pkg(label = "[[TracePackagesAndCommands.controlRoomUrl.label]]",
					description = "[[TracePackagesAndCommands.controlRoomUrl.description]]")
			@NotEmpty
			String controlRoomUrl,

			@Idx(index = "2", type = TEXT)
			@Pkg(label = "[[TracePackagesAndCommands.username.label]]")
			@NotEmpty
			String username,

			@Idx(index = "3", type = CREDENTIAL)
			@Pkg(label = "[[TracePackagesAndCommands.apiKey.label]]",
					description = "[[TracePackagesAndCommands.apiKey.description]]")
			@CredentialAllowPassword
			@NotEmpty
			SecureString apiKey,

			@Idx(index = "4", type = TEXT)
			@Pkg(label = "[[TracePackagesAndCommands.folderId.label]]")
			@NotEmpty
			String folderId,

			@Idx(index = "5", type = FILE)
			@Pkg(label = "[[TracePackagesAndCommands.outputPath.label]]",
					description = "[[TracePackagesAndCommands.outputPath.description]]")
			@NotEmpty
			@LocalFile
			@FileFolder
			String outputPath) {

		Path outputFolder = resolveOutputFolder(outputPath);
		String apiKeyValue = readApiKey(apiKey);

		try (ReportLogger log = new ReportLogger(outputFolder.resolve(InventoryScanner.LOG_FILE_NAME),
				ReportLogger.Level.DEBUG)) {

			log.info("action", "Log file started.");
			log.debug("action", "get_report called with folder_id: " + folderId);

			ControlRoomClient client = new ControlRoomClient(controlRoomUrl, username, apiKeyValue, log);
			if (!client.authenticate()) {
				throw new BotCommandException(MESSAGES.getString("authenticationFailed", username, controlRoomUrl.trim()));
			}

			InventoryScanner scanner = new InventoryScanner(client, log, outputFolder);
			String summary = scanner.scan(folderId.trim());

			log.info("action", "Scan finished. Summary: " + summary);
			return new StringValue(summary);
		} catch (InventoryScanner.ScanStoppedException e) {
			// The Control Room became unreachable. The report of what was read is saved and the
			// progress files are kept, so the run can simply be started again.
			throw new BotCommandException(e.getMessage());
		} catch (IOException e) {
			throw new BotCommandException(MESSAGES.getString("reportWriteFailed", outputPath, e.getMessage()));
		}
	}

	private static Path resolveOutputFolder(String outputPath) {
		String cleaned = outputPath == null ? "" : outputPath.trim().replaceAll("^\"|\"$", "");
		if (cleaned.isEmpty()) {
			throw new BotCommandException(MESSAGES.getString("emptyInputString", "outputPath"));
		}

		Path folder = Paths.get(cleaned);
		try {
			Files.createDirectories(folder);
		} catch (IOException e) {
			throw new BotCommandException(MESSAGES.getString("invalidOutputFolder", cleaned));
		}
		if (!Files.isDirectory(folder)) {
			throw new BotCommandException(MESSAGES.getString("invalidOutputFolder", cleaned));
		}
		return folder;
	}

	private static String readApiKey(SecureString apiKey) {
		String value = null;
		if (apiKey != null) {
			value = apiKey.getInsecureString();
		}
		if (value == null || value.trim().isEmpty()) {
			throw new BotCommandException(MESSAGES.getString("missingApiKey"));
		}
		return value;
	}
}
