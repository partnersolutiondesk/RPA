package com.automationanywhere.botcommand.sharepointpersongroup.commands;

import static com.automationanywhere.commandsdk.model.AttributeType.DICTIONARY;
import static com.automationanywhere.commandsdk.model.AttributeType.RADIO;
import static com.automationanywhere.commandsdk.model.AttributeType.SESSION;
import static com.automationanywhere.commandsdk.model.AttributeType.TEXT;
import static com.automationanywhere.commandsdk.model.DataType.STRING;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.automationanywhere.botcommand.data.Value;
import com.automationanywhere.botcommand.data.impl.StringValue;
import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.botcommand.sharepointpersongroup.graph.ColumnInfo;
import com.automationanywhere.botcommand.sharepointpersongroup.graph.ItemLocator;
import com.automationanywhere.botcommand.sharepointpersongroup.graph.SharePointGraph;
import com.automationanywhere.botcommand.sharepointpersongroup.logic.Inputs;
import com.automationanywhere.botcommand.sharepointpersongroup.logic.PersonFieldLogic;
import com.automationanywhere.botcommand.sharepointpersongroup.session.GraphSession;
import com.automationanywhere.commandsdk.annotations.BotCommand;
import com.automationanywhere.commandsdk.annotations.CommandPkg;
import com.automationanywhere.commandsdk.annotations.Execute;
import com.automationanywhere.commandsdk.annotations.Idx;
import com.automationanywhere.commandsdk.annotations.Pkg;
import com.automationanywhere.commandsdk.annotations.rules.NotEmpty;
import com.automationanywhere.commandsdk.annotations.rules.SessionObject;
import com.automationanywhere.commandsdk.i18n.Messages;
import com.automationanywhere.commandsdk.i18n.MessagesFactory;
import com.automationanywhere.commandsdk.model.DataType;

/**
 * Writes one or more SharePoint "Person or Group" columns of a single list item.
 *
 * <p>Microsoft Graph refuses a name or an email in these columns: it wants the numeric lookup ID
 * the site keeps in its hidden "User Information List". This action resolves every email, display
 * name or group name to that ID, reads the column's internal name and whether it allows more than
 * one selection, and then PATCHes the fields of the item. The item is either the one whose ID the
 * bot provides or the single item whose column matches a value.</p>
 */
@BotCommand
@CommandPkg(
		name = "updatePersonOrGroupColumn", label = "[[UpdatePersonOrGroupColumn.label]]",
		node_label = "[[UpdatePersonOrGroupColumn.node_label]]",
		description = "[[UpdatePersonOrGroupColumn.description]]", icon = "pkg.svg",
		return_label = "[[UpdatePersonOrGroupColumn.return_label]]",
		return_type = STRING, return_required = true)
public class UpdatePersonOrGroupColumn {

	private static final Messages MESSAGES = MessagesFactory
			.getMessages("com.automationanywhere.botcommand.sharepointpersongroup.messages");

	@Execute
	public Value<String> update(
			@Idx(index = "1", type = SESSION)
			@Pkg(label = "[[UpdatePersonOrGroupColumn.sessionName.label]]",
					default_value = "Default", default_value_type = DataType.SESSION)
			@SessionObject
			GraphSession session,

			@Idx(index = "2", type = TEXT)
			@Pkg(label = "[[UpdatePersonOrGroupColumn.listName.label]]",
					description = "[[UpdatePersonOrGroupColumn.listName.description]]")
			@NotEmpty
			String listName,

			@Idx(index = "3", type = RADIO, options = {
					@Idx.Option(index = "3.1", pkg = @Pkg(label = "[[UpdatePersonOrGroupColumn.itemSelection.3.1.label]]",
							value = ItemLocator.BY_ID)),
					@Idx.Option(index = "3.2", pkg = @Pkg(label = "[[UpdatePersonOrGroupColumn.itemSelection.3.2.label]]",
							value = ItemLocator.BY_MATCH)) })
			@Pkg(label = "[[UpdatePersonOrGroupColumn.itemSelection.label]]")
			@NotEmpty
			String itemSelection,

			@Idx(index = "4", type = TEXT)
			@Pkg(label = "[[UpdatePersonOrGroupColumn.itemId.label]]",
					description = "[[UpdatePersonOrGroupColumn.itemId.description]]")
			String itemId,

			@Idx(index = "5", type = TEXT)
			@Pkg(label = "[[UpdatePersonOrGroupColumn.matchColumn.label]]",
					description = "[[UpdatePersonOrGroupColumn.matchColumn.description]]")
			String matchColumn,

			@Idx(index = "6", type = TEXT)
			@Pkg(label = "[[UpdatePersonOrGroupColumn.matchValue.label]]",
					description = "[[UpdatePersonOrGroupColumn.matchValue.description]]")
			String matchValue,

			@Idx(index = "7", type = DICTIONARY)
			@Pkg(label = "[[UpdatePersonOrGroupColumn.personUpdates.label]]",
					description = "[[UpdatePersonOrGroupColumn.personUpdates.description]]")
			@NotEmpty
			Map<String, Value> personUpdates) {

		SharePointGraph graph = new SharePointGraph(session);
		String listId = graph.resolveListId(listName);
		String targetItemId = ItemLocator.resolveItemId(graph, listId, listName, itemSelection, itemId, matchColumn,
				matchValue);

		Map<String, Object> body = new LinkedHashMap<>();
		int columnsUpdated = 0;
		for (Map.Entry<String, Value> entry : personUpdates.entrySet()) {
			String columnName = Inputs.clean(entry.getKey());
			List<String> people = PersonFieldLogic.toPersonValues(entry.getValue());
			if (columnName.isEmpty() || people.isEmpty()) {
				continue;
			}
			ColumnInfo column = graph.resolveColumn(listId, listName, columnName, true);
			List<String> lookupIds = new ArrayList<>();
			for (String person : people) {
				lookupIds.add(graph.resolveUserLookupId(person));
			}
			try {
				PersonFieldLogic.addPersonEntry(body, column.getInternalName(), column.isAllowMultipleSelection(),
						lookupIds);
			} catch (IllegalArgumentException e) {
				throw new BotCommandException(MESSAGES.getString("singlePersonColumn", columnName, people.size()));
			}
			columnsUpdated++;
		}
		if (columnsUpdated == 0) {
			throw new BotCommandException(MESSAGES.getString("noPersonUpdates"));
		}

		return new StringValue(graph.patchItemFields(listId, targetItemId, body));
	}
}
