package com.automationanywhere.botcommand.sharepointpersongroup.commands;

import static com.automationanywhere.commandsdk.model.AttributeType.CREDENTIAL;
import static com.automationanywhere.commandsdk.model.AttributeType.TEXT;
import static com.automationanywhere.commandsdk.model.DataType.SESSION;

import com.automationanywhere.botcommand.data.impl.SessionValue;
import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.botcommand.sharepointpersongroup.graph.SharePointGraph;
import com.automationanywhere.botcommand.sharepointpersongroup.logic.Inputs;
import com.automationanywhere.botcommand.sharepointpersongroup.session.GraphSession;
import com.automationanywhere.commandsdk.annotations.BotCommand;
import com.automationanywhere.commandsdk.annotations.CommandPkg;
import com.automationanywhere.commandsdk.annotations.Execute;
import com.automationanywhere.commandsdk.annotations.Idx;
import com.automationanywhere.commandsdk.annotations.Pkg;
import com.automationanywhere.commandsdk.annotations.rules.CredentialAllowPassword;
import com.automationanywhere.commandsdk.annotations.rules.NotEmpty;
import com.automationanywhere.commandsdk.i18n.Messages;
import com.automationanywhere.commandsdk.i18n.MessagesFactory;
import com.automationanywhere.commandsdk.model.ReturnSettingsType;
import com.automationanywhere.core.security.SecureString;

/**
 * Starts a SharePoint session for the other actions of this package.
 *
 * <p>The action exchanges the app registration client credentials for a Microsoft Graph token and
 * resolves the site, so the first thing a bot learns about a wrong secret or a missing admin
 * consent is right here instead of in the middle of an update. The token, the expiry, the site ID
 * and the {@code HttpClient} live in the returned {@link GraphSession}, which refreshes the token
 * on its own before it expires. The client secret is only read when a token is requested and is
 * never logged.</p>
 */
@BotCommand
@CommandPkg(
		name = "authenticate", label = "[[Authenticate.label]]",
		node_label = "[[Authenticate.node_label]]",
		description = "[[Authenticate.description]]", icon = "pkg.svg",
		return_label = "[[Authenticate.return_label]]",
		return_settings = { ReturnSettingsType.SESSION_TARGET },
		return_type = SESSION, default_session_value = "Default", return_required = true)
public class Authenticate {

	private static final Messages MESSAGES = MessagesFactory
			.getMessages("com.automationanywhere.botcommand.sharepointpersongroup.messages");

	@Execute
	public SessionValue startSession(
			@Idx(index = "1", type = TEXT)
			@Pkg(label = "[[Authenticate.tenantId.label]]",
					description = "[[Authenticate.tenantId.description]]")
			@NotEmpty
			String tenantId,

			@Idx(index = "2", type = TEXT)
			@Pkg(label = "[[Authenticate.clientId.label]]",
					description = "[[Authenticate.clientId.description]]")
			@NotEmpty
			String clientId,

			@Idx(index = "3", type = CREDENTIAL)
			@Pkg(label = "[[Authenticate.clientSecret.label]]",
					description = "[[Authenticate.clientSecret.description]]")
			@CredentialAllowPassword
			@NotEmpty
			SecureString clientSecret,

			@Idx(index = "4", type = TEXT)
			@Pkg(label = "[[Authenticate.sharePointHost.label]]",
					description = "[[Authenticate.sharePointHost.description]]")
			@NotEmpty
			String sharePointHost,

			@Idx(index = "5", type = TEXT)
			@Pkg(label = "[[Authenticate.siteName.label]]",
					description = "[[Authenticate.siteName.description]]")
			String siteName) {

		String tenant = require(tenantId, "tenantIdRequired");
		String client = require(clientId, "clientIdRequired");
		String host = hostOf(sharePointHost);

		GraphSession session = new GraphSession(tenant, client, clientSecret, host, Inputs.clean(siteName));
		try {
			session.accessToken();
			session.setSiteId(new SharePointGraph(session).resolveSiteId());
		} catch (RuntimeException e) {
			session.close();
			throw e;
		}
		return SessionValue.builder().withSessionObject(session).build();
	}

	private static String require(String value, String messageKey) {
		String cleaned = Inputs.clean(value);
		if (cleaned.isEmpty()) {
			throw new BotCommandException(MESSAGES.getString(messageKey));
		}
		return cleaned;
	}

	/** Accepts both {@code contoso.sharepoint.com} and a pasted {@code https://contoso.sharepoint.com/}. */
	private static String hostOf(String sharePointHost) {
		String host = Inputs.clean(sharePointHost).replaceFirst("(?i)^https?://", "");
		int slash = host.indexOf('/');
		if (slash >= 0) {
			host = host.substring(0, slash);
		}
		if (host.isEmpty() || host.indexOf('.') < 0) {
			throw new BotCommandException(MESSAGES.getString("invalidSharePointHost", sharePointHost));
		}
		return host;
	}
}
