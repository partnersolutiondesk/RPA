package com.automationanywhere.botcommand.sharepointpersongroup.logic;

/**
 * Small helpers for turning bot supplied values into the plain values the Graph API expects.
 *
 * <p>Deliberately free of any network or SDK runtime dependency so it can be unit tested
 * without a Control Room.</p>
 */
public final class Inputs {

	private Inputs() {
	}

	/** Trims a value that may be {@code null}. */
	public static String clean(String value) {
		return value == null ? "" : value.trim();
	}

	/** True when the value is {@code null} or blank after trimming. */
	public static boolean isBlank(String value) {
		return clean(value).isEmpty();
	}

	/**
	 * Renders a value coming from a bot variable as text. Whole numbers are rendered without the
	 * trailing {@code .0} that A360 number values would otherwise produce.
	 */
	public static String plainString(Object raw) {
		if (raw == null) {
			return "";
		}
		if (raw instanceof Double) {
			double number = (Double) raw;
			if (!Double.isInfinite(number) && !Double.isNaN(number) && number == Math.rint(number)) {
				return String.valueOf((long) number);
			}
		}
		return String.valueOf(raw);
	}
}
