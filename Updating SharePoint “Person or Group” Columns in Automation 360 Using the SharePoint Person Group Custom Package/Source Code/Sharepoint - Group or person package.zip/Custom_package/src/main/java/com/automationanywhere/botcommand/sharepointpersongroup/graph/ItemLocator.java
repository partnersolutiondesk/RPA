package com.automationanywhere.botcommand.sharepointpersongroup.graph;

import java.util.List;
import java.util.StringJoiner;

import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.botcommand.sharepointpersongroup.logic.Inputs;
import com.automationanywhere.commandsdk.i18n.Messages;
import com.automationanywhere.commandsdk.i18n.MessagesFactory;

/**
 * Works out which list item has to be updated: either the ID the bot supplied, or the single item
 * whose column equals a given value.
 *
 * <p>An ambiguous match is never updated. When more than one item matches, the action fails and
 * lists the IDs so the bot developer can make the match value more specific.</p>
 */
public final class ItemLocator {

	/** Radio value of the "By item ID" selection. */
	public static final String BY_ID = "id";

	/** Radio value of the "By column match" selection. */
	public static final String BY_MATCH = "match";

	private static final Messages MESSAGES = MessagesFactory
			.getMessages("com.automationanywhere.botcommand.sharepointpersongroup.messages");

	private ItemLocator() {
	}

	/**
	 * @param itemSelection {@link #BY_ID} or {@link #BY_MATCH}
	 * @return the ID of the one item to update
	 * @throws BotCommandException when a required input is missing, no item matches, or more than
	 *         one item matches
	 */
	public static String resolveItemId(SharePointGraph graph, String listId, String listName, String itemSelection,
			String itemId, String matchColumn, String matchValue) {
		if (!BY_MATCH.equals(Inputs.clean(itemSelection))) {
			String id = Inputs.clean(itemId);
			if (id.isEmpty()) {
				throw new BotCommandException(MESSAGES.getString("itemIdRequired"));
			}
			return id;
		}

		String column = Inputs.clean(matchColumn);
		if (column.isEmpty()) {
			throw new BotCommandException(MESSAGES.getString("matchColumnRequired"));
		}
		String value = Inputs.clean(matchValue);
		if (value.isEmpty()) {
			throw new BotCommandException(MESSAGES.getString("matchValueRequired"));
		}

		ColumnInfo info = graph.resolveColumn(listId, listName, column, false);
		List<String> ids = graph.findItemIds(listId, info.getInternalName(), value);
		if (ids.isEmpty()) {
			throw new BotCommandException(MESSAGES.getString("noItemForMatch", column, value));
		}
		if (ids.size() > 1) {
			StringJoiner joined = new StringJoiner(", ");
			for (String id : ids) {
				joined.add(id);
			}
			throw new BotCommandException(
					MESSAGES.getString("ambiguousItemMatch", ids.size(), column, value, joined.toString()));
		}
		return ids.get(0);
	}
}
