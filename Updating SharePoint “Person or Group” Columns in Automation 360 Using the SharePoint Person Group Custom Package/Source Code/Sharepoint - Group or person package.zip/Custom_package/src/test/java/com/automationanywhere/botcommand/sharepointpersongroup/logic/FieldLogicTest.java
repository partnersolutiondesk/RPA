package com.automationanywhere.botcommand.sharepointpersongroup.logic;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.Test;

import com.automationanywhere.botcommand.data.impl.BooleanValue;
import com.automationanywhere.botcommand.data.impl.NumberValue;
import com.automationanywhere.botcommand.data.impl.StringValue;

/**
 * Tests how the values of normal columns are turned into the values the field PATCH sends.
 */
public class FieldLogicTest {

	@Test
	public void writesTextAsAString() {
		Map<String, Object> body = new LinkedHashMap<>();
		assertTrue(FieldLogic.addFieldEntry(body, "Request_x0020_Status", new StringValue("Open")));
		assertEquals(body.get("Request_x0020_Status"), "Open");
	}

	@Test
	public void writesAWholeNumberWithoutADecimalPart() {
		Map<String, Object> body = new LinkedHashMap<>();
		assertTrue(FieldLogic.addFieldEntry(body, "Amount", new NumberValue(7.0)));
		assertEquals(body.get("Amount"), 7L);
	}

	@Test
	public void keepsTheDecimalPartOfANumber() {
		Map<String, Object> body = new LinkedHashMap<>();
		assertTrue(FieldLogic.addFieldEntry(body, "Amount", new NumberValue(7.5)));
		assertEquals(body.get("Amount"), 7.5);
	}

	@Test
	public void writesABooleanAsABoolean() {
		Map<String, Object> body = new LinkedHashMap<>();
		assertTrue(FieldLogic.addFieldEntry(body, "IsOpen", new BooleanValue(true)));
		assertEquals(body.get("IsOpen"), Boolean.TRUE);
	}

	@Test
	public void skipsABlankNameOrValue() {
		Map<String, Object> body = new LinkedHashMap<>();
		assertFalse(FieldLogic.addFieldEntry(body, "  ", new StringValue("Open")));
		assertFalse(FieldLogic.addFieldEntry(body, "Status", new StringValue("   ")));
		assertFalse(FieldLogic.addFieldEntry(body, "Status", null));
		assertTrue(body.isEmpty());
	}

	@Test
	public void rendersAWholeNumberWithoutATrailingZero() {
		assertEquals(Inputs.plainString(Double.valueOf(12.0)), "12");
		assertEquals(Inputs.plainString(Double.valueOf(12.5)), "12.5");
		assertEquals(Inputs.plainString(null), "");
	}

	@Test
	public void treatsBlankValuesAsBlank() {
		assertTrue(Inputs.isBlank("   "));
		assertTrue(Inputs.isBlank(null));
		assertFalse(Inputs.isBlank(" Open "));
		assertEquals(Inputs.clean(" Open "), "Open");
	}
}
