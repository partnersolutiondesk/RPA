/*
 * Copyright (c) 2019 Automation Anywhere.
 * All rights reserved.
 *
 * This software is the proprietary information of Automation Anywhere.
 * You shall use it only in accordance with the terms of the license agreement
 * you entered into with Automation Anywhere.
 */
package com.automationanywhere.botcommand.botpackageinventory.helpers;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Writes a workbook the same way the report of the CVE scan needs it: rows are streamed straight to
 * disk, so the memory used does not grow with the number of rows, and the number of sheets is only
 * known when the workbook is closed.
 *
 * <p>On top of {@link XlsxReportWriter} it supports rows with an outline level (the collapsible
 * grouped sheets), rows with a fill colour, and sheets that continue on "&lt;name&gt; 2" when they
 * are full.</p>
 *
 * <p>The rows of every sheet are written to a temporary file as they are added; the workbook is
 * assembled from those files when {@link #finish()} is called, which is also when the sheet names
 * are written, so a sheet that was started but never needed can be left out.</p>
 */
public final class StreamingXlsxWriter implements Closeable {

	/** Cell style of a normal cell. */
	public static final int STYLE_DEFAULT = 0;
	/** Cell style of a bold header row. */
	public static final int STYLE_HEADER = 1;
	/** Cell style of a CVE main row. */
	public static final int STYLE_CVE = 2;
	/** Cell style of an artifact / package group row. */
	public static final int STYLE_GROUP = 3;

	/** The number of rows Excel allows on one sheet. */
	private static final int MAX_ROWS_PER_SHEET = 1_048_000;
	/** A grouped sheet continues on a new part at the next main row after this many rows. */
	private static final int SOFT_ROWS_PER_SHEET = 900_000;
	/** Outline level used by the grouped report sheets. */
	private static final int OUTLINE_LEVELS = 2;

	private static final String XML_DECLARATION = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
	private static final String MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
	private static final int BUFFER_SIZE = 1 << 16;

	private final Path target;
	private final Path partsDir;
	private final List<Part> parts = new ArrayList<>();

	private int sheetNumber;
	private boolean saved;

	public StreamingXlsxWriter(Path target, Path partsDir) throws IOException {
		this.target = target;
		this.partsDir = partsDir;
		Files.createDirectories(partsDir);
	}

	/**
	 * Adds a sheet. Rows are added through the returned handle.
	 *
	 * @param outline true for the grouped sheets whose rows can be collapsed
	 */
	public Sheet addSheet(String baseName, List<Object> header, double[] widths, boolean outline)
			throws IOException {
		Sheet sheet = new Sheet(baseName, header, widths, outline);
		sheet.nextPart();
		return sheet;
	}

	/** Assembles the workbook from the rows written so far into the target file. */
	public void finish() throws IOException {
		save(target);
	}

	/**
	 * Assembles the workbook into the given file. It is called with the target file by
	 * {@link #finish()}; a caller can call it again with another file when the target could not be
	 * written (for example because the report is open in Excel), because the rows that were written
	 * are still kept until the workbook has been saved once.
	 */
	public void save(Path file) throws IOException {
		if (saved) {
			return;
		}
		for (Part part : parts) {
			part.close();
		}

		try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(file))) {
			addEntry(zip, "[Content_Types].xml", contentTypes(parts.size()));
			addEntry(zip, "_rels/.rels", packageRelationships());
			addEntry(zip, "docProps/core.xml", coreProperties());
			addEntry(zip, "docProps/app.xml", applicationProperties());
			addEntry(zip, "xl/workbook.xml", workbook());
			addEntry(zip, "xl/_rels/workbook.xml.rels", workbookRelationships(parts.size()));
			addEntry(zip, "xl/styles.xml", styles());
			for (int index = 0; index < parts.size(); index++) {
				writeWorksheet(zip, "xl/worksheets/sheet" + (index + 1) + ".xml", parts.get(index));
			}
		}
		saved = true;
		deleteParts();
	}

	@Override
	public void close() {
		if (saved) {
			return;
		}
		for (Part part : parts) {
			part.closeQuietly();
		}
		deleteParts();
	}

	/** One sheet of the workbook. */
	public final class Sheet {

		private final String baseName;
		private final List<Object> header;
		private final double[] widths;
		private final boolean outline;

		private Part part;

		/** Parts of this sheet, so its continuation sheets are numbered per sheet. */
		private int partIndex;

		private Sheet(String baseName, List<Object> header, double[] widths, boolean outline) {
			this.baseName = baseName;
			this.header = header;
			this.widths = widths;
			this.outline = outline;
		}

		/** Adds a row that is not grouped. */
		public void add(List<Object> cells) throws IOException {
			add(cells, 0, STYLE_DEFAULT, false);
		}

		/**
		 * Adds a row.
		 *
		 * @param level    outline level, 0 for a row that is not grouped
		 * @param style    one of the STYLE_ constants
		 * @param mainRow  true for the row that starts a new group, so a full sheet is left at a
		 *                 group boundary
		 */
		public void add(List<Object> cells, int level, int style, boolean mainRow) throws IOException {
			if (part.rows >= MAX_ROWS_PER_SHEET || (mainRow && part.rows >= SOFT_ROWS_PER_SHEET)) {
				part.close();
				nextPart();
			}
			part.append(cells, level, style);
		}

		private void nextPart() throws IOException {
			sheetNumber++;
			partIndex++;
			String name = partIndex == 1 ? baseName : baseName + " " + partIndex;
			part = new Part(name, headers(), widths, outline, partsDir.resolve("rows_" + sheetNumber + ".xml"));
			parts.add(part);
		}

		/** The name column of a part, so a part can be recognised by its content as well. */
		private List<Object> headers() {
			return header;
		}
	}

	/** The rows of one sheet as they are collected on disk. */
	private static final class Part {

		private final String name;
		private final List<Object> header;
		private final double[] widths;
		private final boolean outline;
		private final Path file;
		private final Writer writer;

		private int rows;
		private boolean closed;

		Part(String name, List<Object> header, double[] widths, boolean outline, Path file) throws IOException {
			this.name = name;
			this.header = header;
			this.widths = widths;
			this.outline = outline;
			this.file = file;
			this.writer = new BufferedWriter(new OutputStreamWriter(Files.newOutputStream(file),
					StandardCharsets.UTF_8), BUFFER_SIZE);
			writeRow(this.writer, 1, header, STYLE_HEADER, 0);
			this.rows = 1;
		}

		void append(List<Object> cells, int level, int style) throws IOException {
			rows++;
			writeRow(writer, rows, cells, style, level);
		}

		void close() throws IOException {
			if (closed) {
				return;
			}
			closed = true;
			writer.close();
		}

		void closeQuietly() {
			try {
				close();
			} catch (IOException ignored) {
				// The workbook is being abandoned; there is nothing useful to do with this.
			}
		}
	}

	private void writeWorksheet(ZipOutputStream zip, String entryName, Part part) throws IOException {
		int columnCount = part.header.size();
		String range = "A1:" + columnName(columnCount) + Math.max(part.rows, 1);

		zip.putNextEntry(new ZipEntry(entryName));
		Writer writer = new BufferedWriter(new OutputStreamWriter(zip, StandardCharsets.UTF_8), BUFFER_SIZE);

		writer.write(XML_DECLARATION);
		writer.write("<worksheet xmlns=\"" + MAIN_NS + "\">");
		if (part.outline) {
			writer.write("<sheetPr><outlinePr summaryBelow=\"0\"/></sheetPr>");
		}
		writer.write("<dimension ref=\"" + range + "\"/>");
		writer.write("<sheetViews><sheetView workbookViewId=\"0\">"
				+ "<pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/>"
				+ "<selection pane=\"bottomLeft\" activeCell=\"A2\" sqref=\"A2\"/>"
				+ "</sheetView></sheetViews>");
		writer.write(part.outline
				? "<sheetFormatPr defaultRowHeight=\"15\" outlineLevelRow=\"" + OUTLINE_LEVELS + "\"/>"
				: "<sheetFormatPr defaultRowHeight=\"15\"/>");
		writer.write("<cols>");
		for (int column = 0; column < columnCount; column++) {
			double width = column < part.widths.length ? part.widths[column] : 0;
			writer.write("<col min=\"" + (column + 1) + "\" max=\"" + (column + 1) + "\" width=\"" + width
					+ "\" customWidth=\"1\"/>");
		}
		writer.write("</cols><sheetData>");
		writer.flush();

		try (InputStream rows = Files.newInputStream(part.file)) {
			byte[] buffer = new byte[BUFFER_SIZE];
			int read;
			while ((read = rows.read(buffer)) != -1) {
				writer.write(new String(buffer, 0, read, StandardCharsets.UTF_8));
			}
		}

		writer.write("</sheetData></worksheet>");
		writer.flush();
		zip.closeEntry();
	}

	private static void writeRow(Writer writer, int rowNumber, List<Object> cells, int style, int level)
			throws IOException {
		StringBuilder xml = new StringBuilder(256);
		xml.append("<row r=\"").append(rowNumber).append('"');
		if (level > 0) {
			xml.append(" outlineLevel=\"").append(level).append('"');
		}
		xml.append('>');

		for (int column = 0; column < cells.size(); column++) {
			Object value = cells.get(column);
			if (value == null && style == STYLE_DEFAULT) {
				continue;
			}
			xml.append("<c r=\"").append(columnName(column + 1)).append(rowNumber).append('"');
			if (style != STYLE_DEFAULT) {
				xml.append(" s=\"").append(style).append('"');
			}
			if (value == null) {
				xml.append("/>");
			} else if (value instanceof Number) {
				xml.append("><v>").append(value).append("</v></c>");
			} else {
				xml.append(" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
						.append(escape(String.valueOf(value))).append("</t></is></c>");
			}
		}

		xml.append("</row>");
		writer.write(xml.toString());
	}

	private void deleteParts() {
		try {
			if (!Files.isDirectory(partsDir)) {
				return;
			}
			try (java.util.stream.Stream<Path> files = Files.list(partsDir)) {
				for (Path file : files.sorted(Comparator.reverseOrder()).toArray(Path[]::new)) {
					Files.deleteIfExists(file);
				}
			}
			Files.deleteIfExists(partsDir);
		} catch (IOException ignored) {
			// Only temporary files; the next run removes what is left.
		}
	}

	private String workbook() {
		StringBuilder xml = new StringBuilder(XML_DECLARATION);
		xml.append("<workbook xmlns=\"").append(MAIN_NS)
				.append("\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");
		xml.append("<sheets>");
		for (int index = 0; index < parts.size(); index++) {
			xml.append("<sheet name=\"").append(escape(parts.get(index).name)).append("\" sheetId=\"").append(index + 1)
					.append("\" r:id=\"rId").append(index + 1).append("\"/>");
		}
		xml.append("</sheets></workbook>");
		return xml.toString();
	}

	private static String workbookRelationships(int sheetCount) {
		StringBuilder xml = new StringBuilder(XML_DECLARATION);
		xml.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
		for (int index = 1; index <= sheetCount; index++) {
			xml.append("<Relationship Id=\"rId").append(index)
					.append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
					.append(index).append(".xml\"/>");
		}
		xml.append("<Relationship Id=\"rId").append(sheetCount + 1)
				.append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>");
		xml.append("</Relationships>");
		return xml.toString();
	}

	private static String contentTypes(int sheetCount) {
		StringBuilder xml = new StringBuilder(XML_DECLARATION);
		xml.append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">");
		xml.append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>");
		xml.append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>");
		xml.append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>");
		xml.append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
		for (int index = 1; index <= sheetCount; index++) {
			xml.append("<Override PartName=\"/xl/worksheets/sheet").append(index)
					.append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
		}
		xml.append("<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>");
		xml.append("<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>");
		xml.append("</Types>");
		return xml.toString();
	}

	private static String packageRelationships() {
		return XML_DECLARATION
				+ "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
				+ "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
				+ "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
				+ "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>"
				+ "</Relationships>";
	}

	private static String coreProperties() {
		return XML_DECLARATION
				+ "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\""
				+ " xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\""
				+ " xmlns:dcmitype=\"http://purl.org/dc/dcmitype/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<dc:creator>BotPackageInventory</dc:creator>"
				+ "<cp:lastModifiedBy>BotPackageInventory</cp:lastModifiedBy>"
				+ "</cp:coreProperties>";
	}

	private static String applicationProperties() {
		return XML_DECLARATION
				+ "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\""
				+ " xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\">"
				+ "<Application>BotPackageInventory</Application>"
				+ "</Properties>";
	}

	private static String styles() {
		return XML_DECLARATION
				+ "<styleSheet xmlns=\"" + MAIN_NS + "\">"
				+ "<fonts count=\"2\">"
				+ "<font><sz val=\"11\"/><color theme=\"1\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
				+ "<font><b/><sz val=\"11\"/><color theme=\"1\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
				+ "</fonts>"
				+ "<fills count=\"4\">"
				+ "<fill><patternFill patternType=\"none\"/></fill>"
				+ "<fill><patternFill patternType=\"gray125\"/></fill>"
				+ "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFBDD7EE\"/><bgColor indexed=\"64\"/></patternFill></fill>"
				+ "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFDDEBF7\"/><bgColor indexed=\"64\"/></patternFill></fill>"
				+ "</fills>"
				+ "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
				+ "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
				+ "<cellXfs count=\"4\">"
				+ "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
				+ "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>"
				+ "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/>"
				+ "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/>"
				+ "</cellXfs>"
				+ "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
				+ "<dxfs count=\"0\"/>"
				+ "</styleSheet>";
	}

	private static void addEntry(ZipOutputStream zip, String name, String content) throws IOException {
		zip.putNextEntry(new ZipEntry(name));
		byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
		zip.write(bytes, 0, bytes.length);
		zip.closeEntry();
	}

	private static String columnName(int columnNumber) {
		StringBuilder name = new StringBuilder();
		int remaining = columnNumber;
		while (remaining > 0) {
			int letter = (remaining - 1) % 26;
			name.insert(0, (char) ('A' + letter));
			remaining = (remaining - letter) / 26;
		}
		return name.toString();
	}

	private static String escape(String value) {
		StringBuilder escaped = new StringBuilder(value.length() + 16);
		for (int index = 0; index < value.length(); index++) {
			char character = value.charAt(index);
			switch (character) {
				case '&':
					escaped.append("&amp;");
					break;
				case '<':
					escaped.append("&lt;");
					break;
				case '>':
					escaped.append("&gt;");
					break;
				case '"':
					escaped.append("&quot;");
					break;
				case '\'':
					escaped.append("&apos;");
					break;
				default:
					if (character == '\t' || character == '\n' || character == '\r' || character >= 0x20) {
						escaped.append(character);
					}
					break;
			}
		}
		return escaped.toString();
	}
}
