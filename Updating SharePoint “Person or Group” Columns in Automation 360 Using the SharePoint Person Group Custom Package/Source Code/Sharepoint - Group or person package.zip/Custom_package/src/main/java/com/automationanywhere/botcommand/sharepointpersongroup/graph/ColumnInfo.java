package com.automationanywhere.botcommand.sharepointpersongroup.graph;

/**
 * The SharePoint column details this package needs: the internal name used by the Graph API, the
 * display name shown to the user and whether the column holds more than one person or group.
 */
public class ColumnInfo {

	private final String internalName;
	private final String displayName;
	private final boolean allowMultipleSelection;
	private final boolean personOrGroup;

	public ColumnInfo(String internalName, String displayName, boolean personOrGroup, boolean allowMultipleSelection) {
		this.internalName = internalName;
		this.displayName = displayName;
		this.personOrGroup = personOrGroup;
		this.allowMultipleSelection = allowMultipleSelection;
	}

	public String getInternalName() {
		return internalName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public boolean isPersonOrGroup() {
		return personOrGroup;
	}

	public boolean isAllowMultipleSelection() {
		return allowMultipleSelection;
	}

	@Override
	public String toString() {
		return displayName + " (" + internalName + ", personOrGroup=" + personOrGroup
				+ ", multiple=" + allowMultipleSelection + ")";
	}
}
