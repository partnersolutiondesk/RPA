package com.automationanywhere.botcommand.sharepointpersongroup.commands;

import static com.automationanywhere.commandsdk.model.AttributeType.DICTIONARY;
import static com.automationanywhere.commandsdk.model.AttributeType.RADIO;
import static com.automationanywhere.commandsdk.model.AttributeType.SESSION;
import static com.automationanywhere.commandsdk.model.AttributeType.TEXT;
import static com.automationanywhere.commandsdk.model.DataType.STRING;

import java.util.LinkedHashMap;
import java.util.Map;

import com.automationanywhere.botcommand.data.Value;
import com.automationanywhere.botcommand.data.impl.StringValue;
import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.botcommand.sharepointpersongroup.graph.ColumnInfo;
import com.automationanywhere.botcommand.sharepointpersongroup.graph.ItemLocator;
import com.automationanywhere.botcommand.sharepointpersongroup.graph.SharePointGraph;
import com.automationanywhere.botcommand.sharepointpersongroup.logic.FieldLogic;
import com.automationanywhere.botcommand.sharepointpersongroup.session.GraphSession;
import com.automationanywhere.commandsdk.annotations.BotCommand;
import com.automationanywhere.commandsdk.annotations.CommandPkg;
import com.automationanywhere.commandsdk.annotations.Execute;
import com.automationanywhere.commandsdk.annotations.Idx;
import com.automationanywhere.commandsdk.annotations.Pkg;
import com.automationanywhere.commandsdk.annotations.rules.NotEmpty;
import com.automationanywhere.commandsdk.annotations.rules.SessionObject;
import com.automationanywhere.commandsdk.i18n.Messages;
import com.automationanywhere.commandsdk.i18n.MessagesFactory;
import com.automationanywhere.commandsdk.model.DataType;

/**
 * Writes the normal (non person) columns of a single list item in the same session, so a bot can
 * fill the whole item in one run: the person columns with
 * {@link UpdatePersonOrGroupColumn} and everything else here.
 *
 * <p>The keys of the dictionary are the column internal names, because a column whose display name
 * contains spaces has an internal name such as
 * {@code External_x0020_System_x0020_reference}.</p>
 */
@BotCommand
@CommandPkg(
		name = "updateOtherFields", label = "[[UpdateOtherFields.label]]",
		node_label = "[[UpdateOtherFields.node_label]]",
		description = "[[UpdateOtherFields.description]]", icon = "pkg.svg",
		return_label = "[[UpdateOtherFields.return_label]]",
		return_type = STRING, return_required = true)
public class UpdateOtherFields {

	private static final Messages MESSAGES = MessagesFactory
			.getMessages("com.automationanywhere.botcommand.sharepointpersongroup.messages");

	@Execute
	public Value<String> update(
			@Idx(index = "1", type = SESSION)
			@Pkg(label = "[[UpdateOtherFields.sessionName.label]]",
					default_value = "Default", default_value_type = DataType.SESSION)
			@SessionObject
			GraphSession session,

			@Idx(index = "2", type = TEXT)
			@Pkg(label = "[[UpdateOtherFields.listName.label]]",
					description = "[[UpdateOtherFields.listName.description]]")
			@NotEmpty
			String listName,

			@Idx(index = "3", type = RADIO, options = {
					@Idx.Option(index = "3.1", pkg = @Pkg(label = "[[UpdateOtherFields.itemSelection.3.1.label]]",
							value = ItemLocator.BY_ID)),
					@Idx.Option(index = "3.2", pkg = @Pkg(label = "[[UpdateOtherFields.itemSelection.3.2.label]]",
							value = ItemLocator.BY_MATCH)) })
			@Pkg(label = "[[UpdateOtherFields.itemSelection.label]]")
			@NotEmpty
			String itemSelection,

			@Idx(index = "4", type = TEXT)
			@Pkg(label = "[[UpdateOtherFields.itemId.label]]",
					description = "[[UpdateOtherFields.itemId.description]]")
			String itemId,

			@Idx(index = "5", type = TEXT)
			@Pkg(label = "[[UpdateOtherFields.matchColumn.label]]",
					description = "[[UpdateOtherFields.matchColumn.description]]")
			String matchColumn,

			@Idx(index = "6", type = TEXT)
			@Pkg(label = "[[UpdateOtherFields.matchValue.label]]",
					description = "[[UpdateOtherFields.matchValue.description]]")
			String matchValue,

			@Idx(index = "7", type = DICTIONARY)
			@Pkg(label = "[[UpdateOtherFields.otherFields.label]]",
					description = "[[UpdateOtherFields.otherFields.description]]")
			@NotEmpty
			Map<String, Value> otherFields) {

		SharePointGraph graph = new SharePointGraph(session);
		String listId = graph.resolveListId(listName);
		String targetItemId = ItemLocator.resolveItemId(graph, listId, listName, itemSelection, itemId, matchColumn,
				matchValue);

		Map<String, Object> body = new LinkedHashMap<>();
		int fieldsUpdated = 0;
		for (Map.Entry<String, Value> entry : otherFields.entrySet()) {
			String columnName = entry.getKey();
			ColumnInfo column = graph.resolveColumn(listId, listName, columnName, false);
			if (FieldLogic.addFieldEntry(body, column.getInternalName(), entry.getValue())) {
				fieldsUpdated++;
			}
		}
		if (fieldsUpdated == 0) {
			throw new BotCommandException(MESSAGES.getString("noFieldUpdates"));
		}

		return new StringValue(graph.patchItemFields(listId, targetItemId, body));
	}
}
